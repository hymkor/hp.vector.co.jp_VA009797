#define INCL_DOSMEMMGR
#define INCL_RXFUNC
// #define INCL_RXSUBCOM
#include <os2.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include "getline.h"

TtyCannaInputR inputline;

extern "C" ULONG APIENTRY effinput(  PSZ name
				   , long argc
				   , RXSTRING argv[]
				   , PSZ queueName
				   , RXSTRING *retval )
{
  if( argc > 0 )
    fputs( (char*)argv[0].strptr , stdout );

  const char *answer=inputline.getline((char*)(argc > 1?argv[1].strptr:0));
  if( answer != NULL ){
    int length = strlen(answer);
    if( length > 255 ){
      int rc=DosAllocMem(  (void**)&retval->strptr , length+1
			 , PAG_COMMIT | PAG_READ | PAG_WRITE );
      if( rc != 0 )
	return rc;
    }
    strcpy( (char*)retval->strptr , answer );
    retval->strlength = length;
  }else{
    retval->strptr[0] = '\0';
    retval->strlength = 0;
  }
  return 0;
}
