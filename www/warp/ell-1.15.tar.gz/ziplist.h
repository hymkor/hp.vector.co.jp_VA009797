/* -*- c++ -*- */
#ifndef ZIPLIST_H
#define ZIPLIST_H

#include <stdio.h>
#include "macros.h"
#include "sem.h"

class StrEnum {
public:
  virtual const char *next()=0;
};

void myexec(const char *command,const char *fname);
int filename_match(const char *pattern , const char *path );

struct ZipType{
  char *suffix ;
  int islaunch;
  int period;
  char *unpacker ;
  char *junk_unpacker ; /* �p�X�����̂Ă� unpacker */
  char *lister ;
  char *printer ;
  char *killer ;
  char *header ;
  char *tailer ;
  int rootchar;
  int linecount,fnamepos;
  int isIndex ;

  /* EXE�t�@�C���ȂǁA�g���q�����ŏ��ɂ𔻕ʂł��Ȃ��ꍇ�A
   * address �� keyword �Ŕ���ł���B
   */
  int startAddress , endAddress;
  char *keyword ;

  ZipType *next;
  
  ZipType() : suffix(0) , islaunch(0) , period(1) , unpacker(0) 
    , junk_unpacker(0) , lister(0) , printer(0) , killer(0) , header(0) 
      , tailer(0) , rootchar(0) 
	, linecount(1) , fnamepos(1) ,isIndex(0) , startAddress(0) 
	  , endAddress(0) , keyword(0) , next(0) { }

  void copy_from( const ZipType &z ){
    islaunch      = z.islaunch;
    unpacker      = z.unpacker;
    junk_unpacker = z.junk_unpacker;
    lister        = z.lister;
    printer       = z.printer;
    header        = z.header;
    tailer        = z.tailer;
    linecount     = z.linecount;
    fnamepos      = z.fnamepos;
    rootchar      = z.rootchar;
  }

  int extract( const char *archive , const char *fname );
  int extract( const char *archive , StrEnum &filelist );
};

extern ZipType *typelist;
ZipType *readini(const char *argv0);
int isFileThatArchive(const char *fname,ZipType *ziptype);

/* ZipList �̂P�C���X�^���X���A�A�[�J�C�u���̂P�t�@�C����\���B
 * ZipList �̃N���X�S�̂ŁA�P�A�[�J�C�u�������ׁA
 * �����̃A�[�J�C�u�𓯎��Ɉ������Ƃ͕s�\�B
 */
class ZipList{
  static ZipList *first;
  static int nowreading;
  
  static ZipType *ziptype; /* ziptype �� NULL �ȊO�Ȃ�΃A�[�J�C�u
			      �����Ȃ���΁A�f�B���N�g�� */
  static FILE *pp;
  static char fullpath[FILENAME_MAX];
  static int nmarks,nkillmarks;
	
  ZipList *next,*prev;
  int nlines;
  char *name,*info[4];
  int mark;
  int killmark;

  static void ya_thread(void *);/* (void*) <--- (ZipList*) */

  static MutexSem sem;
  static int count;

  int linenumber;

  ZipList();/* constructor */
public:
  static int get_count(void);
  static int is_nowreading(void)
    { int rc;sem.request();rc=nowreading;sem.release();return rc; }
  static ZipType *get_type(void){ return ziptype; }
  static int get_mark_num(void){ return nmarks; }
  static int get_kill_num(void){ return nkillmarks; }
  static ZipList *get_1st(void){ return first; }
	
  ~ZipList();/* destructor */
	
  void reverse_mark();
  void operator ++ (void);
  void operator -- (void);
  int is_mark(void) const { return mark; }
  int is_kill(void) const { return killmark; }
  int operator* (void){ return mark; }

  void del(void);
  void undel(void);
  
  static ZipList *open(  const char *fname
		       , ZipType **type=NULL
		       , const char *as_fname=NULL );
  // .exe �t�@�C�� .zip ������ open ����ꍇ�́A
  // open(fname,type,".zip")�ȂǂƂ���B

  static void     close(void); 
  static const char *get_arcname(void){ return fullpath; }
  static ZipList *get_first(void){ return first; }
  
  ZipList *draw(const char *title=NULL);
  
  void draw(int l,int offset=0);

  int get_linenumber()const{return linenumber;}
  ZipList *forward();
  ZipList *backward() const { return prev; }
  int Nlines() const { return nlines; }
  const char *havestr(const char *s);
  
  int get_linecount(void) const { return nlines; }
  const char *get_name(void) const { return name; }
  const char *operator[] (int n) const { return info[n]; }

  class MarkEnum : public StrEnum {
    ZipList *ptr;
  public:
    MarkEnum() : ptr(0) { }
    const char *next();
  };
};
#endif
