#define INCL_DOSNLS
#define INCL_DOSPROCESS
#define INCL_DOSSEMAPHORES
#define INCL_VIO
#include <os2.h>
#include <stdlib.h>
#include <sys/video.h>
#include <sys/ea.h>
#include "zipwin.h"

void ZipWindow::print_lnum(void)
{
  char buffer[80];
  int C,len;
  USHORT X,Y;

  len = sprintf(buffer,"[%4d/%-4d]"
		, cursor->get_linenumber()+1
		, ZipList::get_count()+1 );
  
  VioGetCurPos(&Y,&X,0);
  // v_getxy(&X,&Y);
  C=v_getattr();

  v_gotoxy( x2-len-1 , y1-1 );
  v_attrib( is_filer_mode() ? 0x0B : 0x0A );
  v_puts(buffer);

  v_attrib(C);
  v_gotoxy(X,Y);
}

extern void v_chattr(int x, int y, int w, int attr);
extern void v_frameline(int x, int y, int w, const char *frame);
typedef const char (*framechar_t)[4];
extern framechar_t theframe;

void ZipWindow::marking(void)
{
  cursor->reverse_mark();
  repaint_csrlin();
}

void ZipWindow::del(void)
{
  if (ZipList::get_mark_num() == 0) {
    cursor->del();
    repaint_csrlin();
  } else {
    ZipList *ptr = ZipList::get_1st();
    while (ptr != NULL) {
      if (ptr->is_mark())
	ptr->del();
      ptr = ptr->forward();
    }
    repaint();
  }
}

void ZipWindow::undel(void)
{
  cursor->undel();
  repaint_csrlin();
}

void ZipWindow::undel_all(void)
{
  if (ZipList::get_kill_num() > 0) {
    ZipList *ptr = ZipList::get_1st();
    while (ptr != NULL) {
      if (ptr->is_kill())
	ptr->undel();
      ptr = ptr->forward();
    }
    repaint();
  }
}

void ZipWindow::cursor_on(void)
{
  if (status == OPEN) {
    status = CSRON;
    for (int i = 0; i < ziptype->linecount; i++) {
      v_chattr(x1, y1 + csrlin * ziptype->linecount + i, x2 - x1 + 1, 0x4F);
    }
  }
}

void ZipWindow::cursor_off(void)
{
  if (status == CSRON) {
    status = OPEN;
    for (int i = 0; i < ziptype->linecount; i++) {
      v_chattr(x1, y1 + csrlin * ziptype->linecount + i, x2 - x1 + 1, 0x0F);
    }
  }
}

void ZipWindow::init(const char *fname,const char *as_fname)
{
  heaven = ZipList::open(fname, &ziptype, as_fname);
  status = (heaven == NULL ? ERROR : CLOSE);
  direct = 0;
  column_offset = 0;
}

int ZipWindow::getkey(void)
{
  int ch;
  if( ZipList::is_nowreading() ){
    int lnum=-1;
    while( (ch=::getkey(0)) == (-1) ){
      /* �s���\������ */
      if( lnum != ZipList::get_count() ){
	this->print_lnum();
	lnum = ZipList::get_count();
      }else{
	sleep(0);
      }
    }
  }else{
    ch = ::getkey(1);
  }
  return ch;
}

void ZipWindow::search_forward(void)
{
  /* �܂��A��ʓ��ɂȂ������������� */
  ZipList *ptr;
  if( (ptr=cursor->forward()) != hell ){
    int lnum=csrlin+1;
    
    while( ptr != hell ){
      if( ptr == NULL ){
	DosBeep(1380,100);
	return;
      }
      if( ptr->havestr(searchstr) != NULL ){
	cursor = ptr;
	csrlin = lnum;
	return;
      }
      ptr = ptr->forward();
      lnum++;
    }
  }
     
  ZipList *top=heaven->forward();
  while( ptr != NULL ){
    if( ptr->havestr(searchstr) != NULL ){
      cursor = earth = ptr;
      hell = earth->forward();
      heaven = top;
      csrlin = files_per_win-1;
      repaint();
      return;
    }
    top = top->forward();
    ptr = ptr->forward();
  }
  DosBeep(1380,100);
}

void ZipWindow::search_backward(void)
{
  /* �܂��A��ʓ��ɂȂ������������� */
  ZipList *ptr;
  if( (ptr=cursor) != heaven && (ptr=cursor->backward()) != heaven ){
    int lnum=csrlin-1;

    while( ptr != heaven ){
      if( ptr == NULL ){
	DosBeep(1380,100);
	return;
      }
      if( ptr->havestr(searchstr) != NULL ){
	cursor = ptr;
	csrlin = lnum;
	return;
      }
      ptr = ptr->backward();
      lnum--;
    }
  }
  while( ptr != NULL ){
    if( ptr->havestr(searchstr) != NULL ){
      heaven = cursor = ptr;
      csrlin = 0;
      repaint();
      return;
    }
    ptr = ptr->backward();
  }
  DosBeep(1380,100);
}

void ZipWindow::search_first(int dir=1)
{
  searchstr[0]='\0';
  direct = (dir >= 0 ? 1 : -1);

  line_input(  x1
	     , y2+1
	     , (dir > 0 ? "Search forward:" : "Search backward:")
	     , searchstr,sizeof(searchstr) );
  if( direct > 0 )
    search_forward();
  else
    search_backward();
}

void ZipWindow::search_next(int reverse=0)
{
  if( direct == 0 ){
    DosBeep(1380,100);
    return;
  }

  if( (reverse ? -direct : direct ) > 0 )
    search_forward();
  else
    search_backward();
}

void ZipWindow::repaint(void)
{
  hell = earth = heaven;
  
  int y = y1;
  int attr , revattr;
  if( is_filer_mode() ){
    attr = 0x0B;
    revattr = 0x3F;
  }else{
    attr = 0x0A;
    revattr = 0x2F;
  }

  v_attrib(attr);
  v_frameline(0, 0, width, theframe[0]);

  /* �t�@�C�������^�C�g���Ƃ��ĕ\�� */
  const char *filename = ZipList::get_arcname();
  int len = strlen(filename);
  v_attrib(revattr);

  /* �s�ԍ����E��ɕ\�� */
  this->print_lnum();

#if COMMENT_HEAD
  if( comment != NULL ){
    v_gotoxy( x1+1 , y1-1 );
    v_puts( filename );
    v_attrib( attr );
    v_puts( " : " );
    v_putm( comment , commentsize );
  }else{
#endif
    v_gotoxy(x1 + (x2 - x1 - len) / 2, y1 - 1);
    v_puts(filename);
#ifdef COMMENT_HEAD
  }
#endif
  for (int i = 0; i < files_per_win && hell != NULL; i++) {
    v_attrib(attr);
    for (int j = 0; j < ziptype->linecount; j++){
      /* v_frameline(0, y + j, width, theframe[1]); */
      v_gotoxy( 0 , y+j ); v_putc( theframe[1][0] );
      v_gotoxy( width-1 , y+j ); v_putc( theframe[1][2] );
    }
    
    v_attrib(0x0F);
    hell->draw(y,column_offset);
    
    earth = hell;
    hell = hell->forward();
    
    y += ziptype->linecount;
  }
  v_attrib(attr);
  v_frameline(0, y, width, theframe[2]);
#ifdef COMMENT_TAIL
  if( comment != NULL ){
    v_gotoxy( x1 + (x2 - x1 - commentsize )/2 , y );
    v_putm( comment , commentsize );
  }
#endif
  status = OPEN;
}

void ZipWindow::open(void)
{
  if (status == ERROR)
    return;
  
  v_dimen(&width, &height);
  if( theframe == NULL ){
    theframe = getframechar();
  }
  csrlin = 0;
  files_per_win = (height - 2) / ziptype->linecount;
  x1 = 1;
  x2 = width - 2;
  y1 = 1;
  y2 = files_per_win * ziptype->linecount;
  
  cursor = hell = earth = heaven;
  repaint();
}

int ZipWindow::next(void)
{
  ZipList *tmp = cursor->forward();
  if (tmp != NULL) {
    if (csrlin + 1 < files_per_win) {
      cursor = tmp;
      csrlin++;
    } else if( hell != NULL ){
      earth = hell;
      hell = hell->forward();
      heaven = heaven->forward();
      cursor = tmp;

      v_scroll(x1, y1, x2, y2, ziptype->linecount, V_SCROLL_UP);
      earth->draw(x1 + ziptype->linecount * (files_per_win - 1),column_offset);
    }
    return 0;
  } else {
    return -1;
  }
}
void ZipWindow::next_page(void)
{
  for (int i = 0; i < files_per_win && forward() == 0; i++)
    ;
  repaint();
}

int ZipWindow::prev(void)
{
  ZipList *tmp = cursor->backward();
  if (tmp != NULL) {
    ZipList *newheaven;
    if (0 < csrlin) {
      cursor = tmp;
      csrlin--;
    } else if( (newheaven=heaven->backward()) != NULL ){
      heaven = newheaven;
      hell = earth;
      earth = earth->backward();
      cursor = tmp;

      v_scroll(x1, y1, x2, y2, ziptype->linecount, V_SCROLL_DOWN);
      heaven->draw(x1,column_offset);
    }
    return 0;
  } else {
    return -1;
  }
}
void ZipWindow::prev_page(void)
{
  for (int i = 0; i < files_per_win && backward() == 0; i++)
    ;
  repaint();
}

void ZipWindow::first(void)
{
  cursor = heaven = ZipList::get_1st();
  csrlin = 0;
  repaint();
}

void ZipWindow::last(void)
{
  while (forward() == 0)
    ;
  
  while (cursor != earth) {
    cursor = cursor->forward();
    csrlin++;
  }
  repaint();
}

int ZipWindow::forward(void)
{
  ZipList *tmp;
  cursor_off();
  
  if (hell != NULL) {
    earth = hell;
    hell = hell->forward();
    heaven = heaven->forward();
    cursor = cursor->forward();
    return 0;
  }else if( csrlin < files_per_win-1 && (tmp=cursor->forward()) != NULL ){
    cursor = tmp;
    ++csrlin;
    return 0;
  }
  return 1;
}

int ZipWindow::backward(void)
{
  cursor_off();
  ZipList *tmp = heaven->backward();
  if (tmp != NULL) {
    heaven = tmp;
    hell = earth;
    earth = earth->backward();
    cursor = cursor->backward();
    return 0;
  }else if( csrlin > 0  && (tmp=cursor->backward()) != NULL ){
    cursor = tmp;
    --csrlin;
    return 0;
  }
  return 1;
}
