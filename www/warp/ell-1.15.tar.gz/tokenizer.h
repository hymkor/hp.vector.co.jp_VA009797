// -*- c++ -*-
#ifndef TOKENIZER_H
#define TOKENIZER_H

class Tokenizer{
  int lastchar;
protected:
  // �ꕶ���擾
  virtual int read()=0;
public:
  class SyntaxError {
    const char *errmsg;
  public:
    SyntaxError(const char *p=0) throw() : errmsg(p) {}
    const char *getErrMsg() const throw() { return errmsg; }
    const char *getErrMsg(const char *x) const throw() {
      return errmsg != 0 ? errmsg : x ;
    }
  };
  class TooNearEof {};

  // �R���X�g���N�^�B
  Tokenizer() throw() : lastchar('\n') { }
  virtual ~Tokenizer(){ }
  
  class PostIncResult {
    int prevchar;
  public:
    PostIncResult(int ch) throw() : prevchar(ch) { }
    int operator * () const throw() { return prevchar; }
  };

  int operator *  () const throw() { return lastchar; }
  Tokenizer &operator++(){ lastchar=read(); return *this; }
  PostIncResult  operator++(int){
    PostIncResult rc(lastchar);   ++*this;   return rc;
  }
  virtual int isOk() const=0;

  /* �\����̊e�v�f���擾���� 
   */
  Tokenizer &passSpace(); // �󔒂�ǂݔ�΂��B
  void passChar(int ch) throw(TooNearEof,SyntaxError);
  
  char *readIdentifier(char *buffer,int size)
    throw(TooNearEof,SyntaxError);
  char *readQuoted(char *buffer,int size)
    throw(TooNearEof,SyntaxError);
  int readNumber();
};

class FileTokenizer : public Tokenizer {
  char *fname;
  FILE *fp;
  int lnum;
protected:
  int read();
public:
  int isOk() const;

  FileTokenizer( const char *fname );
  FileTokenizer( FILE *_fp ) throw(): Tokenizer() , fname((char*)0) , fp(_fp) 
    , lnum(0) { }
  ~FileTokenizer();
  
  int getLineNumber() const throw(){ return lnum; }
  const char *getFileName() const throw() { return fname; }
};

#endif
