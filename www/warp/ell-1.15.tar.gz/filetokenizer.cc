#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "Tokenizer.h"

int FileTokenizer::read()
{
  if( this->operator * () == '\n' ){
    lnum++;
    int ch=getc(fp);
    if( ch == '#' ){
      for(;;){
	if( feof(fp) )
	  return -1;
	if( (ch=getc(fp)) == '\n' )
	  return '\n';
      }
    }
    // fputc(ch,stderr);
    return ch;
  }
  int ch=getc(fp);
  // fputc(ch,stderr);
  return ch;
}

int FileTokenizer::isOk() const
{
  return fp != NULL && !feof(fp);
}

FileTokenizer::FileTokenizer( const char *fname )
{
  this->fname = strdup(fname);
  fp=fopen(fname,"r");
  lnum=0;
}

FileTokenizer::~FileTokenizer()
{
  if( fname != 0 )
    free(fname);

  if( fp != 0 )
    fclose(fp);
}
