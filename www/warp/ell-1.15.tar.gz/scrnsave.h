/* -*- c++ -*- */
#ifndef SCREEN_SAVE_H
#define SCREEN_SAVE_H

class ScreenSave{
 protected:
  int width,height;
  char *screen;
  
  unsigned short cursor_x,cursor_y;
  int cursor_start,cursor_end;
public:
  ScreenSave( void );
  ~ScreenSave( void );
  
  void restore( void );
  void resave( void );
};

#endif

