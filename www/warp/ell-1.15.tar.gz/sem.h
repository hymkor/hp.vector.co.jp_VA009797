/* -*- c++ -*- */
#ifndef SEM_H
#define SEM_H

/***** �P�Ȃ�AOS/2 API�̃Z�}�t�H�֐��ɑ΂��� C++ �̃t�B���^�[ ****/

#define INCL_DOSSEMAPHORES
#include <os2.h>

class MutexSem{
  HMTX hmtx;
public:
  int  create(BOOL32 isowned=FALSE , PCSZ name=NULL )
    { return DosCreateMutexSem(name,&hmtx,0,isowned); }

  void request(ULONG timeout=(ULONG)SEM_INDEFINITE_WAIT )
    {  (void)DosRequestMutexSem( hmtx , timeout ); }

  void release()
    {  (void)DosReleaseMutexSem( hmtx ); }
};

#endif
