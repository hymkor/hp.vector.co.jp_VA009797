#include <assert.h>
#include <alloca.h>
#include <ctype.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/video.h>
#include <sys/kbdscan.h>
#include <sys/types.h>
#include <dirent.h>

#define INCL_VIO
#include <os2.h>

#include "macros.h"
extern unsigned PROMPT_COLOR ,ANSWER_COLOR;

extern int getkey( int wait );

class Shiel{
  char buffer[512];
  int x,y,length;
  USHORT cursor_x,cursor_y;
  int orgattr;
public:
  void putat(int x,int y,const char *string,int attr=-1);
  void putoff(void);
};

void Shiel::putat(int x_,int y_,const char *string,int attr=-1)
{
  VioGetCurPos( &cursor_y , &cursor_x , 0 );
  orgattr = v_getattr();
  if( attr != -1 )
    v_attrib(attr);

  length = strlen(string);
  assert( length*2 < (int)sizeof(buffer) );
  v_getline( buffer , x=x_ , y=y_ , length );
  v_gotoxy( x , y );
  v_puts( string );
}

void Shiel::putoff( void )
{
  v_putline( buffer , x , y , length );
  v_gotoxy( cursor_x , cursor_y );
  v_attrib( orgattr );
}


int path_input(int x0,int y0,const char *prompt,char *buffer,size_t size )
{
  enum{ ANK , KNJ1ST , KNJ2ND };
  
  char *atrbuf = (char*)alloca( size );
	
  int top = x0+strlen(prompt);
  
  int screen_width,screen_height;
  v_dimen( &screen_width , &screen_height );
  
  char *saveline = (char *)alloca(2*(screen_width-x0));
  v_getline( saveline , x0 , y0 , screen_width-x0 );
  
  int max = size-1;
  

  v_attrib( ANSWER_COLOR );
  v_scroll( x0 , y0 , screen_width-1 , y0 , 1 , V_SCROLL_CLEAR );
  
  v_ctype( 0 , 16 );
  
  v_attrib( PROMPT_COLOR );
  v_gotoxy( x0 , y0 );
  v_puts( prompt );
  
  v_attrib( ANSWER_COLOR );
  
  int len=0;
  while(  buffer[ len ] != '\0'  ){
    if( is_kanji( buffer[ len ] ) ){
      atrbuf[ len++ ] = KNJ1ST;
      atrbuf[ len++ ] = KNJ2ND;
    }else{
      atrbuf[ len++ ] = ANK;
    }
  }
  if( len > 0 ){
    v_gotoxy( top , y0 );
    v_putm( buffer , len );
  }
  int pos=len;
  
  for(;;){
    v_gotoxy( top+pos , y0 );
    
    int ch=getkey(1);
    
  switch_ch:
    switch( ch ){
    default:
      if( is_kanji( ch ) ){
	if( len <= max-2 ){
	  for(int i=len-1 ; i>=pos ; i-- ){
	    buffer[ i+2 ] = buffer[ i ];
	    atrbuf[ i+2 ] = atrbuf[ i ];
	  }
	  buffer[ pos ] = ch;
	  atrbuf[ pos ] = KNJ1ST;
	  
	  buffer[ pos+1 ] = getkey(0);
	  atrbuf[ pos+1 ] = KNJ2ND;
	  
	  v_putm( &buffer[pos] , (len+=2)-pos );
	  pos+=2;
	}
      }else if( ch < 0x100  &&  isprint( ch ) ){
	if( len <= max-1 ){
	  for(int i=len ; i>= pos ; i-- ){
	    buffer[ i+1 ] = buffer[ i ];
	    atrbuf[ i+1 ] = atrbuf[ i ];
	  }
	  buffer[ pos ] = ch;
	  atrbuf[ pos ] = ANK;
	  
	  v_putm( &buffer[pos] , ++len-pos );
	  pos++;
	}
      }
      break;
      
    case '\t':/* �t�@�C�����⊮ */
      if( len > 0 ){ /* �f�B���N�g���͍Œ�ꕶ�� */
	char directory[256];
	char name[256];
	int namepos =0;  /* �`���_��W�J�����ꍇ�̖��O�ʒu */
	int namepos2=0; /* �`���_��W�J���Ȃ��ꍇ�̖��O�ʒu */
		
	const char *sp=buffer;
	char *dp=directory;
	char *lastroot=NULL;

	int i=0;
	if( *sp == '~' && (sp[1] == '/' || sp[1] == '\\' ) ){
	  const char *home=getenv("HOME");
	  if( home != NULL ){
	    while( *home != '\0' ){
	      *dp++ = *home++;
	    }
	    ++sp;
	    ++i;
	  }
	}
	int waskanji=0;
	for(; i<len ; i++ ){
	  if( (*sp == '\\' || *sp == '/'  || *sp==':') && !waskanji ){
	    namepos = dp-directory+1;
	    namepos2= sp-buffer   +1;
	    lastroot=dp;
	  }
	  if( is_kanji(*sp) ){
	    waskanji = 1;
	  }else{
	    waskanji = 0;
	  }
	  *dp++ = *sp++;
	}
	*dp++ = '\0';
	
	if( lastroot != NULL ){
	  /* ���O�������R�s�[ */
	  sp = lastroot+1;
	  dp = name;
	  while( (*dp++ = *sp++) != '\0' )
	    ;
	  /* ���[�g�f�B���N�g���ł��x�Ⴊ�Ȃ��悤�ɁA
	   * '/'�̌���'.'��t���� */
	  *++lastroot = '.';
	  *++lastroot = '\0';
	}else{
	  namepos = 0;
	  namepos2= 0;
	  sp = directory;
	  dp = name;
	  while( (*dp++ = *sp++) != '\0' )
	    ;
	  directory[ 0 ] = '.';
	  directory[ 1 ] = '\0';
	}
	DIR *dirp=opendir(directory);
	if( dirp == NULL )
	  break;

	for(;;){
	  int nmatch=0;
	  struct dirent *dirbuf;
	  Shiel shiel;
	  
	  while( (dirbuf=readdir(dirp)) != NULL ){
	    if( (dirbuf->d_attr & A_DIR)==0 )
	      continue;
	    
	    char *p1,*p2;
	    for( p1=name,p2=dirbuf->d_name ; ; p1++,p2++){
	      if( *p1 == '\0' ){ /* ���̈���オ��B*/
		nmatch++;
		v_attrib(0x0E);
		shiel.putat( top+namepos2 , y0 , dirbuf->d_name );

		switch( ch=getkey(1) ){
		case '\t':        /* ���̌��� */
		  shiel.putoff();
		  goto next_koho;

		default:          /* �m�� */
		  shiel.putoff();
		  sp = dirbuf->d_name;
		  while( *sp != '\0' ){
		    if( is_kanji(*sp) ){
		      buffer[ namepos2   ] = *sp++;
		      atrbuf[ namepos2++ ] = KNJ1ST;
		      buffer[ namepos2   ] = *sp++;
		      atrbuf[ namepos2++ ] = KNJ2ND;
		    }else{
		      buffer[ namepos2   ] = *sp++;
		      atrbuf[ namepos2++ ] = ANK;
		    }
		  }
		  closedir(dirp);
		  
		  v_gotoxy( top , y0 );
		  v_attrib(ANSWER_COLOR);
		  v_putm( buffer , pos = len = namepos2 );
		  v_gotoxy( top+namepos2 , y0 );
		  
		  if( ch == '\r' )
		    goto exit_complete;
		  else
		    goto switch_ch;
		  
		case '\x1B':      /* �Ȃ��������Ƃ� */
		  shiel.putoff();
		  closedir(dirp);
		  goto exit_complete;
		}
	      }else if( toupper(*p1) != toupper(*p2) ){ /* ���ł͂Ȃ� */
		goto next_koho;
	      }
	    } /* end of for(�e����) */
	  next_koho:
	    ;
	  }/* end of while(readdir) */

	  /* �ȏ�ň���q�b�g���Ȃ��ꍇ�͔����邪�A
	   * �����Ȃ���΁A�����������B
	   */
	  if( nmatch == 0 ){
	    closedir(dirp);
	    break;
	  }
	  rewinddir(dirp);
	}/* for(;;) */
      }
    exit_complete:
      break;
      
    case '\b':
      if( pos <= 0 )
	break;
      
      if( atrbuf[ --pos ] == ANK ){
	v_backsp( 1 );
      }else{
	v_backsp( 2 );
	--pos ;
      }
      
      // continue to next case
      
    case CTRL('D'):
    case KEY(DEL):{
      
      if( pos >= len )
	break;
      
      int delsiz = ( atrbuf[ pos ] == ANK ? 1:2 );
      int i;
      for(i=pos; i<len-delsiz ; i++ ){
	buffer[ i ] = buffer[ i+delsiz ];
	atrbuf[ i ] = atrbuf[ i+delsiz ];
      }
      buffer[ i++ ] = ' '; // �����̏����p
      if( delsiz == 2 )
	buffer[ i++ ] = ' ';
      
      
      v_putm( buffer+pos , len-pos );
      len -= delsiz;
      
      break;
    }
    case CTRL('b'):
    case KEY(LEFT):
      if( pos > 0 ){
	if( atrbuf[ --pos ] != ANK )
	  --pos;
      }
      break;
      
    case CTRL('f'):
    case KEY(RIGHT):
      if( pos < len ){
	if( atrbuf[ pos++ ] != ANK )
	  ++pos;
      }
      break;
      
    case CTRL('a'):
    case KEY(HOME):
      pos = 0;
      break;
      
    case CTRL('e'):
    case KEY(END):
      pos = len;
      break;
      
    case CTRL('U'):
      v_gotoxy( top , y0 );
      v_putn( ' ',len );
      pos = len = 0;
      break;
      
    case CTRL('K'):
      v_putn( ' ',len-pos );
      len = pos;
      break;
      
    case CTRL('G'):
    case CTRL('['):
      buffer[ 0 ] = '\0' ;
      len = -1;
      goto exit;
      
    case '\r':
      buffer[ len ] = '\0';
      goto exit;
      
    } // end switch
  } // end for(;;)
  
 exit:
  v_hidecursor();
  v_putline( saveline , x0 , y0 , screen_width-x0 );
  return len;
}

