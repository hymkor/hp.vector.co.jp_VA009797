#include <alloca.h>
#include <ctype.h>
#include <string.h>
#include <stdlib.h>
#include <sys/video.h>
#include <sys/kbdscan.h>
#include "macros.h"

unsigned PROMPT_COLOR	= 0x0A ,ANSWER_COLOR	= 0x0F ;

int onekeybuffer=-1;

void ungetkey( int key )
{
  onekeybuffer = key;
}

int getkey( int wait ) /* wait != 0 : wait */
{
  int ch;

  if( onekeybuffer != -1 ){
    ch = onekeybuffer;
    onekeybuffer = -1;
  }else{
    ch = _read_kbd( 0 , wait , 0 );
  
    if( ch == 0 ){
      ch = (_read_kbd(0 , wait , 0) | 0x100);
    }
  }
  return ch;
}

int line_input(int x0,int y0,const char *prompt,char *buffer,size_t size )
{
  enum{ ANK , KNJ1ST , KNJ2ND };
  
  char *atrbuf = (char*)alloca( size );
  
  int top = x0+strlen(prompt);
  
  int screen_width,screen_height;
  v_dimen( &screen_width , &screen_height );
  
  char *saveline = (char *)alloca(2*(screen_width-x0));
  v_getline( saveline , x0 , y0 , screen_width-x0 );
  
  int max = size-1;
  
  v_attrib( ANSWER_COLOR );
  v_scroll( x0 , y0 , screen_width-1 , y0 , 1 , V_SCROLL_CLEAR );
  
  v_ctype( 0 , 16 );
  
  v_attrib( PROMPT_COLOR );
  v_gotoxy( x0 , y0 );
  v_puts( prompt );
	
  v_attrib( ANSWER_COLOR );
  
  int len=0;
  while(  buffer[ len ] != '\0'  ){
    if( is_kanji( buffer[ len ] ) ){
      atrbuf[ len++ ] = KNJ1ST;
      atrbuf[ len++ ] = KNJ2ND;
    }else{
      atrbuf[ len++ ] = ANK;
    }
  }
  if( len > 0 ){
    v_gotoxy( top , y0 );
    v_putm( buffer , len );
	}
  int pos=len;
  
  for(;;){
    v_gotoxy( top+pos , y0 );
    
    int ch=getkey(1);
    
    switch( ch ){
    default:
      if( is_kanji( ch ) ){
	if( len <= max-2 ){
	  for(int i=len-1 ; i>=pos ; i-- ){
	    buffer[ i+2 ] = buffer[ i ];
	    atrbuf[ i+2 ] = atrbuf[ i ];
	  }
	  buffer[ pos ] = ch;
	  atrbuf[ pos ] = KNJ1ST;
	  
	  buffer[ pos+1 ] = getkey(0);
	  atrbuf[ pos+1 ] = KNJ2ND;
	  
	  v_putm( &buffer[pos] , (len+=2)-pos );
	  pos+=2;
	}
      }else if( ch < 0x100  &&  isprint( ch ) ){
	if( len <= max-1 ){
	  for(int i=len ; i>= pos ; i-- ){
	    buffer[ i+1 ] = buffer[ i ];
	    atrbuf[ i+1 ] = atrbuf[ i ];
	  }
	  buffer[ pos ] = ch;
	  atrbuf[ pos ] = ANK;
	  
	  v_putm( &buffer[pos] , ++len-pos );
	  pos++;
	}
      }
      break;
      
    case '\b':
      if( pos <= 0 )
	break;
      
      if( atrbuf[ --pos ] == ANK ){
	v_backsp( 1 );
      }else{
	v_backsp( 2 );
	--pos ;
      }
			
      // continue to next case
      
    case CTRL('D'):
    case KEY(DEL):{
      
      if( pos >= len )
	break;
      
      int delsiz = ( atrbuf[ pos ] == ANK ? 1:2 );
      int i;
      for(i=pos; i<len-delsiz ; i++ ){
	buffer[ i ] = buffer[ i+delsiz ];
	atrbuf[ i ] = atrbuf[ i+delsiz ];
      }
      buffer[ i++ ] = ' '; // �����̏����p
      if( delsiz == 2 )
	buffer[ i++ ] = ' ';
      
      
      v_putm( buffer+pos , len-pos );
      len -= delsiz;
      
      break;
    }
    case CTRL('b'):
    case KEY(LEFT):
      if( pos > 0 ){
	if( atrbuf[ --pos ] != ANK )
	  --pos;
      }
      break;
      
    case CTRL('f'):
    case KEY(RIGHT):
      if( pos < len ){
	if( atrbuf[ pos++ ] != ANK )
	  ++pos;
      }
      break;
      
    case CTRL('a'):
    case KEY(HOME):
      pos = 0;
      break;
      
    case CTRL('e'):
    case KEY(END):
      pos = len;
      break;
      
    case CTRL('U'):
      v_gotoxy( top , y0 );
      v_putn( ' ',len );
      pos = len = 0;
      break;
      
    case CTRL('K'):
      v_putn( ' ',len-pos );
      len = pos;
      break;
      
    case CTRL('G'):
    case CTRL('['):
      buffer[ 0 ] = '\0' ;
      len = -1;
      goto exit;
      
    case '\r':
      buffer[ len ] = '\0';
      goto exit;
      
    } // end switch
  } // end for(;;)
  
 exit:
  v_hidecursor();
  v_putline( saveline , x0 , y0 , screen_width-x0 );
  return len;
}
