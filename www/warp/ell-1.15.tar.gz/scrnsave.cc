#include <stddef.h>
#include <sys/video.h>

#define INCL_VIO
#include <os2.h>

#include "scrnsave.h"

ScreenSave::ScreenSave( void )
{
  VioGetCurPos( &cursor_y, &cursor_x, 0);
  // v_getxy( &cursor_x , &cursor_y );
  v_getctype( &cursor_start , &cursor_end );
	
  v_dimen( &width , &height );
  screen = new char [ width*height*2 ];
  resave();
}
ScreenSave::~ScreenSave( void )
{
  restore();
  delete screen;
}

void ScreenSave::resave( void )
{
  if( screen != NULL ){
    v_getline(screen,0,0,width*height);
  }
  v_hidecursor();
  VioGetCurPos(&cursor_y, &cursor_x, 0 );
  // v_getxy( &cursor_x , &cursor_y );
}

void ScreenSave::restore( void )
{
  if( screen != NULL ){
    v_putline(screen,0,0,width*height);
  }
  v_ctype( cursor_start , cursor_end );
  v_gotoxy( cursor_x , cursor_y );
}
