#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <stdlib.h>
#include "tokenizer.h"

#undef DEBUG

/* �󔒂�ǂݔ�΂��B
 */
Tokenizer &Tokenizer::passSpace()
{
  for(;;){
    if( ! isOk() ){
      break;
    }
    if( ! isspace(lastchar & 255) )
      break;
    lastchar = read();
  }
  return *this;
}


/* ����̕�����ǂݔ�΂��B
 */
void Tokenizer::passChar(int ch)
     throw(Tokenizer::TooNearEof,Tokenizer::SyntaxError)
{
  passSpace();
  if( ! isOk() )
    throw TooNearEof();

  if( (lastchar & 255) != (ch & 255) )
    throw SyntaxError();

  lastchar = read();
}

int Tokenizer::readNumber()
{
  passSpace();
  int n=0;
  int minus=0;
  
  if( lastchar == '-' ){
    minus = 1;
    lastchar = read();
    passSpace();
  }

  if( lastchar == '0' ){
    /* 16�i�� */
    lastchar = read();
    if( lastchar == 'x' || lastchar == 'X' ){
      lastchar = read();

      for(;;){
	if( isdigit(lastchar & 255) ){
	  n = (n*16)+(lastchar-'0');
	}else if( 'a' <= lastchar && lastchar <= 'f' ){
	  n = (n*16)+10+(lastchar-'a');
	}else if( 'A' <= lastchar && lastchar <= 'F' ){
	  n = (n*16)+10+(lastchar-'A');
	}else{
	  break;
	}
	lastchar = read();
      }
    }else{
      /* 8�i�� */
      while( '0' <= lastchar && lastchar <= '7' ){
	n = (n*8) + (lastchar-'0');
	lastchar = read();
      }
    }
  }else{
    /* 10�i�� */
    while( isdigit(lastchar & 255) ){
      n = (n*10)+(lastchar-'0');
      lastchar = read();
    }
  }
  return minus ? -n : n ;
}


/* ���(�A���t�@�x�b�g������)��ǂݎ��B
 */
char *Tokenizer::readIdentifier(char *buffer,int size)
     throw(  Tokenizer::TooNearEof,Tokenizer::SyntaxError )
{
  passSpace();
  if( ! isOk() )
    throw TooNearEof();

  if( ! isalpha(lastchar) )
    throw SyntaxError();

  char *p=buffer;
  do{
    *p++ = lastchar;
    lastchar = read();
    /* �o�b�t�@�T�C�Y�ȏ�̒����̎��ʎq�̏ꍇ
     * �c����̂ĂāA�I������B*/
    if( --size <= 1 ){
      while( isOk()  && isalnum(lastchar & 255) )
	lastchar = read();
      break;
    }
  }while( isOk()  && isalnum(lastchar & 255) );
  *p = '\0';

#ifdef DEBUG
  fprintf(stderr,"found keyword /%s/.\n",buffer);
#endif

  return buffer;
}

/* �h�ň͂܂ꂽ�������ǂݎ��B
 */
char *Tokenizer::readQuoted(char *buffer,int size)
     throw(Tokenizer::TooNearEof,Tokenizer::SyntaxError)
{
  passSpace();
  if( ! isOk() )
    throw TooNearEof();

  if( lastchar != '"' )
    throw SyntaxError();
  
  char *p=buffer;
  while( isOk()  &&  (lastchar = read()) != '"' ){
    *p++ = lastchar;
    if( --size <= 1 ){
      for(;;){
	if( ! isOk() )
	  goto exit;
	if( (lastchar=read()) == '"' ){
	  lastchar=read(); // �|�C���^���h�̎��̕����ɂ��Ă����B
	  goto exit;
	}
	*p++ = lastchar;
      }
    }
  }
  if( lastchar == '"' )
    lastchar = read();
 exit:
  *p = '\0';
#ifdef DEBUG
  fprintf(stderr,"found quoted string '%s'.\n",buffer);
#endif
  return buffer;
}

