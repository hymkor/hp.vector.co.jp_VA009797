#include <assert.h>
#include <ctype.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "ziplist.h"
#include "tokenizer.h"

extern char *pager,*shell,*nkf;

/* �^����ꂽ�t�@�C�����A���̃A�[�J�C�u�`�����A�t�@�C���̓��������Č��؂���B
 * return
 *	 0 : ���̃A�[�J�C�u�^�ł���B
 *	 1 : ���̃A�[�J�C�u�^�ł͂Ȃ��B
 *	-1 : I/O �G���[�B
 */
int isFileThatArchive(const char *archive , ZipType *ziptype)
{
  // fputs("Enter isFileThatArchive\n",stderr);
  if( ziptype->keyword == NULL )
    return 0;

  FILE *fp=fopen(archive,"rb");
  if( fp == NULL ){
    // fputs("Leave isFileThatArchive(-1:open error)\n",stderr);
    return -1;
  }
  
  if( fseek( fp , ziptype->startAddress 
	    , ziptype->startAddress >= 0 
	    ? SEEK_SET
	    : SEEK_END ) != 0 ){
    fclose(fp);
    // fputs("Leave isFileThatArchive(-1)\n",stderr);
    return -1;
  }
  
  /* �擪�ꕶ�����Ƃɂ����T�� */
  for(int i=ziptype->startAddress ; i <= ziptype->endAddress ; i++ ){
    if( getc(fp) == (*ziptype->keyword & 255) ){
      int j=1;
      /* �񕶎��ڈȍ~���r */
      for(const char *p=ziptype->keyword+1 ; *p != '\0' ; p++ ){
	int lastchar=getc(fp);
	if( lastchar != (*p & 255) ){
	  /* �ق��Ă�����A�񕶎��ڂ̂Ƃ���܂ŁA
	   * �ǂݎ��ʒu��߂��Ă���A���[�v���ĊJ����B
	   */
	  if( j == 1 ){
	    ungetc( lastchar , fp );
	  }else{
	    fseek(fp, -j , SEEK_CUR );
	  }
	  goto next;
	}
	j++;
      }
      fclose(fp);
      return 0;
    }
  next:
    ;
  }
  fclose(fp);
  return 1;
}

enum{ errValue = -32768 };

ZipType *readini(const char *progName )
{
  // fprintf(stderr,"reading ell.cfg...");
  
  /* �������t�@�C���̖��O�𓾂� */
  char *errstr="Syntax Error";
  char configFileName[ FILENAME_MAX ];
  
  strncpy( configFileName , progName , sizeof(configFileName) );
  strcpy( _getext2(configFileName) , ".CFG" );
  
  FileTokenizer tzer(configFileName);
  ZipType *ziptype=NULL;

  try{
    /*
     * ----------- ��ԊO���̃��[�v (archive/run) ----------- 
     */

    while( tzer.passSpace() , tzer.isOk() ){
      char keyword[128];
      
      /* �R�}���h�ǂݎ�� ( pager | shell | run ���x�� ) */
      tzer.readIdentifier(keyword,sizeof(keyword));
      
      if( keyword[0] == 'p' && strcmp(keyword,"pager")==0 ){
	/* ------- pager�R�}���h -------- */

	tzer.readQuoted(keyword,sizeof(keyword));
	pager = strdup(keyword);
	tzer.passChar(';');

      }else if( keyword[0] == 's' && strcmp(keyword,"shell")==0 ){
	/* -------- shell�R�}���h ---------- */

	tzer.readQuoted(keyword,sizeof(keyword));
	shell = strdup(keyword);
	tzer.passChar(';');

      }else if( keyword[0] == 'n' && strcmp(keyword,"nkf")==0 ){
	/* -------- nkf �R�}���h ---------- */
	tzer.readQuoted(keyword,sizeof(keyword));
	nkf = strdup(keyword);
	tzer.passChar(';');

      }else if( keyword[0] == 'r' && strcmp(keyword,"run")==0 ){
	/* ----------- run�R�}���h ------------ */
	
	ZipType *tmp=new ZipType;
	tmp->next = ziptype;
	ziptype = tmp;
	
	char buffer[128];
	int nTypes=1;
	for(;;){
	  ziptype->islaunch = 1;
	  /* �^�C�v�� */
	  
	  tzer.readQuoted(buffer,sizeof(buffer));
	  
	  ziptype->suffix = strdup(buffer);
	  
	  if( *tzer.passSpace() == '=' )
	    break;

	  if( *tzer != ',' )
	    throw Tokenizer::SyntaxError();

	  tzer++;
	  nTypes++;
	  
	  ZipType *tmp=new ZipType;
	  tmp->next = ziptype;
	  ziptype = tmp;
	}
	tzer++;
	
	/* �����`���[�� */
	tzer.readQuoted(buffer,sizeof(buffer));
	
	ziptype->unpacker = strdup(buffer);
	ZipType *cur=ziptype->next;

	for(int i=1;i<nTypes;i++){
	  if( cur == NULL )
	    break;
	  
	  cur->unpacker = ziptype->unpacker;
	  cur = cur->next;
	}
	
	/* �u;�v��ǂݔ�΂� */
	tzer.passChar(';');
	
      }else if(   (keyword[0]=='a' && strcmp(keyword,"archive")==0)
	       || (keyword[0]=='i' && strcmp(keyword,"index")== 0 ) ){
	/*
	 * ----------- archive�� ------------
	 */
	
	ZipType *tmp=new ZipType;
	tmp->next = ziptype;
	ziptype = tmp;
	
	int nTypes=1;
	
	/* ----- archive ���̒���́A�g���q���X�g�̓ǂݎ�� ---- */
	for(;;){
	  /* �f�t�H���g�l�̐ݒ� */
	  ziptype->islaunch  = 0;
	  ziptype->unpacker  = "rem";
	  ziptype->killer    = "rem";
	  ziptype->lister    = NULL;
	  ziptype->header    = NULL;
	  ziptype->tailer    = NULL;
	  ziptype->linecount = 1;
	  ziptype->fnamepos  = 1;
	  ziptype->rootchar  = '\\';

	  ziptype->keyword   = NULL;
	  ziptype->startAddress  = 0;
	  ziptype->endAddress    = 0;
	  
	  if( keyword[0] == 'i' )
	    ziptype->isIndex = 1;
	  else
	    ziptype->isIndex = 0;
	  
	  /* �A�[�J�C�u�^�C�v��ǂݍ��� "*.zip" */
	  char buffer[128];
	  tzer.readQuoted(buffer,sizeof(buffer));
	  ziptype->suffix = strdup(buffer);
      
	  /* �g���q�̐��𐔂���B*/
	  ziptype->period = 1;
	  for( char *p=ziptype->suffix ; *p != '\0' ; p++ ){
	    if( *p=='.' )
	      ziptype->period++;
	  }
	
	  tzer.passSpace();
	  if( ! tzer.isOk() )
	    throw Tokenizer::TooNearEof();
	  
	  /* �L�[���[�h�I�v�V�����c "*.exe"( "PKZIP" , �c) �Ƃ����z */
	  if( *tzer == '(' ){
	    ++tzer;
	    tzer.passSpace().readQuoted(buffer,sizeof(buffer));
	    
	    ziptype->keyword = strdup(buffer);
	    tzer.passSpace();
	    
	    /* �����J�n�A�h���X�̐ݒ� */
	    if( *tzer == ',' ){
	      /* ��������Ă���ꍇ */
	      ++tzer;
	      tzer.passSpace();
	      if( ! isdigit(*tzer) && *tzer != '-' ){
		errstr="where is address ?";
		throw Tokenizer::SyntaxError();
	      }
	      ziptype->startAddress = tzer.readNumber();
	      
	      /* �����I���A�h���X */
	      if( *tzer.passSpace() == ',' ){
		tzer++;
		if( ! isdigit(*tzer) &&  *tzer != '-' )
		  throw Tokenizer::SyntaxError();
		ziptype->endAddress = tzer.readNumber();
		tzer.passSpace();
	      }else{
		ziptype->endAddress = ziptype->startAddress;
	      }
	    }else{
	      /* �ȗ���(�f�t�H���g=0) */
	      ziptype->startAddress = ziptype->endAddress = 0;
	    }
	    if( *tzer != ')' )
	      throw Tokenizer::SyntaxError();
	    
	    ++tzer;
	    tzer.passSpace();
	  }else{
	    ziptype->keyword = NULL;
	    ziptype->startAddress = ziptype->endAddress = 0;
	  }
	
	  if( *tzer == '{' )
	    break;
	  
	  if( *tzer != ',' )
	    throw Tokenizer::SyntaxError();
	  
	  ++tzer;
	  nTypes++;

	  ZipType *tmp=new ZipType(*ziptype);
	  tmp->next = ziptype;
	  ziptype = tmp;
	}
	tzer++; /* �u{�v�̓ǂ݂Ƃ΂� */

	/* archive���� {...} ������ǂ� */
	for(;;){
	  tzer.passSpace();
	  
	  int firstchar=*tzer;
	  if( firstchar == '}' )
	    break;
	  
	  char command[128],value[128],*strValue;
	  int numValue=errValue;
	  
	  /* ���Ӓl�𓾂� */
	  tzer.readIdentifier(command,sizeof(command));
	  
	  /* �u=�v��ǂݔ�΂� */
	  tzer.passChar('=');
	  tzer.passSpace();
	  
	  /* �E�Ӓl�𓾂� */
	  if( *tzer == '"' ){
	    tzer.readQuoted(value,sizeof(value));
	    strValue = strdup(value);
	    numValue = errValue;
	  }else if( isdigit(*tzer) || *tzer == '-' ){
	    strValue = NULL;
	    numValue = tzer.readNumber();
	  }else{
	    throw Tokenizer::SyntaxError();
	  }
	  
	  /* ���Ӓl�̓��e�ɂ���āA���򂷂� */
	  switch( firstchar ){
	  default:
	    throw Tokenizer::SyntaxError();
	  
	  case 'f': /* fnamepos */
	    if( strcmp(command,"fnamepos") == 0 && numValue != errValue )
	      ziptype->fnamepos = numValue;
	    else
	      throw Tokenizer::SyntaxError();
	    break;

	  case 'l': /* linecount or list */
	    if( strcmp(command,"linecount") == 0 && numValue != errValue )
	      ziptype->linecount = numValue;
	    else if( strcmp(command,"list") == 0 && strValue != NULL )
	      ziptype->lister = strValue;
	    else
	      throw Tokenizer::SyntaxError();
	    break;

	  case 'r': /* rootchar */
	    if( strcmp(command,"rootchar") == 0 && strValue != NULL )
	      ziptype->rootchar = *strValue;
	    else
	      throw Tokenizer::SyntaxError();
	    break;
	  
	  case 'e': /* extract  or  end */
	    if( strcmp(command,"extract") == 0  &&  strValue != NULL )
	      ziptype->unpacker = strValue;
	    else if( strcmp(command,"end") == 0 && strValue != NULL )
	      ziptype->tailer = strValue;
	    else
	      throw Tokenizer::SyntaxError();
	    break;

	  case 'j': /* extract2 (drop path) */
	    if( strcmp(command,"junk") == 0  &&  strValue != NULL )
	      ziptype->junk_unpacker = strValue;
	    else
	      throw Tokenizer::SyntaxError();
	    break;
	    
	  case 'p': /* printer */
	    if( strcmp(command,"print") == 0 && strValue != NULL )
	      ziptype->printer = strValue;
	    else
	      throw Tokenizer::SyntaxError();
	    break;
	    
	  case 'd': /* delete */
	    if( strcmp(command,"delete") == 0 && strValue != NULL )
	      ziptype->killer = strValue;
	    else
	      throw Tokenizer::SyntaxError();
	    break;
	    
	  case 's': /* start */
	    if( strcmp(command,"start") == 0  &&  strValue != NULL )
	      ziptype->header = strValue;
	    else
	      throw Tokenizer::SyntaxError();
	    break;
	  }
	  
	  /* �������u,�v�Ȃ�p�� �u}�v�Ȃ� archive �����I�� */
	  tzer.passSpace();
	  if( !tzer.isOk() )
	    throw Tokenizer::TooNearEof();
	  if( *tzer == '}' )
	    break;
	  if( *tzer != ',' )
	    throw Tokenizer::SyntaxError();
	  tzer++;
	}
	++tzer; /* �u}�v��ǂݔ�΂� */
	
	if( ziptype->lister == NULL ){
	  fprintf(stderr,"%s : "
		  "�^�C�v'%s'�� �{�����@����`����Ă��܂���B\n"
		  , configFileName , ziptype->suffix );
	  return 0;
	}
	
	ZipType *cur=ziptype->next;
	for(int i=1;i<nTypes;i++){
	  if( cur == NULL )
	    break;

	  cur->copy_from( *ziptype );
	  cur = cur->next;
	}

      }else{
	throw Tokenizer::SyntaxError();
      }
    }
  }catch(Tokenizer::TooNearEof){
    fprintf(  stderr
	    , "%s(%d) : Too near EOF\n"
	    , configFileName
	    , tzer.getLineNumber() );
    return 0;
  }catch(Tokenizer::SyntaxError e){
    fprintf(  stderr
	    , "%s(%d) : %s\n"
	    , configFileName 
	    , tzer.getLineNumber() 
	    , e.getErrMsg("Syntax Error") );
    return 0;
  }catch(...){
    fprintf(stderr,"Unexpected Exception Sorry!\n");
    return 0;
  }
  return ziptype;
}

void unexpected()
{
  fputs("\neff: fatal error. Unexpected exception is thrown.\n",stderr);
  exit(1);
}
