/* -*- c++ -*- */
#ifndef ZIPWIN_H
#define ZIPWIN_H

#include "ziplist.h"
#undef COMMENT_HEAD
#undef COMMENT_TAIL

int getkey(int wait);		/* wait != 0 : wait */
void ungetkey(int key);
int line_input(int x0, int y0, const char *prompt, char *buffer, size_t size);
int path_input(int x0, int y0, const char *prompt, char *buffer, size_t size);

typedef const char (*framechar_t)[4];
framechar_t getframechar( void );
void v_frameline(int x, int y, int w, const char *frame);

class ZipWindow
{
  ZipType *ziptype;
  ZipList *heaven, *earth, *hell, *cursor;
  int files_per_win;
  int csrlin;
  int column_offset; /* �\�����ǂꂾ���E�ɂ��炷���c */
  enum {  ERROR, CLOSE, OPEN, CSRON   } status;

  int width, height;		/* ��ʑS�̂̌����ƍs�� */
  int x1, y1, x2, y2;		/* �X�N���[��������͈� */

  int forward(void);		/* ��ʂ��X�V�����ɑO���ړ� */
  int backward(void);		/*               ����ړ� */
  char searchstr[256];
  int direct;

public:
  int  getkey();
  void search_forward(void);
  void search_backward(void);

  void search_first(int dir);
  void search_next(int reverse);

  void print_lnum(void);
  void repaint(void);
  void open(void);
  void cursor_on(void);
  void cursor_off(void);
  int next(void);
  void next_page(void);
  int prev(void);
  void prev_page(void);
  void first(void);
  void last(void);
  void del(void);
  void undel(void);
  void undel_all(void);

  void repaint_csrlin(void)
    {    cursor->draw(y1 + csrlin * ziptype->linecount);  }
  ZipList *operator->(void)
    {    return cursor;  }
  int operator ! (void) const
    {    return status == ERROR;  }
  operator const void *(void) const
    {    return status == ERROR ? NULL : this;  }
  void marking(void);

  int is_filer_mode(void) const
    { return ziptype->isIndex; }
  
  const ZipType *get_type(void) const
    { return ziptype;  }
  const char *get_fname(void) const
    {  return ZipList::get_arcname();  }
  const char *get_cursor_name(void) const
    {    return cursor->get_name();  }
  void init(const char *fname, const char *title=NULL);
  ZipWindow(const char *fname, const char *title=NULL)
    { init(fname,title); }

  void shift(int n){
    column_offset += n; 
    if( column_offset < 0 )
      column_offset = 0;
    repaint();
  }
  int getShift() const
    {   return column_offset;  }
};
#endif
