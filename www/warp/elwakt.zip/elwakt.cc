#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define numof(A) (sizeof(A)/sizeof((A)[0]))

/* elwakt -- PDB-Plugin for ELL
 *
 * elwakt v �sPDB�t�@�C�����t
 * elwakt p �sPDB�t�@�C�����t �sUID�t
 */

/* --- memo ---
 *
 * PDB�t�@�C��
 *	- header(78bytes)
 *		+ 52to55 app_info(�J�e�S���[���)
 *		+ 56to59 sort_info(�\�[�g���)
 *		+ 76to77  ���R�[�h����
 *	- record entry header * RECORD(8 bytes/RECORD)
 *		+ 0to3  ���R�[�h�̈ʒu
 *		+ 4     ����
 *			bit7 Delete	bit6 Dirty
 *			bit5 Busy	bit4 Secret
 *			bit3�`0 �A��
 *		+ 3to7  UNIQUE-ID
 *	- empty(2bytes)
 *	- app_info
 *		+ �ύX�r�b�g(2bytes)
 *		+ �J�e�S��(15bytes+NUL)*15��
 *		
 *	- sort_info
 *	- record
 *
 */

class UnexpectedEOF { };

unsigned long getCforPDB(FILE *fp) throw(UnexpectedEOF)
{
  int ch=getc(fp);
  if( ch==EOF ) throw UnexpectedEOF();
  return ch;
}

unsigned long getWforPDB(FILE *fp) throw(UnexpectedEOF)
{
  unsigned char buf[2];
  if( feof(fp) || fread( buf , 1 , sizeof(buf) , fp ) < sizeof(buf) )
    throw UnexpectedEOF();
  return (buf[0]<<8) | (buf[1] & 255 );
}

unsigned long getQforPDB(FILE *fp) throw(UnexpectedEOF)
{
  unsigned char buf[4];
  if( feof(fp) || fread( buf , 1 , sizeof(buf) , fp ) < sizeof(buf) )
    throw UnexpectedEOF();
  return (buf[0]<<24) | (buf[1]<<16) | (buf[2]<<8) | buf[3];
}

/* PDB�t�@�C���̂P���R�[�h�G���g�����Ǘ�����N���X
 */
class RecordEntry {
  unsigned long position;
  unsigned long attrib;
  
  enum{
    DELETED = 0x80000000 ,
    DIRTY   = 0x40000000 ,
    BUSY    = 0x20000000 ,
    SECRET  = 0x10000000 ,

    CATEGORY= 0x0F000000 ,
    UID     = 0x00FFFFFF ,
  };
      
public:
  bool isDeleted() const { return attrib & DELETED; }
  bool isDirty()   const { return attrib & DIRTY;   }
  bool isBusy()    const { return attrib & BUSY;    }
  bool isSecret()  const { return attrib & SECRET;  }

  unsigned long getCategory() const { return (attrib & CATEGORY) >> 24; }
  unsigned long getUID()      const { return attrib & UID; }
  unsigned long getPos()      const { return position; }

  RecordEntry(){}
  ~RecordEntry(){}

  /* read
   * 
   * PDB�t�@�C���̑S�Ẵ��R�[�h�G���g����ǂݏo���āA
   * RecordEntry�^�̔z��Ƃ��ĕԂ��ÓI���\�b�h�B
   *
   * �A��l�̔z��́A�g�p���ς񂾂�Adelete[] ����K�v������B
   */

  /* read(1) 
   *
   * ���݂̃t�@�C���ǂݏo���ʒu���烌�R�[�h�G���g����
   * ����ł���Ɖ��肵�Ă���o�[�W�����B
   * ���R�[�h�G���g�����́A���� n �ŗ^���Ă��K�v������B
   *
   *	n  (in)	���R�[�h�G���g����
   *	fp (in)	PDB�t�@�C���̃t�@�C���|�C���^
   */
  static RecordEntry *read(int n,FILE *fp){
    RecordEntry *buf=new RecordEntry[n];
    if( buf==0 )
      return 0;

    for(int i=0;i<n;i++){
      buf[i].position = getQforPDB(fp);
      buf[i].attrib   = getQforPDB(fp);
    }
    return buf;
  }

  /* read(2)
   *
   * ���R�[�h�G���g���̈ʒu�܂ŁA�t�@�C���ǂ݈ʒu��
   * �ړ������āA��O����ɕK�v�Ȑ��̃��R�[�h�G���g��
   * ��ǂݏo���o�[�W�����B
   *
   *	fp  (in) PDB�t�@�C���̃t�@�C���|�C���^
   *	*n (out) ���R�[�h�G���g���̐�
   */

  static RecordEntry *read(FILE *fp,int *n=NULL){
    if( n != NULL ){
      fseek(fp,76,SEEK_SET);
      *n = getWforPDB(fp);
    }else{
      fseek(fp,78,SEEK_SET);
    }
    return RecordEntry::read(*n,fp);
  }
};

/* �S�J�e�S���[���Ǘ�����N���X
 */
class Category{
  char category[16][16];
public:
  const char *operator[] (int n){
    return category[n];
  }

  void read(FILE *fp) throw(UnexpectedEOF) {
    (void)getw(fp);
    if( fread( category , 1 , sizeof(category) , fp ) < sizeof(category) )
      throw UnexpectedEOF();
  }

  int getMaxLength() const {
    int length=0;
    for(int i=0;i<16;i++){
      int len=strlen(category[i]);
      if( len > length )
	length = len;
    }
    return length;
  }

  Category(){}
  Category(FILE *fp){ read(fp); }
  ~Category(){}
};

enum PDBType {
  PDB_UNKNOWN ,
  PDB_MEMOPAD ,
  PDB_TODO ,
  PDB_ADDRESS ,
};

PDBType whichPdb( const char *path )
{
  const char *name=_getname(path);
  
  if( stricmp(name,"MemoDB") == 0 )
    return PDB_MEMOPAD;
  else if( stricmp(name,"ToDoDB") == 0 )
    return PDB_TODO;
  else if( stricmp(name,"AddressDB") == 0 )
    return PDB_ADDRESS;
  else
    return PDB_UNKNOWN;
}

PDBType whichPdb( FILE *fp )
{
  char buffer[16];
  int ch;

  for(int i=0;i<sizeof(buffer);i++){
    if( (ch=getc(fp))==EOF )
      return PDB_UNKNOWN;
    
    if( ch==0 ){
      buffer[i]='\0';
      break;
    }
    buffer[i] = ch;
  }
  return whichPdb( buffer );
}


/* ���݂̃t�@�C���ǂݏo���ʒu���A'\0'�܂ł�S�ĕW���o�͂ɓf���B
 */
static int print_until_zero(FILE *fp)
{
  int ch;
  while( (ch=getc(fp)) !='\0' && ch != EOF )
    putchar(ch & 255);
  return ch;
}

static int print_until_zero_without_yomi(FILE *fp)
{
  int ch;
  while( (ch=getc(fp)) != '\0' && ch != EOF ){
    if( ch == 1 ){
      while( (ch=getc(fp)) != '\0' && ch != EOF )
	;
      return ch;
    }
    putchar( ch & 255 );
  }
  return ch;
}

static int print_until_zero_with_yomi(FILE *fp,const char *pre,const char *post)
{
  int ch;
  while( (ch=getc(fp)) != '\0' && ch != EOF ){
    if( ch == 1 ){
      fputs(pre,stdout);
      while( (ch=getc(fp)) != '\0' && ch != EOF )
	putchar(ch & 255);
      fputs(post,stdout);
      return ch;
    }
    putchar( ch & 255 );
  }
  return ch;
}

/* ���݂̃t�@�C���ǂݏo���ʒu���A���s��'\0'�܂ł�S�ĕW���o�͂ɓf���B
 */
static int print_1_line(FILE *fp)
{
  int ch;
  while( (ch=getc(fp)) !='\0' && ch != EOF && ch != '\n' )
    putchar(ch & 255);
  return ch;
}

int main(int argc,char **argv)
{
  if( argc < 3 ){
    fputs("elwakt -- PDB-Plugin for ELL\n"
	  "usage:\n"
	  "       elwakt v MemoDB.pdb\n"
	  "   or  elwakt p MemoDB.pdb UID\n" , stderr );
    return -1;
  }

  if( argv[1][0] == 'v' ){
    /* �ꗗ�\�� */
    FILE *fp=fopen(argv[2],"rb");
    if( fp == NULL ){
      perror(argv[2]);
      return 1;
    }
    PDBType pdbtype=whichPdb( fp );
    if( pdbtype == PDB_UNKNOWN ){
      fprintf(stderr,"%s: unsupport type .pdb file\n",argv[0]);
      return -1;
    }

    RecordEntry *recEntry=0;
    try{
      int nRecords;
      recEntry=RecordEntry::read(fp,&nRecords);
      if( recEntry != NULL ){
	Category category(fp);
	
	int category_space = category.getMaxLength();
      
	for(int i=0;i<nRecords;i++){
	  printf("%c%c%c%c %06X (%-*s) "
		 , recEntry[i].isDeleted() ? 'D' : '-'
		 , recEntry[i].isDirty()   ? 'X' : '-'
		 , recEntry[i].isBusy()    ? 'B' : '-'
		 , recEntry[i].isSecret()  ? 'S' : '-'
		 , recEntry[i].getUID()
		 , (unsigned int)category_space
		 , category[ recEntry[i].getCategory() ]
		 );
	  
	  fseek( fp , recEntry[i].getPos() , SEEK_SET);
	  switch( pdbtype ){
	  case PDB_MEMOPAD:
	    print_1_line(fp);
	    putchar('\n');
	    break;
	    
	  case PDB_TODO:
	    {
	      unsigned date = getWforPDB(fp);
	      if( date == 0xFFFF ){
		printf("           ");
	      }else{
		printf("%4d/%2d/%2d "
		       , 1904 + ((date >> 9) & 127)
		       , (date >> 5 ) & 15
		       ,  date & 31  );
	      }
	      int kanryo=getc(fp);
	      printf("[%c] %1d "
		     , ( kanryo & 128 ) ? 'x' : ' '
		     , ( kanryo & 127 ) );
	      if( print_1_line(fp) != EOF &&  getc(fp) != '\0' )
		puts(" [Note]");
	      else
		putchar('\n');
	    }
	    break;
	    
	  case PDB_ADDRESS:
	    {
	      (void)getQforPDB(fp);
	      (void)getQforPDB(fp);
	      (void)getCforPDB(fp);
	      if( print_until_zero_without_yomi(fp) != EOF ){
		putchar(' ');
		print_until_zero_without_yomi(fp);
	      }
	      putchar('\n');
	    }
	    break;
	  
	  default:
	    ;
	  }
	}
	delete [] recEntry;
      } /* if recEntry != NULL */
    }catch( UnexpectedEOF ){
      delete [] recEntry;
      fprintf(stderr,
	      "%s: %s: Unexpected EOF."
	      "File may be broken or program has bugs.\n"
	      , argv[0],argv[2]);
    }
    fclose(fp);
  }else if( argv[1][0] == 'p' ){
    if( argc < 4 ){
      fprintf(stderr,"%s: -p option needs UID.\n",argv[0]);
      return 0;
    }
      
    FILE *fp=fopen(argv[2],"rb");
    if( fp == NULL ){
      perror(argv[2]);
      return 1;
    }

    PDBType pdbtype=whichPdb( fp );
    if( pdbtype == PDB_UNKNOWN ){
      fprintf(stderr,"%s: unsupport type .pdb file\n",argv[0]);
      return -1;
    }

    RecordEntry *recEntry=0;
    try{
      unsigned long uid = strtoul(argv[3],NULL,16);
      int nRecords;
      recEntry=RecordEntry::read(fp,&nRecords);
      if( recEntry != NULL ){
	for(int i=0;i<nRecords;i++){
	  if( recEntry[i].getUID() == uid ){
	    fseek( fp , recEntry[i].getPos(), SEEK_SET);
	    
	    switch( pdbtype ){
	    case PDB_MEMOPAD:
	      print_until_zero(fp);
	      goto exit_p;
	      
	    case PDB_TODO:
	      (void)getWforPDB(fp);
	      (void)getc(fp);
	      
	      putchar('[');
	      print_until_zero(fp) ;
	      puts("]");
	      if( ! feof(fp) )
		print_until_zero(fp);
	      goto exit_p;
	      
	    case PDB_ADDRESS:
	      {
		const static char *contents_name[]={
		  "��","��","��Ж�",0,0,0,0,0,
		  "�Z��","�s����","�s���{��","�X�֔ԍ�","��","��E",
		  "Custom1","Custom2","Custom3","Custom4","        \n",
		};
		const static char *phone_name[]={
		  "���","����" , "Fax","���̑�",
		  "E-Mail","��\\ ","�|�P�x��","�g��",
		};
		unsigned long phone = getQforPDB(fp);
		unsigned long contents=getQforPDB(fp);
		(void)getCforPDB(fp);
		
		for(int i=0;i<numof(contents_name);i++){
		  if( contents & 1 ){
		    if( contents_name[i] != 0 ){
		      printf("%-9s",contents_name[i]);
		    }else{
		      printf("%-9s",phone_name[ phone & 15 ] );
		    }
		    print_until_zero_with_yomi(fp,"\n (�ǂ�)  ","");
		    putchar('\n');
		  }
		  if( contents_name[i] == 0 )
		    phone >>= 4;
		  contents >>= 1;
		}
	      }
	      goto exit_p;
	      
	    default:
	      ;
	    }
	  }
	} // for loop
	fprintf(stderr,"%s: %06lX: no such UID.\n",argv[0],uid);
      }else{
	fprintf(stderr,"%s: memory allocation error\n",argv[0]);
      }
    }catch(UnexpectedEOF){
      ;
    }
  exit_p:
    delete [] recEntry;
    fclose(fp);
    return 0;
  }else{
    fprintf(stderr,"%s: %s: unsupported command\n",argv[0],argv[1]);
  }
  return 0;
}




