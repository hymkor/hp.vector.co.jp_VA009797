#undef DEBUG
#include <assert.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <signal.h>
#include <sys/ptrace.h>

#include "macros.h"
#include "leszbuf.h"
#include "sem.h"
#include "strbuffer.h"
#include "os2eff.h"

#ifdef DEBUG
#  define DEBUG1(x) (x)
#else
#  define DEBUG1(x)
#endif

static Sem hmtx;

Buffer::NomemoMode Buffer::defaultNomemoMode=Buffer::UNKNOWN_NOMEMO;
bool Buffer::rawmode=true;
bool Buffer::nobsmode=false ;
bool Buffer::crlf_arrow_mode=false ;

unsigned Buffer::TEXT_COLOR     = 0x0F;
unsigned Buffer::CTRL_COLOR     = 0x0E;
unsigned Buffer::TITLE_COLOR    = 0x70;
unsigned Buffer::REV_CTRL_COLOR = 0xE1;
unsigned Buffer::UL_COLOR       = 0x0A;
unsigned Buffer::BOLD_COLOR     = 0x0C;

/* ���X���b�h�������Ă���� true�B�I�����Ă�����Afalse ��Ԃ��B
 * �����A�N�Z�X�����肦��̂ŁA�Z�}�t�H���Ă���B
 */
bool Buffer::isThreadAlive() const 
{
  hmtx.request();
  bool rc=threadLife;
  hmtx.release();
  return rc;
}

/* �t�@�C����ǂޗ��X���b�h
 * Buffer::beginBackgroundThread() ����̂݌Ăяo�����B
 */
void Buffer::backGroundThread( void *_buf )
{
  Buffer *buf=(Buffer*)_buf;
  
  for(;;){
    hmtx.request();
    if(   buf->status  == Buffer::ENDOFFILE
       || buf->threadLife == Buffer::KILL_THREAD ){
      buf->threadLife = Buffer::THREAD_IS_DEAD;
      hmtx.release();
      return;
    }
    hmtx.release();
    sleep(0);
    if( buf->readline() == false ){
      hmtx.request();
      buf->threadLife = Buffer::THREAD_IS_DEAD;
      hmtx.release();
      return;
    }
    sleep(0);
  }
}

/* �t�@�C����ǂޗ��X���b�h���N�����郁�\�b�h
 * return value �X���b�h�h�c(-1 : ���s)
 */
int Buffer::beginBackgroundThread()
{
  static bool firstCall=true;
  if( firstCall ){
    int rc=hmtx.create();
    if( rc ){
      fprintf(stderr , "cannot make new thread(errno=%d)\n",rc);
      exit(1);
    }
    firstCall = false;
  }
  threadLife = THREAD_IS_ALIVE;
  return tid=_beginthread( &Buffer::backGroundThread , NULL , 64000u , this );
}

class TooNearEOF { };

static int getC(FILE *fp, StrBuffer &buf ) throw( TooNearEOF )
{
  if( feof(fp) )
    throw TooNearEOF();

  int ch=fgetc(fp);
  if( ch == EOF )
    throw TooNearEOF();

  buf << (char)ch;
  return ch & 255;
}

/* �t�@�C������1byte�A�ǂݏo���B
 *	- 2bytes �����񂪌���ꂽ�ꍇ�́AShiftJIS�ɕϊ������`��1��������
 *	  �o�͂���BEUC �� SJIS ���s���Ȏ��́A������܂Ő�ǂ݂���B
 */
int Buffer::readc( void ) throw()
{
  int ch;
  if( presiz > 0 ){
    return prebuf[--presiz] & 255;
  }else if( nkfcnt >= 0 ){
    ch = nkfbuf[ nkfcnt ] & 255;
    if( ++nkfcnt >= nkfbuf.getLength() ){
      nkfcnt = -1;
      nkfbuf.drop();
    }
    return ch & 255;
  }

  assert( presiz == 0 );
  assert( filptr != NULL );
  if( feof((FILE*)filptr) )
    return EOF;
  
  ch = fgetc( filptr );
  if( ch == EOF )
    return EOF;

  /* ���p���[�h�Ȃ�A���̂܂ܕԂ� */
  if( eucmode != UNKNOWN  ||  (ch & 128)==0 )
    return ch & 255;
  
  /* EUC ���[�h�� SJIS ���𔻒肷�� */

  try{
    for(int c=ch ;;){
      if( ( 129 <= c && c <= 141) || (143 <= c  && c <=159 )){
	eucmode = SJISMODE;
	break;
      }
      if( c == 142 ){
	c = getC( filptr , nkfbuf );
	if(   ( c >= 64  && c <= 126 ) 
	   || ( c >= 128 && c <= 160 )
	   || ( c >= 224 && c <= 252 ) ){
	  eucmode = SJISMODE;
	  break;
	}
	/* [161,223]�ł͕s���ɂȂ�炵�� */
	c = getC(filptr,nkfbuf);
	continue;
      }
      if( 161 <= c && c <= 223 ){
	c = getC( filptr ,nkfbuf);
	if( c >= 240 && c <= 254 ){
	  eucmode = EUCMODE;
	  break;
	}
	if( c >= 161 && c <= 223 ){
	  c = getC(filptr,nkfbuf);
	  continue;
	}
	if( c <= 159 ){
	  eucmode = SJISMODE;
	  break;
	}
	if( c >= 240 && c <= 254 ){
	  eucmode = EUCMODE;
	  break;
	}
	if( c >= 224 && c <= 239 ){
	  while( c >= 64 ){
	    if( c >= 129 ){
	      if( c <= 141 || ( c >= 143 && c <= 159 ) ){
		eucmode = SJISMODE;
		goto exit;
	      }else if( c >= 253 && c <= 254 ){
		eucmode = EUCMODE;
		goto exit;
	      }
	    }
	    c = getC(filptr,nkfbuf);
	  }
	  c = getC(filptr,nkfbuf);
	  continue;
	}
	if( c >= 224 &&  c <= 239 ){
	  c = getC(filptr,nkfbuf);
	  if( ( c>=64 && c <= 126) || (c>=128 && c<=160 ) ){
	    eucmode = SJISMODE;
	    break;
	  }
	  if(   ( c>=253 && c <= 254 )
	     || ( c>=128 && c <= 160 ) ){
	    eucmode = EUCMODE;
	    break;
	  }
	}
      }
      c = getC(filptr,nkfbuf);
    } /* for(;;) */
  }catch(TooNearEOF){
    eucmode = SJISMODE;
  }
 exit:
  if( nkfbuf.getLength() > 0 )
    nkfcnt = 0;
  return ch & 255;
}

void Buffer::unreadc( int ch )
{
  assert( presiz < numof(prebuf) );
  prebuf[ presiz++ ] = ch & 255;
}

/* euc2sjis �n�֐��̉������֐�
 * EUC �̊��������� 2bytes �� SJIS �� 2bytes �ɒu���A��B
 * 2bytes �R�[�h�łȂ��ꍇ�̓���͖���`
 * 
 * in	c1 EUC��� 1byte
 *	c2 EUC���� 1byte
 * out	jms_c1 SJIS��� 1byte
 *	jms_c2 SJIS���� 1byte (���p�J�i�̏ꍇ�A������Ȃ�)
 * return
 *	1 : ���p�J�i
 *	2 : ����ȊO
 */
static int euc2sjis_oneword(int c1,int c2,char &jms_c1,char &jms_c2)
{
  if( (c1 & 255) == 0x8E ){
    jms_c1 = c2;
    return 1;
  }
  c1 &= 0x7F;c2 &= 0x7F;

  if( c1 & 1 ){
    c1 = (c1 >> 1 ) + 0x71;
    c2 += 0x1f;
    if( c2 >= 0x7f )
      c2++;
  }else{
    c1 = (c1 >> 1 ) + 0x70;
    c2 += 0x7e;
  }
  if( c1 > 0x9F )
    c1 += 0x40;
  
  jms_c1 = c1;
  jms_c2 = c2;
  return 2;
}

bool Buffer::readline()
{
  hmtx.request();
  int nbackspace=0;
	
  if( status != GOOD ){
    DEBUG1(fprintf(stderr,"(Buffer::readline) status != GOOD\n"));
    hmtx.release();
    return false;
  }
  Line *newlast = (Line *)sbrk.alloc( sizeof( Line )+width*2-2 );
	
  if( newlast == NULL ){
    DEBUG1(fprintf(stderr,"(Buffer::readline) sbrk.alloc failed.\n"));
    hmtx.release();
    return false;
  }
	
  newlast->len = 0 ;
  newlast->prev = newlast->next = 0;
  unsigned char *ptr = newlast->buffer;
  
  while(  status==GOOD  &&  newlast->len < width ){
    int ch;
    switch( ch = readc() ){
      
    case '\t':
      do{
	*ptr++ = ' ';
	*ptr++ = TEXT_COLOR;
	newlast->len++;
	
	if( newlast->len >= width )
	  goto EndOfLine;
      }while( newlast->len % 8 !=0 );
      
      break;
      
    case '\n':
      if( crlf_arrow_mode ){
	/* ���s�}�[�N�\�����[�h�Ȃ�΁A�f���ɉ��s�}�[�N��\�����ďI��� */
	*ptr++ = 0x1B;
	*ptr++ = CTRL_COLOR;
	newlast->len++;
      }
      goto EndOfLine;
      
    case EOF:
      DEBUG1(fprintf(stderr,"EOF found line number==%d.\n"
		     , 1+nlines));

      *ptr++ = ' ';
      *ptr++ = REV_CTRL_COLOR;
      newlast->len++;
      
      status = ENDOFFILE;
      this->close();
      
      goto EndOfLine;
      
    case '\b':
      if( !nobsmode  &&  newlast->len > 0 ){
	ptr -= 2;
	newlast->len--;
	nbackspace++;
      }else{
	goto Default;
      }
      break;
      
    case '\x1B':
      if( (ch=readc())=='$' ){ /* KANJI-ON */
	if( (ch=readc())=='B' || ch=='@'){
	  jismode = true;
	  hasJisCode = true;
	  break;
	}else{
	  unreadc(ch);
	  unreadc('$');
	}
      }else if( ch=='(' ){	/* KANJI-OFF */
	if( (ch=readc())=='J' || ch=='B'){
	  jismode = false;
	  break;
	}else{
	  unreadc(ch);
	  unreadc('(');
	}
      }else{
	unreadc(ch);
      }
      ch = '\x1B';
      goto Default;
      
    case '\r':
      if( (ch=readc()) == '\n' ){ // CR+LF --> LF
	if( crlf_arrow_mode ){
	  *ptr++ = 0x1B;
	  *ptr++ = CTRL_COLOR;
	  newlast->len++;
	}
	goto EndOfLine;
      }else{						// CR only --> ^M
	unreadc( ch );
	ch = '\r';
	/* continue to next case */
      }
      
    default:Default:
      if( rawmode ? ch==0 : ch < ' ' ){	/* �R���g���[���R�[�h */
	
	if( width - newlast->len <= 1 ){
	  unreadc( ch );
	  *ptr++ = '-';
	  *ptr++ = CTRL_COLOR;
	  newlast->len++;
	  
	  goto EndOfLine;
	}
	*ptr++ = '^';
	*ptr++ = CTRL_COLOR;
	
	*ptr++ = '@'+ch;
	*ptr++ = TEXT_COLOR;
	
	newlast->len += 2;
	break;
	
      } else if( ch >= 128  &&  eucmode == EUCMODE ){ /* EUC ���� */
	char jms[2] , nextchar;
	
	if( euc2sjis_oneword(ch,nextchar=readc(),jms[0],jms[1]) == 1 ){
	  /* ���p�J�i */
	  *ptr++ = jms[0];
	  *ptr++ = TEXT_COLOR;
	  newlast->len++;
	  break;
	}else{
	  /* �S�p */
	  if( width - newlast->len <= 1 ){
	    unreadc(nextchar);
	    unreadc(ch);
	    *ptr++ = '-';
	    *ptr++ = CTRL_COLOR;
	    newlast->len++;
	    goto EndOfLine;
	  }
	  *ptr++ = jms[0];
	  *ptr++ = TEXT_COLOR;
	  *ptr++ = jms[1];
	  *ptr++ = TEXT_COLOR;
	  newlast->len +=2;
	}
      } else if( is_kanji( ch & 255 ) ){ /* Shift JIS-���� */
	if( nomemoMode == UNKNOWN_NOMEMO ){
	  nomemoMode = NOT_CONV_NOMEMO;
	}
	
	if( width - newlast->len <= 1 ){
	  unreadc( ch );
	  *ptr++ = '-';
	  *ptr++ = CTRL_COLOR;
	  newlast->len++;
	  goto EndOfLine;
	}
	*ptr++ = ch;
	*ptr++ = TEXT_COLOR;
	newlast->len++;
	
	/* ���肦�Ȃ����Ƃ���,�S�p�����̑��o�C�g��EOF���������̏��� */
	ch = readc();
	if( ch==EOF ){
	  *(ptr-2) = 0x1A;
	  *(ptr-1) = CTRL_COLOR;
	  
	  status = ENDOFFILE ;
	  this->close();
	  
	  goto EndOfLine;
	}
	*ptr++ = ch;
	*ptr++ = TEXT_COLOR;
	newlast->len++;
	break;
      }else if( jismode ){
	if( width - newlast->len <= 1 ){
	  unreadc( ch );
	  *ptr++ = '-';
	  *ptr++ = CTRL_COLOR;
	  newlast->len++;
	  goto EndOfLine;
	}
	int cl=readc();
	if( ch % 2 == 0 ){
	  cl += 0x7e;
	  ch = (ch / 2 )+0x70;
	}else{
	  cl += 0x1f;
	  if( cl >= 0x7f ){
	    cl++;
	  }
	  ch = (ch+1)/2+0x70;
	}
	if( ch >= 0xa0 ){
	  ch += 0x40;
	}
	*ptr++ = ch;
	*ptr++ = TEXT_COLOR;
	*ptr++ = cl;
	*ptr++ = TEXT_COLOR;
	newlast->len += 2;
	break;

      }else{ /* �񊿎� ANK����*/
	if( 0xB0 <= (ch & 255) && (ch & 255) <= 0xDF ){
	  const static unsigned char EtoJ[]=
	    /* 0xB- */
	    "\x1A\x14\x14\x05\x17\x17\x17\x02"
	      "\x02\x17\x05\x02\x04\x04\x04\x02"
		
		/* 0xC-*/
		"\x03\x15\x16\x19\x06\x10\x19\x19"
		  "\x03\x01\x15\x16\x19\x06\x10\x15"
		    
		    /* 0xD- */
		    "\x15\x16\x16\x03\x03\x01\x01\x10"
		      "\x10\x04\x01\x14\x14\x14\x14\x14"
			;
	  
	  if( nomemoMode == CONVERT_NOMEMO ){
	    ch = EtoJ[ (ch & 255) - 0xB0 ];
	  }else if( nomemoMode == UNKNOWN_NOMEMO ){
	    int ch2 = readc();
	    int ch3 = readc();
	    
	    if( ch2 == ch3 ){ /* 2�����J�i������ł���ꍇ */
	      const static unsigned char list[][4]={
		"��","��","��","��","��",
	      };
	      if( ch==ch2 ){ /* ����������3�A���̏ꍇ */
		nomemoMode = CONVERT_NOMEMO;
		ch = EtoJ[ (ch & 0xFF) - 0xB0 ];
	      }else{ /* ����(���g�g)�ɑ�������R�[�h���ۂ��ꍇ */
		for(int i=0 ; i<numof(list) ; i++ ){
		  if(   (ch & 255)==(list[i][0] & 255)
		     && (ch2& 255)==(list[i][1] & 255) ){
		    nomemoMode = CONVERT_NOMEMO;
		    ch = EtoJ[ (ch & 0xFF) - 0xB0 ];
		    break;
		  }
		}// for
	      }// fi
	    }
	    unreadc(ch3);
	    unreadc(ch2);
	  }/* UNKNOWN_NOMEMO */
	}/* if( 0xB0 <= ch && ch <= 0xDF )... */
	
	ptr[1] = TEXT_COLOR;
	if( nbackspace > 0 ){
	  if( ptr[0] == '_' )
	    ptr[1] = UL_COLOR;
	  else if( ptr[0] == ch )
	    ptr[1] = BOLD_COLOR;
	  nbackspace--;
	}
	ptr[0] = ch;
	ptr += 2;
	newlast->len++;
	
	break;
      }
    } // end switch(...)
  } // end while(...)
 EndOfLine:

  if( status == GOOD  &&  !crlf_arrow_mode  &&  newlast->len >= width ){
    /* 80���ڂ� CRLF ������ƁA����炪���̍s�ɏo�Ă��܂��A1�s�Ȃ̂�2�s��
     * �܂�Ԃ���Ă��܂��B���s�}�[�N���\������Ă��鎞�́A����Ŏ��R����
     * �����łȂ��ꍇ�́A�X�������̂��Ƃ������̂ŁA�����ŗ]���ȉ��s���̂�
     * �Ă���Ă���B
     */
    int ch=readc();
    if( ch=='\r' ){
      if( (ch = readc()) !='\n' ){
	unreadc( ch );
	unreadc('\r');
      }
    }else if( ch != '\n' ){
      unreadc( ch );
    }
  }

  if( width > newlast->len ){
    sbrk.back(  (width - newlast->len)*2 );
  }
  
  nlines++;
  
  newlast->next = NULL;
  newlast->prev = last;
  
  if( last != NULL )
    last->next = newlast;
  last = newlast;

  hmtx.release();
  return true;
}


Line *Buffer::nextline( Line *current )
{
  assert( current != NULL );
	
  if( current->next != NULL ){
    return current->next;
  }else{
    if( status != GOOD ){
      DEBUG1(fputs("(Buffer::nextline) status != GOOD\n",stderr));
      return NULL;
    }

    // while( status==GOOD  &&  current->next == NULL ){
    readline();
    //sleep(0);
    //}
#ifdef DEBUG
    if( current->next == NULL ){
      fputs("(Buffer::nextline) current->next == NULL\n",stderr);
    }
#endif
    return current->next;
  }
}


/* �o�b�t�@�I�[�v���̋��ʕ���
 *	title �^�C�g��������
 */
int Buffer::open_core( const char *_title )
{
  // assert( _title != NULL );
  // assert( status != GOOD );
  
  status = GOOD ;
  nlines = 0 ;
  
  title = _title;
  
  // �Ƃ肠�����A�擪�s�����̓��[�h���ă��X�g�̌`������Ă��� 
  last = NULL; // �O�̍s���Ȃ��̂𖾎�����B
  if( readline() == false || (first = last) == NULL ){
    DEBUG1(fprintf(stderr,"(Buffer::open_core) failure readline(),status=%d\n"
		  , status ) );
    if( status == GOOD )
      status = CANT_OPEN;
    return status;
  }
  return 0;
}

int Buffer::open( const char *_fname , const char *_title )
{
  if( _fname[0] == '-'  &&  _fname[1] == '\0' ){
    filptr = stdin ;
  }else{
    const char *suffix=_getext(_fname);
    
    if( suffix != NULL  &&  strcmp( suffix , ".gz" )==0 ){
      filptr.pOpen( "gzip -dc",_fname,"rb");
    }else if( suffix != NULL && strcmp( suffix , ".bz2" )==0 ){
      filptr.pOpen( "bzip2 -dc",_fname , "rb" );
    }else{
      filptr.fOpen( _fname , "rb" );
    }
  }
  if( filptr.isOk() ){
    fname = _fname;
    return open_core( _title );
  }else{
    DEBUG1( fprintf(stderr,"(Buffer::open) can't open file %s(%s)\n"
		    , _fname , _title ) );
    return status=CANT_OPEN ;
  }
}

Buffer::Buffer( int Width )
: threadLife(THREAD_IS_DEAD) , eucmode(UNKNOWN), hasJisCode(false) ,
  status(NOT_OPENED) , tab(4) , nlines(0) , jismode(false) ,
  presiz(0) , nkfcnt(-1) , first(0) , last(0) , tid(-1) ,
  width(Width)
{
  nomemoMode = defaultNomemoMode;
}

Buffer::~Buffer()
{
  if( tid != -1 ){
    /* �X���b�h�����ʂ܂ő҂ׂ��I */
    hmtx.request();
    while( threadLife != THREAD_IS_DEAD ){
      threadLife = KILL_THREAD;
      hmtx.release();
      sleep(0);
      hmtx.request();
    }
    hmtx.release();
  }
}

int Window::forward()
{
  if( hell == NULL  &&  (hell=buf.nextline(earth))==NULL ){
    DEBUG1(fputs("(Window::forward) hell==NULL\n",stderr));
    return 1;
  }

  Line *tmp=buf.nextline( hell );
#if 0
  /* �ʂ� hell �� NULL �ł��悢����A������ tmp==NULL �ł�����
   * �����͂��B������Ԉ���Ă͂����Ȃ��̂ŁA������ block ��
   * #if 0 �̂܂܁A�ۑ����Ă����� 
   */
  if( tmp == NULL ){
    DEBUG1(fputs("(Window::forward) tmp==NULL\n",stderr));
    return 1;
  }
#endif

  earth  = hell;
  hell   = tmp;
  hmtx.request();
  assert( heaven != NULL );
  heaven = heaven->next;
  hmtx.release();
  
  lnum++;
  return 0;
}

int Window::backward()
{
  if( heaven->prev == NULL )
    return 1;
  
  hell   = earth;
  earth  = earth->prev;
  heaven = heaven->prev;
  
  lnum--;
  return 0;
}
