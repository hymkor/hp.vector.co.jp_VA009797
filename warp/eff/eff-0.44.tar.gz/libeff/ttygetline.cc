#include <stdio.h>
#include "getline.h"

int TtyLineInput::getkey()
{
  fflush(stdout);
  return ::getkey();
}

void TtyLineInput::putchr(int ch)
{
  putchar(ch);
}
void TtyLineInput::putbs(int n)
{
  while(n--)
    putchar('\b');
}
void TtyLineInput::start(void)
{
  raw_mode();
}
void TtyLineInput::end(void)
{
  cocked_mode();
  putchar('\n');
}

