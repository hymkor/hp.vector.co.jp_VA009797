#include <stdlib.h>
#include <sys/video.h>
#include "effetc.h"

void ScrnSave::save()
{
  if( buffer != NULL )
    free(buffer);
  
  v_dimen( &width , &height );
  buffer = (char*)_tmalloc( (count=width * height) * 2 );
  if( buffer != NULL ){
    v_getline( buffer , 0 , 0 , count );
    v_getxy(&csrpos,&csrlin);
  }
}

void ScrnSave::load()
{
  if( buffer == NULL )
    return;
  
  v_putline( buffer , 0 , 0 , count );
  _tfree(buffer);
  buffer = NULL;
  v_gotoxy(csrpos,csrlin);
}
