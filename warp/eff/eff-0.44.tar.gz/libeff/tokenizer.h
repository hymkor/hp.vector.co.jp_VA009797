// -*- c++ -*-
#ifndef TOKENIZER_H
#define TOKENIZER_H

class Tokenizer{
  int lastchar;
protected:
  int lnum; /* ���̍s�ԍ��ϐ��̑����́A�h���N���X�̃��\�b�h�Ɉς˂���
	     * (include �Ȃǂ�z��)
	     */
  virtual int read()=0;   /* �ꕶ���擾���\�b�h */
public:
  /* �G���[�I�u�W�F�N�g */
  struct SyntaxError{
    Tokenizer  *errObject;
    const char *errMethod;
    const char *errMessage;
    
    SyntaxError(  Tokenizer *_errObject
		, const char *_errMethod
		, const char *_errMessage )
      : errObject(_errObject) , errMethod(_errMethod) , errMessage(_errMessage)
	{ }
  };
  struct UnexpectedChar : public SyntaxError {
    int errChar;
    UnexpectedChar(  Tokenizer  *_errObject
		   , const char *_errMethod
		   , int _errChar )
      : SyntaxError(_errObject,_errMethod,"Unexpected Character")
	, errChar(_errChar)
	  { }
  };
  struct TooNearEof : public SyntaxError{
    TooNearEof(  Tokenizer *_errObject
	       , const char *_errMethod )
      : SyntaxError(_errObject,_errMethod,"Too near end of file")
	{ }
  };

  // �R���X�g���N�^�B
  Tokenizer() : lastchar('\n'),lnum(0) { }
  virtual ~Tokenizer(){ }
  
  class PostIncResult {
    int prevchar;
  public:
    PostIncResult(int ch) : prevchar(ch) { }
    int operator * () const { return prevchar; }
  };

  int operator *  () const { return lastchar; }
  Tokenizer &operator++(){ lastchar=read(); return *this; }
  PostIncResult  operator++(int){
    PostIncResult rc(lastchar);   ++*this;   return rc;
  }
  virtual int isOk() const=0;
  int getLineNumber() const { return lnum; }

  /* �\����̊e�v�f���擾���� 
   */
  Tokenizer &passSpace(); // �󔒂�ǂݔ�΂��B

  /* �� + ����̕������ǂݔ�΂� */
  void passChar(int ch)
    throw(TooNearEof* , UnexpectedChar*);

  /* ���ʎq( [ \t]*[a-zA-Z][a-zA-Z0-9]* ) */
  char *readIdentifier(char *buffer,int size)
    throw(TooNearEof* , UnexpectedChar*);
  
  /* ������( �_�u���N�H�[�g�Ɉ͂܂ꂽ������ ) */
  char *readQuoted(char *buffer,int size)
    throw(TooNearEof* , UnexpectedChar*);
  int readNumber()
    throw(TooNearEof* , UnexpectedChar*);
};

class FileTokenizer : public Tokenizer {
  char *fname;
  FILE *fp;
protected:
  int read();
public:
  /* �G���[�I�u�W�F�N�g */
  struct FileNotFound {
    const char *fname;
    FileNotFound(const char *_fname) : fname(_fname) { }
  };

  int isOk() const;
  FileTokenizer( const char *fname ) throw(FileNotFound*);
  FileTokenizer( FILE *_fp ) : Tokenizer() , fname((char*)0) , fp(_fp){ }
  
  ~FileTokenizer();
  const char *getFileName() const { return fname; }
};

#endif
