/* -*- c++ -*- */
#ifndef DIRDEF_H
#define DIRDEF_H

class DirDef {
  


}



#endif
