#include <sys/video.h>
#include <stdlib.h>
#include <stdio.h>
#include "VBuffer.h"
#include "effetc.h"
#include "dirwin.h"
#include "volwin.h"

#define INCL_DOSFILEMGR
#define INCL_DOSMISC
#include "os2eff.h"

VolWindow::VolumeInfo VolWindow::volume[];
char VolWindow::fileSystem['Z'-'A'+1][8];

const char *VolWindow::driveCharToString(int letter)
{
  static char driveString['Z'-'A'+1][3];

  if( isAlpha(letter) )
    letter = (letter & 0x1F)-1;
  driveString[ letter ][ 0 ] = letter+'A';
  driveString[ letter ][ 1 ] = ':';
  driveString[ letter ][ 2 ] = '\0';
  return driveString[ letter ];
}

void VolWindow::Iterator::putat(int x,int y,int w)
{
  VBuffer vbuf;

  vbuf.printf( " %08X %c: %-5s %-20s"
	      , volume[N()].serial
	      , this->getDriveLetter()
	      , fileSystem[ N() ]
	      , volume[N()].label
	      );
  vbuf.putatPart( x,y,0,w,' ');
}

void VolWindow::drawTitle()
{
  const char title[]=" Volume List ";
  v_attrib( 0x0C );
  v_putc('-');
  v_attrib( 0xC0 );
  v_puts( title );

  v_attrib( 0x0C );
  v_putn('-',width-sizeof(title));
  v_attrib( STANDARD_COLOR );
}

VolWindow::VolWindow(int x,int y,int w,int h)
: AnyWindow(x,y,w,h)
{
  ndrives = 'Z'-'A'+1;
  DosError( FERR_DISABLEHARDERR );
  for(int i=0 ; i<ndrives ; i++ ){
    if(   DosQueryFSInfo(i+1 , 2,&volume[i] , sizeof(volume[i]) ) != 0 
       || _filesys(  driveCharToString(i) , fileSystem[i]
		   , sizeof(fileSystem[i])) != 0 ){
      volume[i].serial = ~0;
      volume[i].label_length = 0;
      volume[i].label[0] = '\0';
      strcpy(fileSystem[i],"----");
    }
  }
  DosError( FERR_ENABLEHARDERR );
  top = new Iterator(*this);
  heaven = top->dup();
  cursor = heaven->dup();
  earth = NULL;

}
VolWindow::~VolWindow()
{
  ;
}
AnyWindow::Status VolWindow::runVolWindow(int key)
{
  switch( key ){
  default:
    return this->AnyWindow::runAnyWindow(key);

  case 'i':
  case CTRL('J'):
  case CTRL('m'):
    char buffer[FILENAME_MAX];
    buffer[0] = getCursor()->getDriveLetter();
    buffer[1] = ':';
    
    DosError( FERR_DISABLEHARDERR );

    if(   _getcwd1(buffer+2,buffer[0]) == 0
       && _chdir2(buffer) == 0
       && new DirWindow(x0,y0,width,height+1,buffer) != NULL ){
      DosError( FERR_ENABLEHARDERR );
      return REPLACE;
    }else{
      DosError( FERR_ENABLEHARDERR );
      return CONTINUE;
    }
  }
}
