/* -*- c++ -*- */
#ifndef LESZ_H
#define LESZ_H

#define THENAME		"eff"
#define OPTIONENV	"EFF"
#define VER		"0.23"

#include <stdio.h>
#include "macros.h"
#include "leszbuf.h"

/* ----- leszwin.cc ----- */

extern int text_cut_column ;	/* ��ʏ�̃e�L�X�g�\���̈�̃T�C�Y */
extern int print_lines ;

extern int screen_width ;		/* ��ʂ̃T�C�Y */
extern int screen_height ;

/************* LESZCOM.CC ***********/

enum command_t { CONTINUE , RESTORE_QUIT , QUIT , WARNING };

command_t command_seek_forward( Pager &win );
command_t command_seek_backward( Pager &win );
command_t command_seek_next( Pager &win );
command_t command_seek_reverse( Pager &win );

/************ LESZMAIN.C ************/

extern unsigned int PROMPT_COLOR , ANSWER_COLOR ;
extern unsigned long codepages[];
enum{ CHEV_JP=932 , CHEV_US=437 };
extern const char *program_name;

extern "C" int _read_kbd(int,int,int);

inline int getkey( int wait )
{
  int key=_read_kbd(0,wait,0);
  return key==0 ? (0x100 | _read_kbd(0,wait,0)) : key;
}

int lesz_pipe( const char *command , const char *title);
int lesz_file( const char *fname );
int lesz_stdin( const char *title );

/************* INPUT.CC ***************/

void print_wait_a_moment();

#define SEMAPHORE
#define MULTITHREAD 1

#endif /* defined LESZ_H */
