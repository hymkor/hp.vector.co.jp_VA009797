#ifndef NEWSBRK_H
#define NEWSBRK_H

class Sbrk {
  struct Block{
    struct Block *prev;
    char buffer[ 1 ];
  };
  Block *block;
  char *pointor;

  unsigned usedsize , leftsize;
public:
  void *alloc( unsigned size );
  void back( int size );
  void free( void );

  Sbrk() : block(0) , pointor(0) , usedsize(0) , leftsize(0) { }
  ~Sbrk(){ this->free(); }
};

#endif
