/* -*- c++ -*- */
#ifndef FILEWIN_H
#define FILEWIN_H

#include "files.h"

typedef const char (*framechar_t)[4];
framechar_t getframechar( void );
void v_frameline(int x, int y, int w, const char *frame);

class FileWindow{
  enum{
    TEXT_ATTRIB		= 0x0F ,
    CURSOR_ATTRIB	= 0x4F ,
  };
protected:
  Files *heaven,*hell,*earth,*cursor;
  framechar_t framechar;
	
  int openflag;
  int x0,y0;
  int width,height;
  int csrlin;
  int nfiles;
  char *screen_buffer;
  int _x0,_y0,_width,_height;
  
  void repaint( void );
  void disp_a_file(int y,Files *ptr,unsigned attr);
  int screen_save( void );
  int screen_restore( void );
public:
  void chdir( void );
  int  open(int x,int y,int w,int h);
  int  close( void );
  
  void scrollup( void );
  void scrolldown( void );
  void pageup( void );
  void pagedown( void );
  
  void csr_forward( void );
  void csr_backward( void );
  
  const Files *operator->( void ) const { return cursor; }
  
  const char *csr_fname( void ) const {return cursor->fname(); }
  
  FileWindow(const char *dir)
    : heaven( Files::open(dir) ) , hell(0) , earth(0) , cursor(0)
      , openflag(0) , csrlin(0) , screen_buffer(0)
	{ /* no-operation */ }
  
  ~FileWindow( void )
    {	Files::close();		close();	}
};

#endif
