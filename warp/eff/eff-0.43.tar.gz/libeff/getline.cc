#undef DEBUG
#include <stdlib.h>
#include <assert.h>
#include <stdio.h>
#include <string.h>
#include <sys/kbdscan.h>

#include "effetc.h"
#include "files.h"
#include "getline.h"

#undef TEST

#ifdef DEBUG
#  define DEBUG1(x) (x)
#else
#  define DEBUG1(x)
#endif

Histories::~Histories()
{
  while( history != NULL ){
    History *nxt=history->prev;
    if( history->lock==0 )
      free(history->string);
    free(history);
    history = nxt;
  }
}

void Histories::append( char *s ) throw (MallocError)
{
  /* �q�X�g���L�� */
  History *tmp=(History*)malloc(sizeof(History));
  if( tmp == NULL )
    throw MallocError();

  tmp->string = s;
  tmp->length = strlen(s);
  tmp->lock   = 0;
  tmp->prev   = history;
  tmp->next   = NULL;
  if( history != NULL ){
    drop_future();
    history->next = tmp;
  }
  history = tmp;
  ++nhistories;
}

void Histories::drop_future(void)
{
  if( history != NULL  &&  history->next != NULL ){
    /* ���͂������̂��̂��A�����̃q�X�g���Ƃ��ē����Ă���ꍇ������B
     * ���̏ꍇ�A������S�Ĕj��������B*/
    
    History *ptr=history->next;
    while( ptr != NULL ){
      History *nxt=ptr->next;
      free(ptr->string);
      free(ptr);
      ptr=nxt;
    }
    history->next = NULL;
  }
}


/* ���[���[�`�� */

void LineInput::makeroom(int at,int size)
{
  /* �o�b�t�@�T�C�Y���������悤�ł���΁A�L���� */
  if( len+size > max ){
    max = len+size+UNIT_BUFSIZE;
    strbuf = (char*)realloc( strbuf, max );
    atrbuf = (char*)realloc( atrbuf, max );
    assert( strbuf != NULL  &&  atrbuf != NULL );
  }
  
  for(int i=len-1 ; i >= at ; i-- ){
    strbuf[ i+size ] = strbuf[ i ];
    atrbuf[ i+size ] = atrbuf[ i ];
  }
  len += size;
}

void LineInput::delroom(int at,int size)
{
  for(int i=at;i<len;i++){
    strbuf[ i ] = strbuf[ i+size ];
    atrbuf[ i ] = atrbuf[ i+size ];
  }
  len -= size;
}

/* �J�[�\���ȍ~���ĕ`�� */
void LineInput::repaint_after(int rm=0)
{
  int bs=0;
  for(int i=pos;i<len;i++){
    putchr( strbuf[ i ] );
    ++bs;
  }
  
  while( rm-- > 0 ){
    putchr( ' ' );
    ++bs;
  }
  putbs( bs );
}


void LineInput::get_current_word(int *at, int *size,char **string)
{
  int j=0;
  int wordtop=0;
  do{
    while( isSpace(strbuf[j]) &&  j < pos )
      ++j;
    wordtop = j;
    while( !isSpace(strbuf[j]) && j < pos )
      ++j;
  }while( j < pos );
  
  if( at != 0 )
    *at = wordtop;
  if( size != 0 )
    *size = j-wordtop;
  if( string != 0 ){
    *string = (char*)malloc( j-wordtop+1 );
    assert( *string != NULL );
    if( j-wordtop > 0 )
      strncpy( *string , &strbuf[wordtop] , j-wordtop );
    else
      **string = '\0';
  }
}



/* -----------------
 * �L�[�o�C���h�֌W
 * ----------------- */

LineInput::Status LineInput::enter(int)
{  return ENTER; }
LineInput::Status LineInput::cancel(int)
{  return CANCEL;  }
LineInput::Status LineInput::do_nothing(int)
{  return CONTINUE;  }

LineInput::Status LineInput::insert(int key)
{
  int upperbyte=(key >> 8) & 255;

  if( upperbyte == 1 ){
    return CONTINUE;
  }else if( upperbyte != 0 ){
    /* DBCS���� */
    makeroom(pos,2);
    strbuf[ pos   ] = upperbyte;
    atrbuf[ pos++ ] = DBC1ST;
    putchr( upperbyte );
    
    strbuf[ pos   ] = key;
    atrbuf[ pos++ ] = DBC2ND;
    putchr( key & 0xFF );
  }else{
    makeroom(pos,1);
    strbuf[ pos   ] = key;
    atrbuf[ pos++ ] = SBC;
    putchr( key );
  }
  repaint_after();
  return CONTINUE;
}

LineInput::Status LineInput::erase(int)
{
  if( atrbuf[pos] == SBC ){
    delroom(pos,1);
    repaint_after(1);
  }else{
    delroom(pos,2);
    repaint_after(2);
  }
  repaint_after();
  return CONTINUE;
}


LineInput::Status LineInput::backspace(int key)
{
  if( pos > 0 ){
    backward(key);
    erase(key);
  }
  return CONTINUE;
}

LineInput::Status LineInput::foreward(int)
{
  if( pos < len ){
    if( atrbuf[pos] != SBC ){
      assert(atrbuf[pos] != DBC2ND );
      assert(pos+1<len);
      putchr(strbuf[pos++]);
    }
    putchr(strbuf[pos++]);
  }
  return CONTINUE;
}

LineInput::Status LineInput::backward(int)
{
  if( pos > 0 ){
    if( atrbuf[pos-1] != SBC ){
      if( pos >= 2 ){
	assert(atrbuf[pos-1] == DBC2ND );
	assert(atrbuf[pos-2] == DBC1ST );
	putbs(2);
	pos -= 2;
      }
    }else{
      putbs(1);
      --pos;
    }
  }
  return CONTINUE;
}

LineInput::Status LineInput::goto_head(int)
{
  putbs( pos );
  pos = 0;
  return CONTINUE;
}

LineInput::Status LineInput::goto_tail(int)
{
  for( ; pos < len ; pos++ )
    putchr( strbuf[pos] );
  return CONTINUE;
}

LineInput::Status LineInput::erase_line(int)
{
  for(int i=pos ; i<len ; i++)
    putchr( ' ' );
  putbs( len-pos );
  len=pos;
  return CONTINUE;
}

LineInput::Status LineInput::erase_all(int key)
{
  putbs( pos ); pos = 0;
  return erase_line( key );
}

int LineInput::insert_text(const char *s,int at)
{
  if( s == NULL )
    return 0;

  if( at==-1 )
    at = pos;

  int len=strlen(s);
  makeroom( at , len );
  bool afterkanji=false;

  while( *s != '\0' ){
    if( afterkanji ){
      atrbuf[ at ] = DBC2ND;
      afterkanji = false;
    }else if( isKanji(*s) ){
      atrbuf[ at ] = DBC1ST;
      afterkanji = true;
    }else{
      atrbuf[ at ] = SBC;
      afterkanji = false;
    }
    strbuf[ at++ ] = *s++;
  }
  return len;
}

LineInput::Status LineInput::yank(int)
{
  const char *clipboard=getClipBoardValue();
  if( clipboard == NULL )
    return CONTINUE;
  
  int len=insert_text( clipboard );
  while( len-- )
    putchr( strbuf[pos++] );

  repaint_after();
  return CONTINUE;
}

const char *LineInput::getline(const char *default_value)
{
  max = INIT_BUFSIZE;
  strbuf = (char*)malloc( INIT_BUFSIZE );
  if( strbuf == NULL ){
    DEBUG1( fputs("(LineInput::getline) strbuf is null.\n",stderr) );
    return NULL;
  }
  atrbuf = (char*)malloc( INIT_BUFSIZE );
  if( atrbuf == NULL ){
    DEBUG1( fputs("(LineInput::getline) atrbuf is null.\n",stderr) );
    free(strbuf);
    return NULL;
  }
  pos = len = 0;

  /* �f�t�H���g�l������ꍇ */
  if( default_value != 0 ){
    /* �f�t�H���g�l�̕����񒷂��m�ۂ����o�b�t�@���傫���� */
    int default_value_len = strlen( default_value );
    if( default_value_len >= max ){
      max = default_value_len + INIT_BUFSIZE;
      free(strbuf); strbuf = (char*)malloc( max );
      free(atrbuf); atrbuf = (char*)malloc( max );
      if( strbuf == NULL || atrbuf == NULL ){
	DEBUG1( fputs("(LineInput::getline) strbuf/atrbuf is"
		      " null(default value)\n"
		      , stderr ) );
	free(strbuf); free(atrbuf);
	strbuf = atrbuf = 0;
	return NULL;
      }
    }

    while( *default_value != '\0' ){
      if( isKanji(*default_value) ){
	putchr( strbuf[ len ] = *default_value++ );
	atrbuf[ len++ ] = DBC1ST;

	putchr( strbuf[ len ] = *default_value++ );
	atrbuf[ len++ ] = DBC2ND;
      }else{
	putchr( strbuf[ len ] = *default_value++ );
	atrbuf[ len++ ] = SBC;
      }
    }
    pos = len;
  }
  start();

  for(;;){
    int key=getkey();
    switch( (this->*bindkey(key))(key) ){
    case CONTINUE:
      continue;

    case CANCEL:
      free(strbuf);
      free(atrbuf);
      end();
      strbuf = atrbuf = 0;
      return NULL;
      
    case ENTER:
      strbuf = (char*)realloc(strbuf,len+1);
      strbuf[len] = '\0';
      
      if( len > 0 ){
	append( strbuf );
      }else{
	drop_future();
      }
      end();
      history_cursor.reset();
      free(atrbuf);
      return strbuf;
    }
  }
}

int LineInput::HistoryIterator::operator--(void)
{
  if( ptr->prev != NULL ){
    ptr = ptr->prev;
    n--;
    return 0;
  }else{
    return 1;
  }
}
int LineInput::HistoryIterator::operator++(void)
{
  if( ptr->next != NULL ){
    ptr = ptr->next;
    n++;
    return 0;
  }else{
    return 1;
  }
}

#if 0
int LineInput::HistoryIterator::replace(const char *s)
{
  /* ���b�N���������Ă��鎞�͌����s�\ */
  if( ptr->lock > 0 )
    return ptr->lock;
  
  free( ptr->string );
  ptr->string = strdup(s);
  assert(ptr->string != NULL );
  return 0;
}
#endif

// -- at ���� nchars �o�C�g���� string �Œu������ --
int LineInput::replace(int at,int nchars, const char *string, int new_nchars)
{
  if( new_nchars < 0 )
    new_nchars=strlen(string);

  if( nchars < new_nchars ){
    makeroom( at+nchars , new_nchars-nchars );
  }else if( nchars > new_nchars ){
    delroom( at+new_nchars , nchars-new_nchars);
  }

  for(int i=0;i<new_nchars;i++){
    if( isKanji( string[i] ) ){
      assert( i < new_nchars-1 );
      strbuf[ at+i ] = string[i];
      atrbuf[ at+i ] = DBC1ST;
      i++;
      strbuf[ at+i ] = string[i];
      atrbuf[ at+i ] = DBC2ND;
    }else{
      strbuf[ at+i ] = string[i];
      atrbuf[ at+i ] = SBC;
    }
  }
  return new_nchars-nchars;
}


void LineInput::replace_with_history(void)
{
  /* ���݂̃q�X�g���J�[�\���̓��e��ҏW���e�ƒu��������B */
  int diff=-replace(0,len, *history_cursor, history_cursor.Length() );
  putbs(pos);
  for(pos=0;pos<len;pos++)
    putchr(strbuf[pos]);
  if( diff > 0 ){
    for(int bs=0;bs<diff;bs++)
      putchr(' ');
    putbs(diff);
  }
}

LineInput::Status LineInput::previous(int)
{
  if( history == NULL )
    return CONTINUE;

  if( !history_cursor.ok() ){
    history_cursor.set(*this);
    
    /* ����܂œ��͂���������𖢗��̗����Ƃ��ĕۑ����Ă��� */
    History *tmp=(History*)malloc(sizeof(History));
    if( tmp == NULL )
      throw MallocError();

    if( (tmp->string = (char*)malloc(len+1)) == NULL ){
      free( tmp );
      throw MallocError();
    }

    memcpy( tmp->string , strbuf , len );
    tmp->string[len] = '\0';
    tmp->length = len;
    tmp->lock = 0;
    tmp->prev = history;
    tmp->next = NULL;
    
    assert( history->next == NULL );
    history->next = tmp;

    replace_with_history();
  }else if( --history_cursor == 0 ){
    replace_with_history();
  }else{
    /* �x�����ł��炷����? */
  }
  return CONTINUE;
}


LineInput::Status LineInput::next(int)
{
  if( history == NULL  ||  !history_cursor.ok()  )
    return CONTINUE;

  if( ++history_cursor == 0 ){
    replace_with_history();
    
    if( history_cursor.is_top() ){
      /* �q�X�g���Q�ƑO�̂Ƃ���܂Ŗ߂��� */
      history_cursor.reset();
      drop_future();
    }
  }else{
    /* �x���� */
  }
  return CONTINUE;
}

LineInput::Status (LineInput::*LineInput::bindmap[512])(int);

void LineInput::bindkey(int key,LineInput::BindFunc func)
{
  if( localmap == 0 ){
    localmap = (BindFunc*)malloc(sizeof(bindmap));
    memcpy(localmap,bindmap,sizeof(bindmap));
    currentmap = localmap;
  }
  assert( key <= numof(bindmap) );
  localmap[ key ] = func;
}


LineInput::LineInput()
: localmap(0) , currentmap(LineInput::bindmap)
{
  /* --- �o�C���h�֌W --- */
  static bool bindmap_inited=false;
  if( bindmap_inited == false ){
    bindmap_inited=true;
    /* -- �K�v�ŏ����̃L�[�o�C���h�݂̂��` -- */

    for(int i=0;i<numof(bindmap);i++)
      bindmap[ i ] = &do_nothing;
    for(int i=' ';i<256;i++)
      bindmap[ i ] = &insert;
    
    bindmap[ CTRL('D') ] = bindmap[ KEY(DEL)   ] = &erase;
    bindmap[ CTRL('F') ] = bindmap[ KEY(RIGHT) ] = &foreward;
    bindmap[ CTRL('B') ] = bindmap[ KEY(LEFT)  ] = &backward;
    bindmap[ CTRL('M') ] = bindmap[ CTRL('J') ]  = &enter;
    bindmap[ CTRL('H') ] =                         &backspace;
    bindmap[ CTRL('A') ] = bindmap[ KEY(HOME) ]  = &goto_head;
    bindmap[ CTRL('E') ] = bindmap[ KEY(END) ]   = &goto_tail;
    bindmap[ CTRL('K') ] =                         &erase_line;
    bindmap[ CTRL('[') ] =                         &cancel;
    bindmap[ CTRL('P') ] = bindmap[ KEY(UP) ]    = &previous;
    bindmap[ CTRL('N') ] = bindmap[ KEY(DOWN) ]  = &next;
    bindmap[ CTRL('I') ] =                         &complete_filename;
    bindmap[ CTRL('Y') ] = bindmap[ KEY(CTRL_INS)] = &yank;
  }
}

LineInput::~LineInput()
{
  free(localmap);
}


void LineInput::complete_path_core(int attr)
{
  int at,size;
  char *basefname;
  get_current_word(&at,&size,&basefname);
  basefname = (char*)realloc(basefname,size+2);
  basefname[ size   ] = '*';
  basefname[ size+1 ] = '\0';

  Files::Exploder list( basefname );
  free(basefname);
  if( list.N() <= 0 )
    return;

  int i=0;
  while( (list[i].attr & attr)==0 ){
    if( ++i >= list.N() )
      return;
  }

  char *match=(char*)alloca(strlen(list[i])+1);
  strcpy( match , list[i] );
  int n=1;

  while( ++i < list.N() ){
    if( (list[i].attr & attr )==0 )
      continue;

    n++;
    
    const char *sp=list[i];
    char *dp=match;

    while( *sp != '\0' && *dp != '\0' ){
      if( *sp != *dp ){
	*dp = '\0';
	break;
      }
      ++sp ; ++dp ;
    }
  }
  int leastmatch=strlen(match);
  if( leastmatch < size )
    return;

  replace(at,size,match,leastmatch);
  putbs( pos-at );
  for(int j=at ; j < at+leastmatch ; j++ )
    putchr( strbuf[j] );
  pos = at+leastmatch;
  if( n == 1  &&  (list[0].attr & Files::DIRECTORY)!=0 )
    insert('/');
  else
    repaint_after();
  
}

LineInput::Status LineInput::complete_directory(int)
{
  complete_path_core( Files::DIRECTORY );
  return CONTINUE;
}

LineInput::Status LineInput::complete_filename(int)
{
  complete_path_core( ~0 );
  return CONTINUE;
}


#ifdef TEST

int main(void)
{
  ConsoleInput input;
  
  printf("Input :");

  for(;;){
    char *line=input.getline();
    if( line == NULL )
      break;
    printf("[%s]\n",line);
  }
  return 0;
}

#endif
