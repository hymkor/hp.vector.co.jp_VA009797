// #include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "NString.h"

NStringBuffer::NStringBuffer(int bufsize,int step) : NString()
{
  this->step = step;
  
  rep = static_cast<Rep*>(malloc( sizeof(Rep)+bufsize ));
  if( rep != 0 ){
    rep->refcnt    = 1;
    rep->maximum   = bufsize;
    rep->length    = 0;
    rep->buffer[0] = '\0';
  }
}

NStringBuffer &NStringBuffer::operator << (int ch)
{
  if( rep == 0 )
    return *this;

  if( rep->length+1 >= rep->maximum ){
    Rep *newrep = static_cast<Rep*>
      (realloc( rep , sizeof(Rep) + rep->maximum + step ));
    if( newrep == 0 )
      return *this;
    
    rep = newrep;
    rep->maximum += step;
  }
  rep->buffer[ rep->length++ ] = ch;
  rep->buffer[ rep->length   ] = '\0';
  return *this;
}

NStringBuffer &NStringBuffer::operator << (const char *s)
{
  if( rep == 0 )
    return *this;
  
  int slen=strlen(s);
  
  if( rep->length + slen >= rep->maximum ){
    Rep *newrep = static_cast<Rep*>
      (realloc( rep , sizeof(Rep)+ rep->length + slen + step) );
    if( newrep == 0 )
      return *this;

    rep = newrep;
    rep->maximum = rep->length + slen + step ;
  }
  strcpy( rep->buffer + rep->length , s );
  rep->length += slen;
  return *this;
}

void NStringBuffer::clear()
{
  if( rep == 0 )
    return;

  rep->length = 0;
}

#if 0

#include <stdio.h>
int main(int argc,char **argv)
{
  NStringBuffer buffer(3);

  for(int i=0;i<argc;i++){
    buffer << argv[i] << ' ' << ',' << " ";
  }
  puts(buffer);
}

#endif
