/* -*- c++ -*- */
#ifndef EFFCFG_H
#define EFFCFG_H

struct SuffixList{
  SuffixList *next;
  
  const char *suffix;
  enum SuffixType{ OPEN , PAGER , EXEC } type;
  const char *procedure;
};

SuffixList *findSuffix(const char *suffix);
int effConfig(void);
extern char *configurationFileName;
extern char *pagerProgramName;
extern char *editorProgramName;

#endif
