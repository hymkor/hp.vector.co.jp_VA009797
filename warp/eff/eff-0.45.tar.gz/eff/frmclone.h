/* -*- c++ -*- */
#ifndef FRMCLONE_H
#define FRMCLONE_H

class RmCloneWindow : public AnyWindow {
  struct Node {
    Node *next,*prev;
    enum{
      SAME_TO_NEXT ,
      SAME_TO_BOTH ,
      SAME_TO_LAST ,
      ZERO_BYTE_FILE ,
    } type;
    Files::DirDateTime datetime;
    int mark;
    unsigned long size;
    char fullpath[1];
  } *first ;
public:
  class Iterator : public AnyWindow::Iterator {
    Node *ptr;
  public:
    Iterator() : ptr(NULL) { }
    Iterator(const Iterator &it) : AnyWindow::Iterator(it) , ptr(it.ptr) { }

    int can_forward() const { return ptr->next != 0; }
    int forward() { 
      if( ptr->next ){
	ptr=ptr->next;return ++n;
      }else{
	return -1;
      }
    }
    int backward(){
      if( ptr->prev ){
	ptr=ptr->prev;return --n;
      }else{
	return -1;
      }
    }
    AnyWindow::Iterator *dup(){
      return new Iterator(*this);
    }
    void mark(int code){ ptr->mark = code; }
    int mark() const { return ptr->mark; }
    void putat();
    const char *getName() const { return ptr->fullpath; }
  };

  void drawTitle();
  Status runRmCloneWindow(int key);
  RmCloneWindow(int x,int y,int w,int h)
    : AnyWindow(x,y,w,h) { }
  ~RmCloneWindow();
};

#endif
