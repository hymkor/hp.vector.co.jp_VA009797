#undef DEBUG
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <sys/video.h>

#include "anywin.h"
#include "wminput.h"
#include "dirwin.h"
#include "getline.h"
#include "thedir.h"
#include "ealib.h"
#include "os2eff.h"
#include "macros.h"

AnyWindow::Status DirWindow::commentWrite(int)
{
  static VioCannaInput *input=NULL;
  if( input == NULL  &&  (input = new WmInput(console_handle)) == NULL ){
    DEBUG1(fputs("(DirWindow::commentWrite) new WmInput failed.\n",stderr));
    return CONTINUE;
  }

  char *orgRemark=get_ascii_ea( cursor->getName() , ".SUBJECT" );
  if( orgRemark == NULL ){
    char **orgComments=get_multiascii_ea( cursor->getName() , ".COMMENTS" );
    if( orgComments != 0 ){
      orgRemark = orgComments[0];
      for(char **p=orgComments+1 ; *p != NULL ; p++ )
	free(*p);
      free( orgComments );
    }
  }
  message( "comment to %s :",cursor->getName());
  const char *remark=input->getline(orgRemark);
  free(orgRemark);
  if( remark == NULL ){
    message( "\ncannceled.\n" );
    return CONTINUE;
  }

  if( set_ascii_ea( cursor->getName() , ".SUBJECT" , remark ) == 0 ){
    // ���݂̃E�C���h�E�̕��փR�����g�𔽉f������.
    if( aFile == NULL ){
      setPrintMode(PRINT_COMMENTS,true);
      readEA();
    }
    aFile[ cursor->N() ].setSubject( remark );

    repaint_cursor_line();
    clear_message();
  }else{
    message("\nunable to comment to '%s'\n",cursor->getName() );
  }
  return AnyWindow::CONTINUE;
}

AnyWindow::Status DirWindow::rename(int)
{
  message("rename %s to ? ",getCursor()->getName() );
  
  WmInput input(console_handle);
  const char *newName = input.getline(getCursor()->getName() );

  // �L�����Z�����Ȃ���΁A���ۂɃ��l�[�������݂�B
  if( newName != NULL ){
    char oldPath[FILENAME_MAX];
    char newPath[FILENAME_MAX];

    Files::makeFullPath(  oldPath , sizeof(oldPath)
			, this->getCurrentDir()
			, getCursor()->getName()  );
    Files::makeFullPath(  newPath , sizeof(newPath)
			, this->getCurrentDir()
			, newName  );

    // ����Ƀ��l�[���ł���΁A�t�@�C�����ă\�[�g����B
    if( ::rename(oldPath,newPath) == 0  ){
      this->reset();
      this->repaint();
      search_for_forward( newName );
    }
  }
  clear_message();
  return CONTINUE;
}

AnyWindow::Status DirWindow::relongname(int)
{
  message("longname for %s ? ",cursor->getName() );
  
  WmInput input(console_handle);
  const char *longname = input.getline(  getLongname( cursor->N() ) );
  
  if( longname == NULL ){
    message( "\ncanceled.\n");
    return CONTINUE;
  }

  if( (  longname[0] != '\0' 
       ? set_ascii_ea( cursor->getName() , ".LONGNAME" , longname )
       : unset_ea( cursor->getName() , ".LONGNAME" ) )==0 ){
    if( aFile == NULL ){
      setPrintMode( PRINT_LONGNAME , true );
      readEA();
    }
    aFile[ cursor->N() ].setLongname( longname );
    
    repaint_cursor_line();
    clear_message();
  }else{
    message("\nunable to relongname for '%s'\n",cursor->getName() );
  }
  return AnyWindow::CONTINUE;
}

AnyWindow::Status DirWindow::mkdir(int)
{
  message("new directory name ? ");

  WmInput input( console_handle );
  const char *dirName = input.getline();
  
  // �L�����Z�����Ȃ���΁A���ۂɍ쐬����B
  if( dirName != NULL ){
    char dirPath[FILENAME_MAX];
    
    Files::makeFullPath(  dirPath , sizeof(dirPath)
		      , this->getCurrentDir()
		      , dirName );
    
    // ����ɍ쐬�ł����
    if( ::mkdir( dirPath , 0777 ) == 0 ){
      this->reset();
      this->repaint();
      search_for_forward( dirName );
    }
  }
  clear_message();
  return CONTINUE;
}

