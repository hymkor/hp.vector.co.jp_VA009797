#include <stdlib.h>
#include <sys/video.h>
#include <sys/kbdscan.h>
#include <sys/ioctl.h>
#include <process.h>

#define CHCP_SUPPORT
/* ...���i�K�ł͓��{��-->�p��ւ̈ڍs�����ł��Ȃ��̂� OFF */
#ifdef CHCP_SUPPORT
#	define INCL_DOSNLS
#	include <os2.h>
#endif

#include "lesz.h"

void print_wait_a_moment()
{
  v_attrib(0x0A);
  v_gotoxy(0,screen_height-1);
  v_putn(' ',screen_width );
  v_puts("Wait a momnet. (^G or ESC : abort)");
}

enum command_t (*jump_table[ 1+256+256 ] )(Pager &);

static command_t command_no_operation( Pager &win )
{
  sleep(0);
  return CONTINUE ;
}

static command_t command_quit1( Pager &win )
{
  return RESTORE_QUIT ;
}

static command_t command_quit2( Pager &win )
{
  return QUIT ;
}

#ifdef CHCP_SUPPORT

static int original_codepage;
static void restore_codepage(void)
{
  system(   original_codepage==437
	 ? "cmd /c chcp 437"
	 : "cmd /c chcp 932" );
}
static command_t command_chcp( Pager &win )
{
  static int codepage=0;
  
  if( codepage == 0 ){
    ULONG CpList[8];
    ULONG CpSize;
    
    original_codepage = codepage 
      = (  DosQueryCp(sizeof(CpList),CpList,&CpSize)==0
	 ? 932 : CpList[0] 
	 );
    
    atexit( restore_codepage );
  }
  
  switch( codepage ){
  case 932:
  case 942:
    system( "cmd /c chcp 437");
    codepage = 437;
    break;
  default:
  case 437:
    system( "cmd /c chcp 932");
    codepage = 932;
    break;
  }
  win.repaint();
  return CONTINUE;
}
#endif

static command_t command_nextline( Pager &win )
{
  win.forward_1();
  return CONTINUE;
}

static command_t command_prevline( Pager &win )
{
  win.backward_1();
  return CONTINUE;
}

static command_t command_nextpage_roll( Pager &win )
{
  for(int i=0 ; i<win.getLines() ; i++ )
    win.forward_1();
  
  // �o�b�t�@�ɂ��܂��Ă���L�[���̂Ă�B
  ioctl(0,TCFLSH,NULL);
  
  return CONTINUE;
}

static command_t command_prevpage_roll( Pager &win )
{
  for(int i=0 ; i<win.getLines() ; i++ )
    win.backward_1();
  
  // �o�b�t�@�ɂ��܂��Ă���L�[���̂Ă�B
  ioctl(0,TCFLSH,NULL);
  
  return CONTINUE;
}

static command_t command_nextpage_change( Pager &win )
{
  for(int i=0 ; i<win.getLines() ; i++ ){
    if( win.forward() )
      break;
  }
  win.repaint();
  return CONTINUE;
}

static command_t command_prevpage_change( Pager &win )
{
  for(int i=0 ; i<win.getLines() ; i++ ){
    if( win.backward() )
      break;
  }
  win.repaint();
  return CONTINUE;
}

static command_t command_first( Pager &win )
{
  while( !win.backward() )
    ;
  win.repaint();
  return CONTINUE;
}

static command_t command_last( Pager &win )
{
  unsigned char i=0;
  print_wait_a_moment();
  while( !win.forward() ){
    if( i++ == 0 ){
      int key=getkey(0);
      if( key == '\x1B' || key == '\x7' )
	break;
    }
  }
  win.repaint();
  return CONTINUE;
}

static command_t command_reprint( Pager &win )
{
  win.repaint();
  return CONTINUE;
}
extern char *original_screen;
extern int screen_size;
extern int original_cursor_x  , original_cursor_y ;
extern int line_input( const char *prompt , char *buffer , size_t size );

static command_t command_spawn( Pager &win )
{
  const char prompt[]="Shell:";
  char cmdlin[256]="";

  int len = line_input( prompt , cmdlin , sizeof(cmdlin) );

  if( len > 0 ){
    v_putline( original_screen , 0 , 0 , screen_size );
    v_gotoxy( original_cursor_x , original_cursor_y );
    system( cmdlin );
    v_getline( original_screen , 0 , 0 , screen_size );
    v_getxy( &original_cursor_x , &original_cursor_y );
    fputs("Hit any key to continue.\n",stderr);
    getkey(1);
  }
  win.repaint();
  return CONTINUE;
}

int jump_table_init()
{
  static struct {
    const char *keys;
    command_t (*command)( Pager & );
  } command_list1[]={
#ifdef CHCP_SUPPORT
    { "L"		, command_chcp },
#endif
    { "q^[o"		, command_quit1 },
    { "Q^Q"		, command_quit2 },
    { "^L"		, command_reprint },
    { "^Xej^J^N\r"	, command_nextline },
    { "^Ey^Yk^K^P\b"	, command_prevline },
    { "fF^F "		, command_nextpage_roll },
    { "bB^B"		, command_prevpage_roll },
    { "cC^C^V"		, command_nextpage_change },
    { "rR^R^Z"		, command_prevpage_change },
    { "<"		, command_first },
    { ">"		, command_last },
    { "/"		, command_seek_forward },
    { "?"		, command_seek_backward },
    { "n"		, command_seek_next },
    { "N"		, command_seek_reverse },
    { "!"		, command_spawn },
  };
  
  static struct {
    unsigned keyno;
    command_t (*command)( Pager & );
  } command_list2[]={
    { K_DOWN		, command_nextline },
    { K_UP		, command_prevline },
    { K_PAGEDOWN	, command_nextpage_change },
    { K_PAGEUP		, command_prevpage_change },
    { K_HOME		, command_first },
    { K_END		, command_last },
  };
  
  for(int i=0 ; i<numof( jump_table ) ; i++ )
    jump_table[ i ] = command_no_operation;
  
  for(int i=0; i<numof(command_list1) ; i++ ){
    const char *p=command_list1[i].keys;
    
    while( *p ){
      int ascii;
      
      if( *p=='^' ){
	if( *++p == '\0'){
	  ascii = '^';
	}else if( *p == '^' ){
	  ascii = '^';
	  p++;
	}else{
	  ascii = (*p++ & 0x1F);
	}
      }else{
	ascii = *p++;
      }
      jump_table[ 1 + ascii ] = command_list1[ i ].command;
    }
  }
  
  for(int i=0 ; i<numof(command_list2) ; i++ ){
    jump_table[ 257 + command_list2[i].keyno ]
      = command_list2[i].command ;
  }
  return 0;
}
