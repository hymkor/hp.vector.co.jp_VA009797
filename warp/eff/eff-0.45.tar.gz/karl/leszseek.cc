#include <alloca.h>
#include <ctype.h>
#include <string.h>
#include <sys/video.h>
#include <sys/kbdscan.h>
#include <stdlib.h>
#include <sys/winmgr.h>
#include "getline.h"
#include "wminput.h"

#include "lesz.h"

unsigned PROMPT_COLOR	= 0x0A ,ANSWER_COLOR	= 0x0F ;

wm_handle inputWindow;

int line_input( const char *prompt , char *buffer , size_t size )
{
  int screen_width , screen_height;
  v_dimen( &screen_width , &screen_height );
  
  /* ���߂ČĂяo�������ׂ̈̏��������� */
  static WmInput *input=NULL;
  if( input == NULL ){
    if( wm_init(2) == 0 )
      return -1;
    inputWindow = wm_create(   0             , screen_height-2 
			    , screen_width-1 , screen_height-1
			    , 0, 0x00 , 0xF );
    input = new WmInput(inputWindow);
    if( input == NULL )
      return -1;
  }
  wm_open( inputWindow );

  wm_clear( inputWindow );
  wm_gotoxy( inputWindow , 0 , 0 );

  wm_attrib( inputWindow , PROMPT_COLOR );
  wm_puts( inputWindow , prompt );

  wm_attrib( inputWindow , ANSWER_COLOR );
  const char *s=input->getline(buffer);
  
  if( s == NULL ){
    wm_close(inputWindow);
    return -1;
  }
  
  strncpy( buffer , s , size-1);
  buffer[size-1] = '\0';
  int len=strlen(s);
  // free(s);
  
  wm_close(inputWindow);
  return len;
}

int Line::check( const char *str )
{
  int strsiz = strlen(str);
  
  int n=len-strsiz;
  
  if( n < 0 )
    return -1;
  
  const unsigned char *bp=buffer;
  
  for(int j=0 ; j<n ; j++ ){
    if( (*bp & 255) == (*str & 255) ){
      const char *_bp  = (const char *)bp;
      const char *_str = str;
      
      for(int i=1 ; (*_bp&255) == (*_str&255) ; i++ ){
	if( i >= strsiz )
	  return j;
	
	_bp += 2 ;
	_str++;
      }
    }
    bp += 2;
  }
  return -1 ;
}

int Window::seek_in_win( const char *seekstr )
{
  int count=0;
  for(  Line *ptr=heaven 
      ; ptr != NULL && ptr != earth
      ; ptr=buf.nextline(ptr) ){

    if( ptr->check( seekstr ) >= 0 )
      count++;
  }
  return count;
}

int Window::seek_forward( const char *str )
{
  Window sekwin = *this ;
  unsigned char i=0;
  print_wait_a_moment();
  while( sekwin.forward() == 0 ){
    if( i++ == 0 ){
      int key=getkey(0);
      if( key=='\x1B' || key=='\x07' )
	break;
    }
    if( sekwin.earth->check(str) >= 0 ){
      *this = sekwin;
      return 1;
    }
  }
  return 0;
}

int Window::seek_backward( const char *str )
{
  Window sekwin = *this ;
  
  while( sekwin.backward() == 0 ){
    if( sekwin.heaven->check(str) >= 0 ){
      *this = sekwin;
      return 1;
    }
  }
  
  return 0;
}

static char seek_buffer[256] = "\0";

static enum {
  SEEK_FORWARD ,
  SEEK_BACKWARD ,
  NOT_SEEK ,
} seek_direct=NOT_SEEK ;

command_t command_seek_forward( Pager &win )
{
  const char prompt[]="Forward Search :";
  int max=screen_width-sizeof(prompt);
  
  if( line_input( prompt , seek_buffer , max ) > 0 ){
    if( win.seek_in_win( seek_buffer ) == 0 ){
      // ���݂̉�ʏ�ɁA���������񂪈���Ȃ������Ƃ������A�O���������s���B
      win.seek_forward( seek_buffer );
    }
    win.repaint_seeking( seek_buffer );
    seek_direct = SEEK_FORWARD ;
  }
  win.disp_status();
  
  return CONTINUE;
}

command_t command_seek_backward( Pager &win )
{
  const char prompt[]="Backward Search :";
  int max=screen_width-sizeof(prompt);
  
  if( line_input( prompt , seek_buffer , max ) > 0 ){
    if( win.seek_in_win( seek_buffer ) == 0 ){
      win.seek_backward( seek_buffer );
    }
    win.repaint_seeking( seek_buffer );
    seek_direct = SEEK_BACKWARD ;
  }
  
  win.disp_status();
  
  return CONTINUE;
}

command_t command_seek_next( Pager &win )
{
  switch( seek_direct ){
  case SEEK_FORWARD:
    win.seek_forward ( seek_buffer );	break;
  case SEEK_BACKWARD:
    win.seek_backward( seek_buffer );	break;
  default:
    break; /* �{���͒u����̂��� */
  };
  win.repaint_seeking( seek_buffer );
  return CONTINUE;
}

command_t command_seek_reverse( Pager &win )
{
  switch( seek_direct ){
  case SEEK_FORWARD:
    win.seek_backward( seek_buffer );	break;
  case SEEK_BACKWARD:
    win.seek_forward ( seek_buffer );	break;
  default:
    break; /* �{���͒u����̂��� */
  };
  win.repaint_seeking( seek_buffer );
  return CONTINUE;
}

		
