#include "jobs.h"
#include "os2eff.h"

HAB Jobs::hab;

Jobs::Jobs()
{
  static int firstcall=1;
  if( firstcall ){
    hab = WinInitialize(0);
    firstcall = 0;
  }
  count = WinQuerySwitchList(hab,NULL,0);
  int size = count*sizeof(SWENTRY) + sizeof( ULONG );
  
  pswblock = (PSWBLOCK)malloc( size );
  if( pswblock != NULL ){
    WinQuerySwitchList(hab,pswblock,size);
  }else{
    count = 0;
  }
}

void Jobs::fg(int i)
{
  if( i < N() ){
    // WinSwitchToProgram( pswblock->aswentry[i].hswitch );
    WinShowWindow( pswblock->aswentry[i].swctl.hwnd , TRUE );
  }
}

void Jobs::bg(int i)
{
  if( i < N() ){
    WinShowWindow( pswblock->aswentry[i].swctl.hwnd , FALSE );
  }
}
