#include "merge.h"

struct TstStack {
  TstStack *prev,*next;
  char buffer[1];
};

int compare(TstStack *,TstStack *)
{
  return -1;
}

int main(int argc,char **argv)
{
  TstStack *teststack;

  teststack = merge_sort (teststack , &compare );
  return 0;
}
