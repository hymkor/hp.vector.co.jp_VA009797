/* -*- c++ -*- */

#ifndef OS2EFF_H
#define OS2EFF_H

#include <os2.h>

#ifdef THEDIR_H1
#  include "thedir.h"
#endif
#ifdef SEM_H1
#  include "sem.h"
#endif
#ifdef JOBS_H1
#  include "jobs.h"
#endif

#endif


