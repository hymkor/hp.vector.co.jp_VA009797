#define INCL_VIO
#include "os2eff.h"

void box_cursor_on()
{
  VIOCURSORINFO info;

  info.yStart = 0;
  info.cEnd   = (unsigned short)-100;
  info.cx     = 0;
  info.attr   = 0;
  VioSetCurType( &info , 0 );
}

void cursor_off()
{
  VIOCURSORINFO info;

  info.yStart = 0;
  info.cEnd   = 0;
  info.cx     = 0;
  info.attr   = 0xFFFF;
  VioSetCurType( &info , 0 );
}
