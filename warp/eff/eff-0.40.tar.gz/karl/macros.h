#ifndef MACROS_H
#define MACROS_H

#undef numof
#define numof(A) (int)(sizeof(A) / sizeof((A)[0]))

#undef KEY
#define KEY(X) ( (K_ ## X) | 0x100 )

#undef CTRL
#define CTRL(X) ( (X) & 0x1F )

class MallocError{ };

#ifdef __cplusplus
inline int is_kanji( int c )
{
  c &= 0xFF;
  return  ( 0x81 <= c  &&  c <= 0x9f )
    ||	( 0xe1 <= c  &&  c <= 0xfc );
}
#else
#	define is_kanji(c) (\
			( 0x81 <= (c)  && (c) <= 0x9f )	\
		||	( 0xe1 <= (c)  && (c) <= 0xfc )		)

#endif /* __cplusplus */

#endif /* MACROS_H */
