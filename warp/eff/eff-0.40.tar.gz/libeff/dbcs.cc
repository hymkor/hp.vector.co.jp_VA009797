#include <stdlib.h>
#include <string.h> 
#include "effetc.h"

#define INCL_DOSNLS
#include "os2eff.h"

int dbcsInit()
{
  static int second_called=0;
  if( second_called || _osmode != OS2_MODE )
    return 0;
  second_called = 1;
  
  //  DBCS table �� DBCS�r�b�g��S�� 0 �ɂ���B
  for(int i=0;i<numof(dbcsTable);i++)
    dbcsTable[ i ] &= ~1;
  
  // OS/2 �̏ꍇ�AAPI �֐����Ă�ŁA�ݒ肷��B
  
  char buffer[12];    
  COUNTRYCODE country;
  
  country.country = 0;
  country.codepage = 0;
  
  int rc=(int)DosQueryDBCSEnv((ULONG)numof(buffer)
			      ,&country
			      ,buffer);
  char *p=buffer;
  while( (p[0] !=0 || p[1] !=0) && p < buffer+sizeof(buffer) ){
    int start=p[0] & 255;
    int end=p[1] & 255;
    for(int i=start ; i < end ; i++ )
      (dbcsTable+128)[ i ] |= 1;
    
    p += 2;
  }
  memcpy( dbcsTable , dbcsTable+256 , 128 );
  return rc;
}
