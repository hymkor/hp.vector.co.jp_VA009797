#undef DEBUG
#include <assert.h>
#include <alloca.h>
#include <assert.h>
#include <ctype.h>
#include <io.h>
#include <signal.h>
#include <cstdlib>
#include <string.h>

#include <sys/ioctl.h>
#include <sys/video.h>
#include <sys/kbdscan.h>
#include <sys/ptrace.h>

#define INCL_DOSNLS

#include "lesz.h"
#include "os2eff.h"

extern void heapCheck(const char *);

#ifdef DEBUG
#  define DEBUG1(x) (x)
#else
#  define DEBUG1(x)
#endif

int rawmode = 0 , nobsmode = 0 ;

unsigned TEXT_COLOR     = 0x0F;
unsigned CTRL_COLOR     = 0x0E;
unsigned TITLE_COLOR    = 0x70;
unsigned REV_CTRL_COLOR = 0xE1;
unsigned UL_COLOR       = 0x0A;
unsigned BOLD_COLOR     = 0x0C;

int jump_table_init();
extern command_t (*jump_table[])( Pager & );
const char *program_name;
char *original_screen=0;

int screen_width , screen_height;
int original_cursor_x  , original_cursor_y ;
int screen_size;

/* LESZ(KARL) �̃G���g���[���[�`���̋��ʕ����B
 * �ʏ�́A�ʂ̈������ő��d��`���ꂽ lesz() ���Ăяo�����B
 *	buffer �ǂݍ��݃o�b�t�@
 */
static int lesz( Buffer &buffer )
{
  program_name = "eff";
  
  // ��ʂ̕ۑ�
  v_getxy( &original_cursor_x , &original_cursor_y );

  original_screen
    = (char*)_tmalloc( (screen_size = screen_width * screen_height)*2 );
  if( original_screen == NULL )
    return -1;

  v_getline( original_screen , 0 , 0 , screen_size );
  int original_attrib = v_getattr();

  Pager win( buffer , 0 , 0 , screen_height );
  win.paint_top();

  if( buffer.getStatus() != Buffer::ENDOFFILE )
    buffer.beginBackgroundThread();

  jump_table_init();
  // ���C�����[�`��
  for(;;){
    int key = getkey( MULTITHREAD );
    switch( (*jump_table[ key + 1 ] )(win) ){
      
    case RESTORE_QUIT: // �ۑ�������ʂ��񕜂��ďI��
      v_putline( original_screen , 0 , 0 , screen_size );
      v_gotoxy( original_cursor_x , original_cursor_y );
      v_attrib( original_attrib );
      _tfree(original_screen);
      return 0;
      
    case QUIT: // ��ʂ����̂܂܂ɂ��ďI��
      v_gotoxy( 0 , screen_height-1 );
      v_attrib( original_attrib );
      _tfree(original_screen);
      return 0;
      
    default:
      ;
    }
  }// end for(;;)
}

/* ��ʃT�C�Y���L�^���Ă��� */
inline void setScrnSize()
{
  v_dimen( &screen_width , &screen_height );
}

/* �W�����͌o�R�œ��͂��� karl
 *
 */
int lesz_stdin( const char *title )
{
  setScrnSize();

  Buffer buffer(screen_width);
  if( buffer.open(stdin,title) == 0 )
    return lesz(buffer);
  return -1;
}

/* �ʏ�t�@�C��������͂��� karl */
int lesz_file( const char *fname )
{
  DEBUG1( fputs("ENTER lesz_file\n",stderr) );
  DEBUG1(heapCheck("lesz_file:1st"));

  setScrnSize();

  Buffer buffer(screen_width);
  int rc = buffer.open(fname,fname);
  if( rc == 0 ){
    DEBUG1( heapCheck("lesz_file:2nd") );
    rc=lesz( buffer );
    DEBUG1( heapCheck("lesz_file:3rd") );
    return rc;
  }
  DEBUG1( fprintf(stderr,"LEAVE lesz_file with %d.\n",rc) );
  DEBUG1( heapCheck("lesz_file:4th") );
  return -1;
}

/* �p�C�v�o�R�œ��͂��� karl */
int lesz_pipe( const char *command , const char *title )
{
  int rc=0;
  FILE *fp=popen(command,"rb");
  if( fp == NULL )
    return 1;
  
  setScrnSize();  
  {
    Buffer buffer(screen_width);
    if( buffer.open(fp,title) == 0 )
      rc=lesz(buffer);
  }
  pclose(fp);
  return rc;
}
ULONG codepages[8];
