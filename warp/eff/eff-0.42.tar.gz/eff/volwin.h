// -*- c++ -*-
#ifndef DRVWIN_H
#define DRVWIN_H

#include "anywin.h"

class VolWindow : public AnyWindow {
  class Iterator; friend class Iterator;
public:
  static const char *driveCharToString(int letter);
private:
  static struct VolumeInfo{
    unsigned long serial;
    unsigned char label_length;
    char label[30];
  } volume['Z'-'A'+1];
  static char fileSystem['Z'-'A'+1][8];

  int ndrives;			// �h���C�u���^�[�̐�
  AnyWindow::Status runVolWindow(int key);
protected:
  // AnyWindow �̉��z�֐��̒�`

  void drawTitle();
public:  
  VolWindow(int x,int y,int w,int h);
  ~VolWindow();
protected:
  Status run(int key)
    { return runVolWindow(key); }
  
  class Iterator : public AnyWindow::Iterator {
    VolWindow &drvwin;
  public:
    Iterator(VolWindow &d) : drvwin(d){ }
    Iterator(const Iterator &it) : AnyWindow::Iterator(it), drvwin(it.drvwin)
      { }
    
    int can_forward() const
      { return N() < drvwin.ndrives-1; }
    int forward()
      { return N() < drvwin.ndrives-1 ? ++n : -1; }
    int backward()
      { return 0 < N() ? --n : -1; }
    AnyWindow::Iterator *dup() const
      { return new Iterator(*this); }
    void mark(int){ }
    int mark()const
      { return 0; }
    void putat(int x,int y,int w);
    const char *getName() const { return driveCharToString(N()); }
    int getDriveLetter() const { return 'A'+N(); }
  };

  Iterator *getHeaven(){ return (Iterator*)heaven; }
  Iterator *getCursor(){ return (Iterator*)cursor; }
  Iterator *getEarth(){  return (Iterator*)earth;  }
};

#endif
