#include <assert.h>
#include <stdlib.h>
#include <string.h>

#include "effetc.h"
#include "thedir.h"
#include "files.h"
#include "os2eff.h"

int Files::compare(  Files::DirDateTime &A , Files::DirDateTime &B ) throw()
{
  int rc=A.date - B.date;
  if( rc==0 )
    return A.time - B.time;
  return rc;
}

int Files::compare(Files::Node *X,Files::Node *Y,int method) throw()
{
  int rc=0;

  if( method & SORT_DIRTOP ){

    if( (X->attr & DIRECTORY )==0 ){ /* X �̓t�@�C�� */
      if( (Y->attr & DIRECTORY) != 0 ) /* X �̓f�B���N�g�� */
	return +1;

    }else{ /* X �̓f�B���N�g�� */
      
      if( (Y->attr & DIRECTORY) == 0 ) /* Y �̓t�@�C�� */
	return -1;
    }
  }
  switch( method & SORT_MASK ){
  case SORT_BY_SUFFIX:
    {
      const char *x_sfx=NULL , *y_sfx=NULL;
      const char *xp=X->name , *yp=Y->name;
      while( *xp != '\0' ){
	if( *xp == '.' ){
	  x_sfx = xp+1;
	}else if( *xp == '/' || *xp == '\\' ){
	  x_sfx = NULL;
	}
	++xp;
      }
      while( *yp != '\0' ){
	if( *yp == '.' ){
	  y_sfx = yp+1;
	}else if( *yp == '/' || *yp == '\\' ){
	  y_sfx = NULL;
	}
	++yp;
      }
      if( x_sfx == NULL ){
	if( y_sfx == NULL )
	  rc = strcmp(X->name,Y->name);
	else
	  rc = -1;
      }else{
	if( y_sfx == NULL ){
	  rc = +1;
	}else{
	  rc = strcmp(x_sfx,y_sfx);
	  if( rc == 0 )
	    rc = strcmp(X->name,Y->name);
	}
      }
    }
    break;

  case SORT_BY_NUMERIC:
    rc = strnumcmp(X->name,Y->name);
    if( rc == 0 )
      rc = strcmp(X->name,Y->name);
    break;

  case SORT_BY_NAME_IGNORE:
    rc = stricmp(X->name,Y->name);
    if( rc != 0 )
      break;
    /* continue to next case */

  case SORT_BY_NAME:
    rc = strcmp(X->name,Y->name);
    break;

  case SORT_BY_SIZE:
    rc = Y->size - X->size;
    if( rc == 0 )
      rc = strcmp(X->name,Y->name);
    break;

  case SORT_BY_CHANGE_TIME:
    if( (rc=compare( Y->create , X->create )) == 0 )
      rc = strcmp( Y->name , X->name );
    break;

  case SORT_BY_LAST_ACCESS_TIME:
    if( (rc=compare( Y->access , X->access )) == 0 )
      rc = strcmp(X->name,Y->name);
    break;

  case SORT_BY_MODIFICATION_TIME:
    if( (rc=compare( Y->write , X->write )) == 0 )
      rc = strcmp(X->name,Y->name);
    break;
    
  default:
    rc = -1;
    break;
  }

  if( method & SORT_REVERSE )
    return -rc;
  else
    return rc;
}

void Files::sort_and_insert(Files::Node *tmp ,int method=0)
{
  int diff;
  allsize += tmp->size;
  ++nfiles;

#if 0
  if( first == NULL ){
    first = tmp;
    tmp->parent = NULL;
  }else{
    Files::Node *ptr=first;
    for(;;){
      diff = compare(ptr,tmp,method);
      if( diff < 0 ){
	if( ptr->low == NULL ){
	  ptr->low = tmp;
	  tmp->parent = ptr;
	  break;
	}
	ptr = ptr->low ;
      }else{ /* diff �� 0 */
	if( ptr->high = NULL ){
	  ptr->high = tmp;
	  tmp->parent = ptr;
	  break;
	}
	ptr = ptr->high;
      }
    }
  }
  tmp->low = tmp->high = NULL;
#else
  if( first == NULL || (diff=compare(tmp,first,method)) <= 0 ){
    tmp->next = first;
    tmp->prev = NULL;
    if( first != NULL ){
      assert( first->prev == NULL );
      first->prev = tmp;
    }
    first = tmp;
    return;
  }
  Node *prev=first,*cur=first->next;
  for(;;){
    if( cur == NULL ){
      prev->next = tmp;
      tmp->next  = NULL;
      tmp->prev  = prev;
      break;
    }
    int diff=compare(tmp,cur,method);
    
    if( diff <= 0 ){
      prev->next = tmp;
      cur ->prev = tmp;
      
      tmp->prev = prev;
      tmp->next = cur;

      break;
    }
    prev = cur;
    cur = cur->next;
  }
#endif
}

Files::Node *Files::merge_sort(Files::Node *list,int method) throw()
{
  if( list == NULL  || list->next == NULL )
    return list;

  /* �܂��́A���X�g��񕪊� */
  Files::Node *tail=list , *half=list;
  while( tail != NULL ){
    tail = tail->next;
    if( tail == NULL )
      break;
    half = half->next;
    tail = tail->next;
  }
  Files::Node *list2=half;
  half->prev->next = NULL;
  half->prev = NULL;

  /* �\�[�g */
  list  = merge_sort( list  , method );
  list2 = merge_sort( list2 , method );
  if( list == NULL )
    return list2;
  if( list2 == NULL )
    return list;
  
  /* �}�[�W */
  Files::Node *merge;
  if( compare(list,list2,method) < 0 ){
    merge = list;
    list = list->next;
  }else {
    merge = list2;
    list2 = list2->next;
  }
  merge->prev = NULL;

  Files::Node *result=merge;
  for(;;){
    if( list == NULL ){
      merge->next = list2;
      if( list2 != NULL )
	list2->prev = merge;
      return result;
    }else if( list2 == NULL ){
      merge->next = list;
      if( list != NULL )
	list->prev = merge;
      return result;
    }else if( compare(list,list2,method) < 0 ){
      list->prev = merge;
      merge = merge->next = list;
      list = list->next;
    }else{
      list2->prev = merge;
      merge = merge->next = list2;
      list2 = list2->next;
    }
  }
}
