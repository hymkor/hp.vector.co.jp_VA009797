#undef DEBUG
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <sys/video.h>
#include <sys/kbdscan.h>

#include "effetc.h"
#include "anywin.h"
#include "getline.h"
#include "wminput.h"
#include "effcfg.h"
#include "strbuffer.h"
#include "macros.h"

#define VER "0.41"

bool AnyWindow::is_message_remained=true;

int AnyWindow::default_devide_number=2;

static void V_xorattr(int xor,int x,int y,int count)
{
  char *buffer=(char*)_tmalloc(count*2);
  v_getline(buffer,x,y,count);
  short *p=(short*)buffer;
  xor <<= 8;
  for(int i=0;i<count;i++)
    *p++ ^= xor;
  v_putline(buffer,x,y,count);
  _tfree(buffer);
}

int readkey()
{
  /* �[������ł͂Ȃ��AVIO �� _read_kbd ���g���Ă���̂́A���x��
   * �l�����Ă̂��ƁBtermio ���g���ƁA�ǂ����x���炵���B
   */
  int key=_read_kbd(0,1,0);
  if( key == 0 )
    return 0x100 | _read_kbd(0,1,0);
  else if( isKanji(key) )
    return (key << 8 ) | (_read_kbd(0,1,0) & 0xff);
  else
    return key;
}

wm_handle AnyWindow::console_handle;
AnyWindow *AnyWindow::first = NULL , *AnyWindow::garbage = NULL;

static VioCannaInput *searchinput = 0;
static int search_direct = 0;

int AnyWindow::Iterator::gotoN(int N)
{
  if( N > n ){
    while( can_forward() && N > n )
      forward();
  }else if( N < n ){
    while( can_backward() && N < n )
      backward();
  }
  return n;
}

void AnyWindow::open(int x,int y,int w,int h)
{
  windowStatus = ALIVE;

  x0 = x ; y0 = y ; width = w ; height = h-1;
  /* ���łɘA������Ă�����A���̘A������U�O�� */
  if( next != NULL )    next->prev = prev;
  if( prev != NULL )    prev->next = next;

  /* �ĘA�� */

  if( first == NULL ){
    prev = next = NULL;
    first = this;
    return;
  }
  if( this->y0 < first->y0 ){
    next = first;
    prev = NULL;
    first->prev = this;
    first = this;
    return;
  }
  
  AnyWindow *cur=first;
  AnyWindow *nxt=cur->next;
  while( nxt != NULL ){
    if( cur->y0 <= this->y0  &&  this->y0 < nxt->y0  ){
      // cur �� this �� nxt �Ȃ�΁Acur �̎���this ����������B
      assert( nxt->prev == cur );
      cur->next = this;
      nxt->prev = this;
      this->prev = cur;
      this->next = nxt;
      return;
    }
    cur = nxt;
    nxt = nxt->next;
  }
  // ���[�ɐڑ�����B
  cur->next = this;
  this->prev = cur;
  this->next = NULL;
}

void AnyWindow::close()
{
  if( windowStatus == ALIVE ){
    if( next != NULL ){
      /* �s�����̃E�C���h�E�ɕ����^���� */
      next->y0 = this->y0;
      next->height += this->height+1;
    }else if( prev != NULL ){
      /* �s��O�̃E�C���h�E�ɕ����^���� */
      prev->height += this->height+1;
    }
    /* �㉺�ɃE�C���h�E�������ꍇ�͂ǂ����悤���Ȃ� */


    if( next != NULL )    next->prev = prev;
    if( prev != NULL )    prev->next = next;
    if( first == this )	first = next;
    
    prev = NULL;
    next = garbage;
    if( garbage != NULL )
      garbage->prev = this;
    garbage = this;
  }
  windowStatus = DEAD;
}

AnyWindow *AnyWindow::getFocus(int line)
{
  for( AnyWindow *cur=first ; cur != NULL ; cur=cur->next ){
    if( cur->y0 <= line  &&  line < cur->y0+cur->height )
      return cur;
  }
  return NULL;  
}

void AnyWindow::replace( AnyWindow *another )
{
  this->close();
  another->open(x0,y0,width,height+1);
}


void AnyWindow::execute()
{
  while( garbage != NULL ){
    AnyWindow *nxt=garbage->next;
    delete garbage;
    garbage = nxt;
  }
}

AnyWindow::~AnyWindow(void)
{
  // ��{�I�Ƀf�X�g���N�^�ł́A�|�C���^�̂Ȃ����킹�݂̂ɖ��߁A
  // ��L���Ă����s�̈Ϗ��ɂ��ẮAAnyWindow::main �ɑ����B

  if( top ) delete top;
  if( heaven ) delete heaven;
  if( earth ) delete earth;
  if( cursor )delete cursor;
  
  if( windowStatus == ALIVE ){
    if( next != NULL )
      next->prev = this->prev;
    
    if( prev != NULL ){
      prev->next = this->next;
    }else if( first == this ){
      first = next;
    }
  }
}

int AnyWindow::input_line=23;

void AnyWindow::repaint(void)
{
  // �J�[�\���s�ʒu���L��������B
  assert( heaven != NULL );
  int nHeaven = 0;
  if( heaven != NULL )
    nHeaven = heaven->N();
  int nCursor = nHeaven;
  if( cursor != NULL ){
    nCursor = cursor->N();
    delete cursor;
    cursor = NULL;
  }
  
  // heaven �ȍ~�̍s�̍ĕ\��
  v_attrib( STANDARD_COLOR );
  if( earth != NULL )
    delete earth;
  earth = heaven->dup();

  int j=0; /* 0...ndevide-1 */
  int i=0; /* 0...height -1 */
  for(;;){
    // v_gotoxy( x0 , y0+i );
    // earth->putat(x0,y0+i,width);

    earth->putat(  x0+(width*j/ndevide) 
		 , y0+i
		 , (width*(j+1)/ndevide)-(width*j/ndevide) );
    
    if( ++i >= height ){
      i=0;
      if( ++j >= ndevide )
	break;
    }

    if( ! earth->can_forward() ){
      for( ; j < ndevide ; j++ ){
	for( ; i < height ; i++ )
	  v_scroll(  x0+(width*j/ndevide)
		   , y0+i
		   , x0+(width*(j+1)/ndevide )
		   , y0+i
		   , 1
		   , V_SCROLL_CLEAR );
	i = 0;
      }
      break;
    }
    earth->forward();
  }
  int nEarth = earth->N();
  
  // �J�[�\���s�ʒu�̉�
  cursor = heaven->dup();
  if( nCursor <= nEarth )
    cursor->gotoN(nCursor);
  
  // v_gotoxy( x0 , y0+height );
  drawTitle();
}

static char *line_buffer=NULL;

void AnyWindow::scrollup(void)
{
  if( earth->forward() >= 0 ){
    heaven->forward();
    if( ndevide >= 2 ){
      if( line_buffer == NULL ){
	line_buffer = (char*)_tmalloc( width*2 );
      }
      v_getline( line_buffer , x0 , y0 , width );
    }
    v_scroll(x0,y0,x0+width-1,y0+height-1,1,V_SCROLL_UP);
    if( ndevide >= 2 ){
      v_putline(  line_buffer+(width/ndevide)*2
		, x0
		, y0+height-1
		, width-width/ndevide );
    }
    earth->putat(  x0+(width-width/ndevide)
		 , y0+height-1
		 , width/ndevide);
  }
}

AnyWindow::Status AnyWindow::gotoRight(int)
{
  if( cursor->N() + height <= earth->N() ){
    /* �E�Ɉړ��\ */
    for(int i=0;i<height;i++){
      if( ! cursor->can_forward() )
	break;
      cursor->forward();
    }
  }else if( earth->can_forward() != NULL ){
    /* �E�Ɉړ��ł��Ȃ��̂ŁA���փX�N���[�������� */
    for(int i=0;i<height;i++){
      if( cursor->can_forward() )
	cursor->forward();
      heaven->forward();
    }
    repaint();
  }
  return CONTINUE;
}

AnyWindow::Status AnyWindow::gotoLeft(int)
{
  if( cursor->N() - height >= heaven->N() ){
    /* ���ֈړ��\ */
    for(int i=0;i<height;i++){
      if( ! cursor->can_backward() )
	break;
      cursor->backward();
    }
  }else if( heaven->can_backward() ){
    for(int i=0;i<height;i++){
      heaven->backward();
      cursor->backward();
    }
    repaint();
  }
  return CONTINUE;
}


void AnyWindow::scrolldown(void)
{
  if( heaven->backward() >= 0 ){
    if( ndevide >= 2 ){
      if( line_buffer == NULL ){
	line_buffer = (char*)_tmalloc( width*2 );
      }
      v_getline( line_buffer , x0 , y0+height-1 , width );
    }
    v_scroll(x0,y0,x0+width-1,y0+height-1,1,V_SCROLL_DOWN);
    if( earth->N()-heaven->N() >= height*ndevide )
      earth->backward();
    if( ndevide >= 2 ){
      v_putline(  line_buffer
		, x0+(width/ndevide)
		, y0
		, width-width/ndevide );
    }
    heaven->putat( x0 , y0 , width/ndevide );
  }
}

void AnyWindow::repaint_cursor_line(void)
{
  int i=cursor->N()-heaven->N();
  int x=(i / height);
  int y=(i % height);

  cursor->putat(  x0+(width*x/ndevide)
		, y0+y
		, (width*(x+1)/ndevide)-(width*x/ndevide) );

  // cursor->putat(x0+(i / height),y0+(i % height),width/ndevide);
}

AnyWindow::Status AnyWindow::forward(int)
{
  if( cursor->forward() >= 0  &&  cursor->N() > earth->N() )
    scrollup();
  return CONTINUE;
}

AnyWindow::Status AnyWindow::backward(int)
{
  if( cursor->backward() >= 0  &&  cursor->N() < heaven->N() )
    scrolldown();
  return CONTINUE;
}

AnyWindow::Status AnyWindow::forward_page(int)
{
  int nCursor=0;
  if( cursor != NULL ){
    nCursor = cursor->N() - heaven->N();
    delete cursor;
  }
  
  for(int i=0 ; i<height  &&  earth->forward() >= 0 ; i++)
    heaven->forward();

  cursor = heaven->dup();
  for(int i=0;i<nCursor && cursor->can_forward() ;i++)
    cursor->forward();

  repaint();
  return CONTINUE;
}

AnyWindow::Status AnyWindow::backward_page(int)
{
  int nCursor=0;
  if( cursor != NULL ){
    nCursor = cursor->N() - heaven->N();
    delete cursor;
  }

  for(int i=0;i<height  &&  heaven->backward() >= 0 ;i++)
    ;
  
  cursor = heaven->dup();
  for(int i=0;i<nCursor && cursor->can_forward() ;i++)
    cursor->forward();

  repaint();
  return CONTINUE;
}

// �Œ�Aheaven ���ݒ肳��Ă���Ύ��s�\ 
void AnyWindow::search_for_forward(const char *searchstr)
{
  // �܂��͉�ʂɕ\������Ă���s��T���B
  Iterator *ptr=(cursor != 0 ?  cursor->dup() : heaven->dup() );
  for(;;){
    if( ! ptr->can_forward() )
      return;
    ptr->forward();
    if( ptr->N() >= heaven->N()+height )
      break;
    if( strstr( ptr->getName(),searchstr) != NULL ){
      delete cursor;
      cursor = ptr;
      return;
    }
  }
  // ���ɉ�ʊO�̍s��T���B
  Iterator *top=heaven->dup();
  top->forward();
  for(;;){
    if( strstr( ptr->getName(),searchstr) != NULL ){
      delete heaven;  heaven = top;
      if( cursor != 0 ) delete cursor;
      cursor = ptr;
      if( earth != 0 ) delete earth;
      earth  = ptr->dup();
      repaint();
      return;
    }
    if( ! ptr->can_forward() )
      break;
    
    top->forward();
    ptr->forward();
  }
  delete top;
  delete ptr;
  return;
}

// �Œ� heaven �����ݒ肳��Ă���΁A���s�\  
void AnyWindow::search_for_backward(const char *searchstr)
{
  Iterator *ptr;
  // �J�[�\�����ݒ肳��Ă���΁A�J�[�\���s�`�ŏ�s���܂��T���B 
  if( cursor != 0 ){
    ptr=cursor->dup();
    for(;;){
      if( !ptr->can_backward() )
	return;
      ptr->backward();
      if( ptr->N() < heaven->N() )
	break;
      if( strstr( ptr->getName(),searchstr) != NULL ){
	delete cursor;
	cursor = ptr;
	return;
      }
    }
  }else{
    ptr = heaven->dup();
  }
  // ��ʊO��T�� 
  for(;;){
    if( strstr( ptr->getName(),searchstr) != NULL ){
      delete heaven;  heaven = ptr;
      if( cursor != 0 ) delete cursor;  
      cursor = ptr->dup();
      if( earth != 0 )  delete earth;
      earth  = 0;
      repaint();
      return;
    }
    if( ! ptr->can_backward() )
      break;
    ptr->backward();
  }
  delete ptr;
}

AnyWindow::Status AnyWindow::search_for_forward(int)
{
  if( searchinput == 0  &&  (searchinput = new WmInput(console_handle))==0 ){
    DEBUG1( fputs( "(AnyWindow::search_for_forward) new WmInput failed.\n"
		  , stderr ) );
    return CONTINUE;
  }
  
  message( "Search forward for :" );
  const char *searchstr=searchinput->getline();
  message( " " );
  if( searchstr == NULL )
    return CONTINUE;

  search_direct = 0;
  search_for_forward( searchstr );
  return CONTINUE;
}

AnyWindow::Status AnyWindow::search_for_backward(int)
{
  if( searchinput==0 && (searchinput = new WmInput(console_handle))==0 ){
    DEBUG1( fputs( "(AnyWindow::search_for_backward) new WmInput failed\n"
		  , stderr ));
    return CONTINUE;
  }
  
  message( "Search backward for :" );
  const char *searchstr=searchinput->getline();
  message( " " );
  if( searchstr == NULL )
    return CONTINUE;

  search_direct = 1;
  search_for_backward( searchstr );
  return CONTINUE;
}

AnyWindow::Status AnyWindow::search_next(int)
{
  if( searchinput == 0 )
    return CONTINUE;

  LineInput::HistoryIterator iter(*searchinput);
  const char *s=*iter;
  if( s == 0 )
    return CONTINUE;

  if( search_direct == 0 )
    search_for_forward(s);
  else
    search_for_backward(s);
  return CONTINUE;
}

AnyWindow::Status AnyWindow::search_reverse(int)
{
  if( searchinput == 0 )
    return CONTINUE;
  
  LineInput::HistoryIterator iter(*searchinput);
  const char *s=*iter;
  if( s == 0 )
    return CONTINUE;

  if( search_direct == 0 )
    search_for_backward(s);
  else
    search_for_forward(s);
  return CONTINUE;
}

AnyWindow::Status AnyWindow::goto_head(int)
{
  delete cursor;
  delete earth;
  
  while( heaven->can_backward() )
    heaven->backward();
  
  cursor = heaven->dup();
  earth  = 0;
  repaint();
  return CONTINUE;
}

AnyWindow::Status AnyWindow::goto_tail(int)
{
  delete cursor;
  while( earth->can_forward() ){
    heaven->forward();
    earth->forward();
  }
  cursor = earth->dup();
  repaint();
  return CONTINUE;
}
AnyWindow::Status AnyWindow::quit(int)
{
  message("Quit ? [Y/N]");
  box_cursor_on();
  if( readkey() == 'y' )
    return QUIT;
  else{
    cursor_off();
    clear_message();
    return CONTINUE;
  }
}

AnyWindow::Status AnyWindow::quit_without_ask(int)
{
  return QUIT;
}

AnyWindow::Status AnyWindow::zero_window(int)
{
  return CLOSE;
}
AnyWindow::Status AnyWindow::next_window(int)
{
  return NEXT;
}

AnyWindow::Status AnyWindow::one_window(int)
{
  int y=y0;
  int h=height+1;
  AnyWindow *it=first ;
  
  while( it != NULL ){
    AnyWindow *nxt=it->next;
    if( it != this ){
      if( it->y0 <= y ){
	y = it->y0;
      }
      h += it->height+1;
      delete it;
    }
    it = nxt;
  }
  y0 = y;
  height = h-1;
  this->repaint();
  return CONTINUE;
}
AnyWindow::Status AnyWindow::do_nothing(int)
{
  return CONTINUE;
}
AnyWindow::Status AnyWindow::markAndForward(int key)
{
  cursor->mark( cursor->mark() ? 0 : 1 );
  repaint_cursor_line();
  forward(key);
  return CONTINUE;
}
AnyWindow::Status AnyWindow::backwardAndMark(int key)
{
  backward(key);
  cursor->mark( cursor->mark() ? 0 : 1 );
  repaint_cursor_line();
  return CONTINUE;
}

AnyWindow::Status AnyWindow::launcher(int key)
{
  extern char *launcherCommands[];

  const static int scancode[]={
    KEY(ALT_A),KEY(ALT_B),KEY(ALT_C),KEY(ALT_D),KEY(ALT_E),KEY(ALT_F),
    KEY(ALT_G),KEY(ALT_H),KEY(ALT_I),KEY(ALT_J),KEY(ALT_K),KEY(ALT_L),
    KEY(ALT_M),KEY(ALT_N),KEY(ALT_O),KEY(ALT_P),KEY(ALT_Q),KEY(ALT_R),
    KEY(ALT_S),KEY(ALT_T),KEY(ALT_U),KEY(ALT_V),KEY(ALT_W),KEY(ALT_X),
    KEY(ALT_Y),KEY(ALT_Z),
  };

  for(int i=0;i<numof(scancode);i++){
    if( key == scancode[i] ){
      if( launcherCommands[i+1] != NULL ){
	ScrnSave scrnsave;
	StrBuffer sbuf;

	for(const char *sp=launcherCommands[i+1] ; *sp != '\0' ; ++sp ){
	  if( *sp != '$' ){
	    sbuf << *sp;
	  }else{
	    switch( *++sp ){
	    case '$':
	      sbuf << '$';
	      break;
	      
	    case 'c':
	    case 'C':
	      sbuf << cursor->getName();
	      break;

	    case '{':
	      {
		StrBuffer prompt;
		while( *++sp != '}' ){
		  if( *sp == '\0' ){
		    message("Syntax Error in configuration file.\n");
		    return CONTINUE;
		  }
		  prompt << *sp;
		}
		message( "%s" , (const char *)prompt );
		VioCannaInput input;
		const char *answer=input.getline();
		message( "\n" );
		if( answer == NULL )
		  return CONTINUE;
		sbuf << answer;
	      }
	      break;

	    case 'm':
	    case 'M':
	      {
		int n=0;
		Iterator *iter=top->dup();
		for(;;){
		  if( iter->mark() ){
		    sbuf << iter->getName() << ' ';
		    ++n;
		  }
		  if( ! iter->can_forward() )
		    break;
		  iter->forward();
		}
		delete iter;
		if( n == 0 )
		  sbuf << cursor->getName();
	      }
	      break;
		
	    }// end switch
	  }
	}
	// message( "%s\n" , (const char *)sbuf );
	wm_cvis( console_handle , 1 );
	box_cursor_on();
	system( sbuf );
	cursor_off();	
	puts("[Hit Any Key]");
	readkey();
	scrnsave.load();
	refresh();
      }
      return CONTINUE;
    }
  }
  return CONTINUE;
}

AnyWindow::Status AnyWindow::one_devide(int)
{
  ndevide = 1;
  delete cursor;
  cursor = NULL;
  repaint();
  return CONTINUE;
}
AnyWindow::Status AnyWindow::two_devide(int)
{
  ndevide = 2;
  delete cursor;
  cursor = NULL;
  repaint();
  return CONTINUE;
}
AnyWindow::Status AnyWindow::four_devide(int)
{
  ndevide = 4;
  delete cursor;
  cursor = NULL;
  repaint();
  return CONTINUE;
}


AnyWindow::Status AnyWindow::runAnyWindow(int key)
{
  static Status (AnyWindow::*jumptable[512])(int);
  static int firstcalled=1;
  if( firstcalled ){
    static struct {
      int key;
      Status (AnyWindow::*method)(int);
    } jumplist[] ={
      { KEY(ALT_1)	, &one_devide },
      { KEY(ALT_2)	, &two_devide },
      { KEY(ALT_4)	, &four_devide },
      { '1'		, &one_window },
      { '0'		, &zero_window },
      { '\t'		, &next_window },
      { KEY(PAGEDOWN)	, &forward_page },
      { CTRL('V')	, &forward_page },
      { KEY(PAGEUP)	, &backward_page },
      { CTRL('Z')	, &backward_page },
      { KEY(DOWN)	, &forward },
      { 'j'		, &forward },
      { CTRL('N')	, &forward },
      { CTRL('X')	, &forward },
      { 'h'		, &gotoLeft },
      { CTRL('B')	, &gotoLeft },
      { KEY(LEFT)	, &gotoLeft },
      { 'l'		, &gotoRight },
      { CTRL('F')	, &gotoRight },
      { KEY(RIGHT)	, &gotoRight },


      { KEY(UP)		, &backward },
      { 'k'		, &backward },
      { CTRL('P')	, &backward },
      { CTRL('E')	, &backward },
      { CTRL('[')	, &quit },
      { 'q'		, &quit },
      { 'Q'             , &quit_without_ask },
      { KEY(CTRL_DOWN)	, &markAndForward },
      { ' '		, &markAndForward },
      { KEY(CTRL_UP)	, &backwardAndMark },
      { '/'		, &search_for_forward },
      { '?'		, &search_for_backward },
      { 'n'		, &search_next },
      { 'N'		, &search_reverse },
      { KEY(HOME)	, &goto_head },
      { '<'		, &goto_head },
      { '>'		, &goto_tail },
      { KEY(END)	, &goto_tail },
    };
    for(int i=0;i<numof(jumptable);i++)
      jumptable[ i ] = &AnyWindow::launcher;
    for(int i=0;i<numof(jumplist);i++)
      jumptable[ jumplist[i].key ] = jumplist[i].method;
    firstcalled = 0;
  }
  if( 0 <= key  &&  key < numof( jumptable ) )
    return (this->*jumptable[ key ])( key );
  else
    return CONTINUE;
}

void AnyWindow::message(const char *fmt,...)
{
  wm_cursor( console_handle );
  wm_cvis( console_handle , 1 );

  va_list vp;
  va_start(vp,fmt);
  char buffer[1024];
  vsnprintf(buffer , sizeof(buffer) , fmt , vp);
  wm_puts( console_handle , buffer );
  va_end(vp);
  
  is_message_remained = true;
}

void AnyWindow::clear_message()
{
  wm_clear( console_handle );
  wm_gotoxy( console_handle , 0 , 0 );
  is_message_remained = false;
}

int AnyWindow::main(int message_line , int nlines )
{
  box_cursor_on();

  if( wm_init(1) == 0 )
    return 0;

  int bottom_line=message_line;
  
  console_handle = wm_create(  0 , message_line
			     , first->width-1 , message_line+nlines-1
			     , 0 , 0x00 , 0x0F );
  wm_open( console_handle );
  clear_message();
  message("The Excellent Filer Ferrari "VER" (c) 1998,1999 HAYAMA,Kaoru");
  if( configurationFileName != NULL )
    message("\n  Config file `%s' is loaded !",configurationFileName);
  is_message_remained = true;
  
  input_line = message_line;

  AnyWindow *focus = first;
  focus->repaint();
  v_hidecursor();

  for(;;){
    int cursorWidth = focus->width/focus->ndevide;
    int focusLine = focus->cursor->N() - focus->heaven->N();
    
    V_xorattr(  0x40 
	      , focus->x0 + cursorWidth * (focusLine/focus->height)
	      , focus->y0 + focusLine % focus->height 
	      , cursorWidth );

    if( ! is_message_remained ){
      if( focus->cursor != NULL ){
	focus->cursor->putat(0,bottom_line,first->width*3);
      }else{
	clear_message();
      }
    }
    ::cursor_off();
    int key = readkey();    // getkey();
    V_xorattr(  0x40 
	      , focus->x0 + cursorWidth * (focusLine/focus->height)
	      , focus->y0 + (focusLine % focus->height) 
	      , cursorWidth );

    clear_message();

    switch( focus->run(key)){
    case REPLACE:
      assert( focus->next != NULL );
      {
	focus->next->y0 = focus->y0;
	focus->next->height = focus->height;
	AnyWindow *newone=focus->next;
	delete focus;
	focus = newone;
      }
      focus->repaint();
      break;

    case CLOSE:
      if( focus->next != NULL ){
	// �����E�C���h�E���ł���Ȃ̂ŁA�������̃E�C���h�E�ɗ^������B
	AnyWindow *newone=focus->next;
	newone->y0      = focus->y0;
	newone->height += (focus->height+1);
	delete focus;
	focus = newone;
      }else if( focus->prev != NULL ){
	// �����E�C���h�E�̗̈�́A������̃E�C���h�E�ɗ^������B
	AnyWindow *newone=focus->prev;
	newone->height += (focus->height+1);
	delete focus;
	focus = newone;
      }else{
	// �Ō�̃E�C���h�E�ł���̂ŁA���I���B
	goto exit;
      }
      focus->repaint();
      break;
      
    case QUIT:
      goto exit;
      
    case NEXT:
      focus = focus->next;
      if( focus == NULL )
	focus = first;
      focus->repaint();
      break;

    case OPEN:
      if( focus->next != NULL )
	focus->next->repaint();
      focus->repaint();
      if( focus->prev != NULL )
	focus->prev->repaint();
      break;
      
    default:
      ; // do nothing
    }
  }
 exit:
  wm_exit();
  return 0;
}
