#include <stdlib.h>
#include <stdio.h>
#include "anywin.h"
#include "dirwin.h"
#include "strbuffer.h"

#define INCL_VIO
#define INCL_WIN
#define INCL_DOSPROCESS
#include <os2.h>
HAB hab,hmq;

/* VIO�v���O��������A�����I�� PM �A�v���P�[�V�����ɉ�����
 * ����ɂ���āAPM �̃N���b�v�{�[�h�̓ǂݏ������\�Ƃ���B
 */
int pretend_pm_application()
{
  PTIB  ptib = NULL;
  PPIB  ppib = NULL;
  APIRET rc = DosGetInfoBlocks(&ptib, &ppib);
  if (rc != 0)
    return rc;
  ppib->pib_ultype = PROG_PM;
  hab = WinInitialize(0);
  hmq = WinCreateMsgQueue(hab, 0);
  if (hmq == NULLHANDLE)
    return rc;
  return 0;
}


/* Ctrl-Insert �ŃR�s�[���ꂽ�t�@�C���Q���L������ */
static struct CopiedFiles {
  CopiedFiles *next;
  int length;
  char name[1];
} *killring;

enum{ MARK2MOVE , MARK2COPY } files_to_do;

static void free_killring()
{
  while( killring ){
    CopiedFiles *nxt = killring->next;
    free( killring );
    killring = nxt;
  }
}

static int insert_file(const char *fname,int len)
{
  CopiedFiles *tmp=(CopiedFiles*)malloc(sizeof(CopiedFiles)+len);
  if( tmp == 0 )
    return -1;
  tmp->length = len;
  strcpy( tmp->name , fname );
  tmp->next = killring;
  killring = tmp;
  return 0;
}

int DirWindow::copy2buffer()
{
  char buffer[ FILENAME_MAX ];
  free_killring();
  
  int nfiles=0;
  StrBuffer sbuf;
  
  for( Files::Iterator iter(files) ; iter.isOk() ; iter.forward() ){
    if( iter.getMark() ){
      nfiles++;
      Files::makeFullPath(  buffer , sizeof(buffer)
			  , getCurrentDir() , iter.getName() );
      
      insert_file( buffer , strlen(buffer) );
      
      if( strchr( buffer , ' ' ) != NULL ){
	sbuf << '"' << buffer << "\" ";
      }else{
	sbuf << buffer << ' ';
      }
    }
  }
  if( nfiles == 0 ){
    Files::makeFullPath( buffer , sizeof(buffer) , getCurrentDir()
			, getCursor()->getName() );
    insert_file( buffer , strlen(buffer) );
    
    if( strchr( buffer, ' ' ) != NULL ){
      sbuf << '"' << buffer << "\" ";
    }else{
      sbuf << buffer << ' ';
    }
    nfiles = 1;
  }
  char *sharemem;
  DosAllocSharedMem(  (void**) &sharemem
		    , NULL
		    , (ULONG) sbuf.getLength()+1
		    , PAG_COMMIT | PAG_READ | PAG_WRITE
		    | OBJ_TILE | OBJ_GIVEABLE );

  strcpy( sharemem , sbuf.getTop() );
  
  WinOpenClipbrd(hab);
  WinSetClipbrdOwner(hab,NULLHANDLE);
  WinEmptyClipbrd(hab);
  WinSetClipbrdData( hab , (ULONG)sharemem , CF_TEXT , CFI_POINTER );
  WinCloseClipbrd(hab);

  return nfiles;
}

AnyWindow::Status  DirWindow::move_to_killring(int)
{
  files_to_do = MARK2MOVE;
  message( "mark %d file(s) to kill\n" , copy2buffer() );
  return CONTINUE;
}

AnyWindow::Status  DirWindow::copy_to_killring(int)
{
  files_to_do = MARK2COPY;
  message( "mark %d file(s) to copy\n" , copy2buffer() );
  return CONTINUE;
}

AnyWindow::Status  DirWindow::paste_from_killring(int)
{
  int success=0;
  int failure=0;
  if( files_to_do == MARK2COPY ){
    for( CopiedFiles *ptr=killring ; ptr != NULL ; ptr=ptr->next ){
      char dstname[ FILENAME_MAX ];
      Files::makeFullPath(  dstname , sizeof( dstname) 
			  , this->getCurrentDir()
			  , Files::getNotDir(ptr->name) );
      if( DosCopy( (PUCHAR)ptr->name , (PUCHAR)dstname , 0 ) == 0 ){
	message( "copy %s to here \n",ptr->name );
	success++;
      }else{
	message( "fail to copy %s\n" , ptr->name );
	failure++;
      }
    }
    updateThisDirectory();
    if( failure > 0 ){
      message( "copied %d file(s). can't copy %d file(s)\n"
	      , success , failure );
    }else{
      message( "copied %d file(s).\n" , success );
    }
  }else{
    for( CopiedFiles *ptr=killring ; ptr != NULL ; ptr=ptr->next ){
      char dstname[ FILENAME_MAX ];
      Files::makeFullPath(  dstname , sizeof( dstname) 
			  , this->getCurrentDir()
			  , Files::getNotDir(ptr->name) );
      if( DosMove( (PUCHAR)ptr->name , (PUCHAR)dstname ) == 0 ){
	message( "move %s to here\n" , ptr->name );
	success++;
      }else{
	message( "fail to move %s\n" , ptr->name );
	failure++;
      }
    }
    for( AnyWindow *cur=AnyWindow::first ; cur ; cur=cur->next ){
      DirWindow *dirptr = dynamic_cast<DirWindow*>(cur);
      if( cur != 0 )
	dirptr->updateThisWindow();
    }
    if( failure > 0 ){
      message( "moved %d file(s). can't move %d file(s).\n"
	      , success , failure );
    }else{
      message( "moved %d file(s).\n" , success );
    }
    free_killring();
  }
  return CONTINUE;
}
