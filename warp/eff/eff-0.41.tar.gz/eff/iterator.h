/* -*- c++ -*- */

#ifndef ITERATOR_H
#define ITERATOR_H

// �قƂ�ǁAJava �� interface �Ɖ����Ă���....

class IteratorBase {
public:
  virtual void forward()=0;
  virtual void backward()=0;
  virtual int  can_forward() const =0;
  virtual int  can_backward() const =0;
  
  virtual int  N() const =0;
  virtual void Title(char *buffer,int size) const =0;
  virtual void Marking(int ch);
  virtual int  Marking(void) const = 0 ; 
};

#endif
