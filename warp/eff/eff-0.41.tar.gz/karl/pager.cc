#undef DEBUG
#include <assert.h>
#include <sys/video.h>
#include <alloca.h>
#include "leszbuf.h"

inline void j_putline(const unsigned char *src, int x, int y, int count)
{  v_putline((const char *)src,x,y,count);  }

void Pager::disp_status()
{
  v_attrib( 0 );
  v_scroll(  x0         , y0+height-1
	   , x0+width-1 , y0+height-1
	   , 1 , V_SCROLL_CLEAR );
  
  v_attrib( Buffer::TITLE_COLOR );
  v_gotoxy( x0 , y0+height-1 );
  const char *s=buf.get_title();
  v_puts( (const char*)s );

  v_gotoxy( x0+width-5 , y0+height-1 );
  if( buf.isEucText() ){
    if( buf.isJisText() ){
      v_putm( "(E+J)" , 5 );
    }else{
      v_putm( "(EUC)" , 5 );
    }
  }else{
    if( buf.isJisText() ){
      v_putm( "(JIS)" , 5 );
    }else if( buf.isNomemo() ){
      v_putm( "(ENG)" , 5 );
    }else if( !buf.isNomemoUnknown() ){
      v_putm( "(JMS)" , 5 );
    }else{
      v_putm( "(UNK)" , 5 );
    }
  }
  v_gotoxy(0,0);
}

int Pager::repaint( Line *top )
{
  v_attrib( Buffer::TEXT_COLOR );
  v_scroll(  x0 , y0
	   , x0+width-1 , y0+height-2
	   , 1 , V_SCROLL_CLEAR );
	
  if( top != NULL ){
    heaven = top;
  }else{
    assert( heaven != NULL );
  }
  
  hell = earth = heaven;
  
  for( int i=0 ; i < lines ; i++ ){
    if( hell == NULL ){
      disp_status();
      return 1;
    }
    
    if( hell->len > 0 ){
      assert( hell->buffer != NULL );
      j_putline( hell->buffer , x0 , y0+i , hell->len );
    }
    earth = hell;
    hell = buf.nextline( hell );
  }
  disp_status();
  return 0;
}

int Pager::repaint_seeking( const char *seekstr , Line *top )
{
  unsigned char *revbuf=(unsigned char*)alloca( width * 2 );
  int nfinds=0;
  
  v_attrib( Buffer::TEXT_COLOR );
  v_scroll( x0 , y0 , x0+width-1 , y0+lines-1 , 1 , V_SCROLL_CLEAR );
  
  if( top != NULL ){
    heaven = top;
  }else{
    assert( heaven != NULL );
  }
  
  hell = earth = heaven;
  
  for( int i=0 ; i < lines ; i++ ){
    if( hell == NULL ){
      disp_status();
      return -1;
    }
    
    if( hell->len > 0 ){
      assert( hell->buffer != NULL );
      
      if( hell->check( seekstr ) >= 0 ){
	// ���������񂪑��݂���s ----> ���]�\��
	for( int j=0 ; j < hell->len ; j++ ){
	  revbuf[ j*2   ] = hell->buffer[ j*2 ];
	  revbuf[ j*2+1 ] = 
	    (( hell->buffer[ j*2+1 ] << 4 ) | ( hell->buffer[ j*2+1 ] >> 4 ));
	}
	j_putline( revbuf , x0 , y0+i , hell->len );
	nfinds++;
      }else{
	// ���������񂪑��݂��Ȃ��s
	j_putline( hell->buffer , x0 , y0+i , hell->len );
      }
    }
    earth = hell;
    hell = buf.nextline( hell );
  }
  disp_status();
  return nfinds;
}

int Pager::forward_1()
{
  if( forward() )
    return 1;
  
  v_attrib( Buffer::TEXT_COLOR );
  v_scroll( x0 , y0 , x0+width-1 , y0+lines-1 , 1 , V_SCROLL_UP );
  j_putline( earth->buffer , x0 , y0+lines-1 , earth->len );
#ifdef DEBUG
  if( earth->next == NULL )
    fprintf(stderr,"last line printed.");
#endif
  
  return 0;
}

int Pager::backward_1()
{
  if( backward() )
    return 1;
  
  v_attrib( Buffer::TEXT_COLOR );
  v_scroll( x0 , y0 , x0+width-1 , y0+lines-1 , 1 , V_SCROLL_DOWN );
  v_scroll( x0 , y0 , x0+width-1 , y0         , 1 , V_SCROLL_CLEAR  );
  j_putline( heaven->buffer , x0 , y0 , heaven->len );
  
  return 0;
}
