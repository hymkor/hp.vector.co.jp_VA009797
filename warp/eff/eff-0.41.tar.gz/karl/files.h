#ifndef FILES_H
#define FILES_H

#ifndef NULL
#	include <stddef.h>
#endif

#include <sys/types.h>
#include <dirent.h>

class Files{
  Files *next,*prev; /* �o�������X�g */
  struct dirent  info;	/* dirent */
  int status; /* !=0 : error */
	
  static DIR *dirp;
  static Files *first;
	
  Files( void ); /* ��ʂ���̌Ăяo�����֎~�B*/
public:
  int no,flag;	 /* �\�� */
	
  Files *forward(void);
  Files *backward(void){ return prev; }
	
  /* ���|�[�g�֐� */
  const char *fname(void)		const { return info.d_name; }
  unsigned short namlen(void)	const { return info.d_namlen; }
  unsigned short mode(void)	const { return info.d_attr; }
  unsigned short time(void)	const { return info.d_time; }
  unsigned short date(void)	const { return info.d_date; }
  unsigned long  size(void)	const { return info.d_size; }
	
  /* �A�g���r���[�g�̃��|�[�g */
  int is_readonly( void ) const { return info.d_attr & A_RONLY ; }
  int is_hidden( void )	const { return info.d_attr & A_HIDDEN ; }
  int is_system( void )	const { return info.d_attr & A_SYSTEM ; }
  int is_label( void ) const { return info.d_attr & A_LABEL ; }
  int is_dir( void ) const { return info.d_attr & A_DIR ; }
  int is_archive( void ) const { return info.d_attr & A_ARCHIVE ; }
  
  ~Files( void );
  operator const void * (void) const { return status ? NULL : this ; }
  int operator ! (void) const { return status; }
	
  static Files *open( const char *path );
  static void   close( void );
};

#endif /* FILES_H */
