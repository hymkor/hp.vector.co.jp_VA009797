#include <assert.h>
#include <stdlib.h>

#include "effetc.h"
#include "thedir.h"
#include "files.h"
#include "os2eff.h"

Files::Exploder::~Exploder()
{
  if( files != NULL ){
    for(Node **p=files ; *p != NULL ; p++ )
      free(*p);
    free(files);
  }
}

Files::Exploder::Exploder(const char *path)
{
  nfiles = 0;
  files = NULL;

  const char *lastroot=NULL;
  int finalchar = 0;
  int have_wildcard = 0;
  
  for(const char *p=path; *p != '\0' ; p++ ){
    finalchar = *p;
    if( *p=='\\' || *p=='/' || *p==':' ){
      lastroot = p;
    }else if( *p=='?' || *p=='*' ){
      have_wildcard = 1;
    }
    if( isKanji(*p) ){
      ++p;
      assert(*p != '\0');
    }
  }
  
  if(   have_wildcard==0 || finalchar=='\\'
     || finalchar == '/' || finalchar == ':')
    return;
  
  int dotprint=0;

  int lendir = 0;
  char *dirname = "";
  if( lastroot != NULL ){
    assert( lastroot >= path );
    lendir=lastroot-path+1;

    // alloca �ɂ͕��G�Ȉ�����n���Ă͂����Ȃ��B
    int memsiz=lendir+1;
    dirname = (char*)alloca(memsiz);
    
    memcpy( dirname , path , lendir );
    dirname[lendir] = '\0';
    if( lastroot[1]=='.' )
      dotprint = 1;
  }else{
    if( path[0] == '.' )
      dotprint = 1;
  }

  /* �����Ɂu*�v��t���Ȃ� */
  Dir dir(path,ALL,0);
  if( ! dir.isOk() )
    return;

  if( (files = (Node**)malloc(sizeof(Node*))) == NULL )
    return;
  
  do{
    /* �u.�v�Ŏn�܂�t�@�C���͊�{�I�ɕ\�����Ȃ��B
     *  - �t�@�C�������̂̎w��Łu.�v�Ŏn�܂�ꍇ�Ε�
     *  - �u.�v���̂ɂ͓W�J���Ȃ�
     */
    if(  dir.getName()[0] == '.'
       && ( dotprint == 0 || dir.getName()[1]=='\0' ) )
      continue;
	
    files[ nfiles ] = 
      (Node*)malloc( sizeof(Node)+lendir + dir.getNameLength() );
    strcpy_tail( strcpy_tail( files[ nfiles ]->name , dirname )
		, dir.getName() );
    files[ nfiles ]->attr = dir.getAttr();
    files = (Node**)realloc( files , (++nfiles+1) * sizeof(Node*) );
  }while( ++dir != NULL );
  files[ nfiles ] = NULL;
  
  if( nfiles <= 0 ){
    free(files);
    files=NULL;
    nfiles = 0;
  }
}

