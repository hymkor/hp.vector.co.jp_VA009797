#include <stdlib.h>
#include <stdarg.h>
#include <stdio.h>
#include <sys/video.h>

#define INCL_WIN
#define INCL_VIO
#include <os2.h>

#include "effetc.h"
#include "getline.h"

#undef TEST

void VioCannaInput::start(void)
{
  ::box_cursor_on();
}

void VioCannaInput::end(void)
{
  ::cursor_off();
}

int VioCannaInput::getkey2(void)
{
  int ch = ( _read_kbd(0,1,0) & 0xFF );

  if( ch == 0 )
    ch = ( _read_kbd(0,1,0) | 0x100 );
  else if( isKanji(ch) )
    ch = ((ch << 8)|(_read_kbd(0,1,0) & 0xFF));
  
  return ch;
}

void VioCannaInput::putchr(int ch)
{
  static int prevchar=0;
  if( prevchar != 0 ){
    char buf[3]={ prevchar , ch , '\0' };
    v_puts(buf);
    prevchar = 0;
  }else if( isKanji(ch) ){
    prevchar = ch;
  }else{
    v_putc(ch);
  }
}

void VioCannaInput::putbs(int n)
{
  v_backsp(n);
}

void VioCannaInput::print_bottom(const char *fmt,...)
{
  int X,Y,W,H;

  v_dimen(&W,&H);
  v_getxy(&X,&Y);

  v_gotoxy(0,H-1);

  if( bottom_buffer == NULL ){
    bottom_buffer = _tmalloc( W*2 );
    if( bottom_buffer != NULL )
      v_getline( (char*)bottom_buffer , 0 , H-1 , W );
  }
  va_list vp;
  va_start(vp,fmt);
  char buffer[256];
  int size=vsprintf(buffer,fmt,vp);
  euc2sjis( buffer , buffer );
  v_puts(buffer);
  va_end(vp);
  if( size < btmsize )
    v_putn(' ',btmsize-size);

  v_gotoxy(X,Y);
  btmsize = size;
}
void VioCannaInput::clear_bottom(void)
{
  int W,H;
  v_dimen(&W,&H);
  if( bottom_buffer != NULL ){
    v_putline((char*)bottom_buffer , 0 , H-1 , W );
    _tfree(bottom_buffer);
    bottom_buffer = NULL;
  }else{
    v_scroll(0, H-1, W-1, H-1, 1, V_SCROLL_CLEAR );
  }
  btmsize = 0;
}

const char *VioCannaInput::getClipBoardValue()
{
  extern HAB hab;
  WinOpenClipbrd( hab );
  WinSetClipbrdOwner(hab,NULLHANDLE);
  ULONG	ulFmtInfo;
  if( WinQueryClipbrdFmtInfo( hab, CF_TEXT, &ulFmtInfo ) ){
    return (char*)WinQueryClipbrdData( hab , CF_TEXT );
  }else{
    return NULL;
  }
}

#ifdef TEST

int main(void)
{
  VioCannaInput input;

  v_init();
  v_gotoxy(0,0);
  char *line=input.getline();
  v_gotoxy(0,2);
  if( line != NULL )
    v_puts(line);
  
  return 0;
}

#endif

