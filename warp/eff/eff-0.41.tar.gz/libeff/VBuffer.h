/* -*- c++ -*- */
#ifndef VBUFFER_H
#define VBUFFER_H

class VBuffer{
  enum { UNITSIZE = 80 };
  char (*buffer)[2];
  int count,max,attr;
  int setmem();

public:
  VBuffer() : buffer(0) , count(0) , max(0) , attr(0x0F) { }
  void reset();
  ~VBuffer(){ reset(); }
  
  VBuffer &operator << ( const char *s );
  VBuffer &operator << ( char ch );
  VBuffer &printf( const char *s ,... );
  VBuffer &color(int x){ attr = x ; return *this; }
  VBuffer &putNumber(int num,int width,char fillchar=' ',char sign='\0');
  
  void putat(int x,int y);				// �S�ĕ\������.
  void putatPart(int x,int y,int at,int len=-1,int fillchar=' ');
  // �����I�ɕ\��.
  
  void pack();
  int isVirgin() const { return buffer == 0 ; }
  int getLength() const { return count; }
};

#endif
