/* product name: RXJIS                                                */
/* Version:      0.92                                                 */
/* author:       YANO Takashi                                         */
/* target:       OS/2 Warp J3.0+ (J2.1 is possible)                   */
/* source name:  JISCASE.HPP                                          */
/* address:      tyano@ca2.so-net.or.jp or tyano@yamato.ibm.co.jp     */
/* comment:      RXJIS is a utility functions for REXX.               */
/*               This header file is a interface to be called from    */
/*               C/C++.                                               */
/* History:                                                           */
/* 1997-9-5 0.92 initial                                              */
/*                                                                    */
typedef wchar_t *PWCHAR_T;
extern PWCHAR_T UppercaseTable[UCHAR_MAX+1];
extern wchar_t ToDbcsTable1[UCHAR_MAX+1];
extern wchar_t ToDbcsTable2[UCHAR_MAX+1];
extern wchar_t ToDbcsTable3[UCHAR_MAX+1];
extern PWCHAR_T ToDbcsTable4[UCHAR_MAX+1];
extern PWCHAR_T ToDbcsTable5[UCHAR_MAX+1];
extern PCHAR *ToSbcsTable[UCHAR_MAX+1];
extern PWCHAR_T* KanjiAliasTable[UCHAR_MAX+1];
extern const int maxKanjiAliasSize;
