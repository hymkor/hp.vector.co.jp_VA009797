/* product name: RXJIS                                                */
/* Version:      0.90                                                 */
/* author:       YANO Takashi                                         */
/* target:       OS/2 Warp J3.0+ (J2.1 is possible)                   */
/* source name:  RXJIS.H                                              */
/* address:      tyano@ca2.so-net.or.jp or tyano@yamato.ibm.co.jp     */
/* comment:      RXJIS is a utility functions for REXX.               */
/*               This header file is a interface to be called from    */
/*               C/C++.                                               */
/*                                                                    */
/* history:      1996-4-21 0.30 Initial release                       */
/*               1996-5-1  0.40 Add JisMimeJis function               */
/*                              Add JisCharJisTo function             */
/*                              Add JisToCharJis function             */
/*               1996-5-19 0.50 Add JisToDbcs function                */
/*                              Add JisToSbcs function                */
/*                              Add JisToAscii function               */
/*                              Add JisToUpper function               */
/*               1996-6-20 0.60 Add JisIso8859_1toCp850 function      */
/*                              Add JisIso8859_2toCp852 function      */
/*                              Add JisIso8859_9toCp857 function      */
/*                              Add JisCp857ToIso8859_9 function      */
/*                              Add JisCp852ToIso8859_2 function      */
/*                              Add JisCp850ToIso8859_1 function      */
/*               1996-6-26 0.70 Add JisZenkakuKatakana function       */
/*               1996-7-21 0.80 Add JisWords function                 */
/*                              Add JisWord function                  */
/*                              Add JisWordIndex function             */
/*                              Add JisAppend function                */
/*               1997-8-4 0.90 Add JisFindWord function               */
/*               1997-9-5 0.92 Add JIsKanjiAlias function             */
/*                                                                    */
extern "C" {
int _Export JisToJis(char* target, char* source, int targetsize, int sourcesize = 0);
int _Export JisToEuc(char* target, char* source, int targetsize, int sourcesize = 0);
int _Export JisToBase64(char* target, char* source, int targetsize, int sourcesize = 0);
int _Export JisToQuotedPrintable(char* target, char* source, int targetsize, int sourcesize = 0);
int _Export JisJisTo(char* target, char* source, int targetsize, int sourcesize = 0);
int _Export JisBase64To(char* target, char* source, int targetsize, int sourcesize = 0);
int _Export JisEucTo(char* target, char* source, int targetsize, int sourcesize = 0);
int _Export JisQuotedPrintableTo(char* target, char* source, int targetsize, int sourcesize = 0);
int _Export JisMimeJisTo(char* target, char* source, int targetsize, int sourcesize = 0);
int _Export JisJisCharTo(char* target, char* source, int targetsize, int sourcesize = 0);
int _Export JisToJisChar(char* target, char* source, int targetsize, int sourcesize = 0);
int _Export JisToDbcs(char* target, char* source, int targetsize, int sourcesize = 0);
int _Export JisToSbcs(char* target, char* source, int targetsize, int sourcesize = 0);
int _Export JisToAscii(char* target, char* source, int targetsize, int sourcesize = 0);
int _Export JisToUpper(char* target, char* source, int targetsize, int sourcesize = 0);
int _Export JisIso8859_1ToCp850(char* target, char* source, int targetsize, int sourcesize = 0);
int _Export JisIso8859_2ToCp852(char* target, char* source, int targetsize, int sourcesize = 0);
int _Export JisIso8859_9ToCp857(char* target, char* source, int targetsize, int sourcesize = 0);
int _Export JisCp850ToIso8859_1(char* target, char* source, int targetsize, int sourcesize = 0);
int _Export JisCp852ToIso8859_2(char* target, char* source, int targetsize, int sourcesize = 0);
int _Export JisCp857ToIso8859_9(char* target, char* source, int targetsize, int sourcesize = 0);
int _Export JisToZenkakuKatakana(char* target, char* source, int targetsize, int sourcesize = 0);
int _Export JisWords(char* source, int sourcesize = 0);
int _Export JisWord(char* target, char* source, int targetsize, int position, int sourcesize = 0);
int _Export JisWordIndex(char* target, char* source, int targetsize, int position, int sourcesize = 0);
int _Export JisAppend(char* target, char* source, int targetsize, int targetlength = 0, int sourcesize = 0);
int _Export JisFindWord(char* string, int length, int position, int* startWord);
int _Export JisKanjiAlias(wchar_t kanji, wchar_t* aliaslist, int aliassize);
};
