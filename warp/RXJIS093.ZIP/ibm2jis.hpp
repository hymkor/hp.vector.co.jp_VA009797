/* product name: RXJIS                                                */
/* Version:      0.90                                                 */
/* author:       YANO Takashi                                         */
/* target:       OS/2 Warp J3.0+ (J2.1 is possible)                   */
/* source name:  IBM2JIS.HPP                                          */
/* address:      tyano@ca2.so-net.or.jp or tyano@yamato.ibm.co.jp     */
/* comment:      RXJIS is a utility functions for REXX.               */
/*               This header file is a interface to be called from    */
/*               C/C++.                                               */
/* history: 1997-08-05 0.90                                           */
extern const PCHAR *IbmToJisTable[UCHAR_MAX+1];
