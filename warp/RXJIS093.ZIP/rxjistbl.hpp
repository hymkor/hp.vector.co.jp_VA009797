/* product name: RXJIS                                                */
/* Version:      0.91                                                 */
/* author:       YANO Takashi                                         */
/* target:       OS/2 Warp J3.0+                                      */
/* source name:  RXJISTBL.HPP                                         */
/* address:      tyano@ca2.so-net.or.jp or tyano@yamato.ibm.co.jp     */
/* comment:      RXJIS is a utility functions for REXX.               */
/* history: 1997-09-5 0.92                                           */
/*                                                                    */
/*                                                                    */
#define Base64Error -1
#define Base64Pad 64
#define QuotedPrintableError -1

struct Seq {
   PSZ seq;
   int len;
};

extern const CHAR Cp850ToIso8859_1Table[UCHAR_MAX+1];
extern const CHAR Iso8859_1ToCp850Table[UCHAR_MAX+1];
extern const CHAR Base64Table[UCHAR_MAX+1];
extern const CHAR Cp852ToIso8859_2Table[UCHAR_MAX+1];
extern const CHAR Iso8859_2ToCp852Table[UCHAR_MAX+1];
extern const CHAR Cp857ToIso8859_9Table[UCHAR_MAX+1];
extern const CHAR Iso8859_9ToCp857Table[UCHAR_MAX+1];
extern const Seq ToQuotedPrintableTable[UCHAR_MAX+1];
extern const LONG QuotedPrintableTable[UCHAR_MAX+1];
