/* product name: RXJIS                                                */
/* Version:      0.93                                                 */
/* author:       YANO Takashi                                         */
/* target:       OS/2 Warp J3.0+ (J2.1 is possible)                   */
/* module name:  RXJIS.DLL                                            */
/* source name:  RXJIS.CPP                                            */
/* compiler:     VisualAge C++ 3.0                                    */
/* address:      tyano@ca2.so-net.or.jp or tyano@yamato.ibm.co.jp     */
/* comment:      RXJIS is a utility functions for REXX.               */
/*               It encodes and decodes JIS 7 bit strings and MIME    */
/*               format strings.                                      */
/*                                                                    */
/*               It provides the functions:                           */
/*               RxJisToPc                                            */
/*               RxJisJisTo                                           */
/*               RxJisDropFuncs                                       */
/*               RxJisToJis                                           */
/*               RxJisToBase64                                        */
/*               RxJisToQuotedPrintable                               */
/*               RxJisBase64To                                        */
/*               RxJisEucTo                                           */
/*               RxJisToEuc                                           */
/*               RxJisQuotedPrintableTo                               */
/*               RxJisLoadFuncs                                       */
/*               RxJisMimeJisTo                                       */
/*               RxJisJisCharJisTo                                    */
/*               RxJisJisToCharJisTo                                  */
/*               RxJisJisIso8859_1ToCp850                             */
/*               RxJisJisIso8859_2ToCp852                             */
/*               RxJisJisIso8859_9ToCp857                             */
/*               RxJisJisCp850ToIso8859_1                             */
/*               RxJisJisCp852ToIso8859_2                             */
/*               RxJisJisCp857ToIso8859_9                             */
/*               RxJisJisToZenkakuKatakana                            */
/*               RxJisWord                                            */
/*               RxJisWords                                           */
/*               RxJisWordIndex                                       */
/*               RxJisPriority                                        */
/*               RxJisKanjiAlias                                      */
/*               JisFindWord (C/C++ only)                             */
/* history:      1996-2-5  0.00 initial release                       */
/*               1996-2-14 0.10 if find alone reset sequence,         */
/*                         add the set seq at the head.               */
/*                         reduce dll size                            */
/*               1996-3-20 0.20 JIS90 support                         */
/*                              Handle umatch JIS sequence            */
/*                              EUC support                           */
/*               1996-4-21 0.30 JIS78 support                         */
/*                              Performance inprovement               */
/*                              Add .HPP/.LIB                         */
/*               1996-5-1  0.40 Add RxJisMimeJis                      */
/*               1996-5-19 0.50 Add RxJisToDbcs                       */
/*                              Add RxJisToSbcs                       */
/*                              Add RxJisToAscii                      */
/*                              Add RxJisToUpper                      */
/*               1996-5-24 0.51 Fix RxJisToJis bug                    */
/*               1996-5-27 0.52 Fix RxJisToJis bug                    */
/*                              Fix Version No                        */
/*               1996-6-20 0.60 Fix RxJisToDbcs bug                   */
/*                              Try to use JIS instead of IBM unique  */
/*                              in RxJisToJis/RxJisToEuc              */
/*                              Add RxJisJisIso8859_1ToCp850          */
/*                              Add RxJisJisIso8859_2ToCp852          */
/*                              Add RxJisJisIso8859_9ToCp857          */
/*                              Add RxJisJisCp850ToIso8859_1          */
/*                              Add RxJisJisCp852ToIso8859_2          */
/*                              Add RxJisJisCp857ToIso8859_9          */
/*                              Fix RxJisQuotedPrintable bug          */
/*                              Fix JisXX NULL term bug               */
/*               1996-6-26 0.70 Add RxJisToZenkakuKatakana            */
/*                              Add JIS codeset 3 support             */
/*               1996-7-8  0.71 RxJisBase64To/RxJisToBase64 may not   */
/*                              work as expected.                     */
/*                              (from 0.70)                           */
/*               1996-7-21 0.80 Add RxJisAppend                       */
/*                              Add RxJisWord                         */
/*                              Add RxJisWords                        */
/*                              Add RxJisWordIndex                    */
/*                              Add RxJisUrltoVar                     */
/*               1996-7-22 0.81 Fix RxJisToJis bug - > 255 source     */
/*               1996-8-19 0.82 Fix RxJisAppend -> blanks + char      */
/*               1996-9-10 0.83 Add codepage 943 support              */
/*                              Fix Ver bug                           */
/*               1996-9-14 0.84 cp943 has NEC chars                   */
/*               1996-10-28 0.86 Use ESC ( B instead of ESC ( J       */
/*               1997-8-5 0.90  Add JisFindWord                       */
/*                              Fix RxJisToZenkakuKatakana bug        */
/*               1997-8-25 0.91 Add JisFindWord                       */
/*               1997-9-5 0.92 Add RxJisKanjiAlias/RxJisPriority      */
/*               1997-9-11 0.93 Add RxJisTrace                        */
/*                                                                    */
/*                                                                    */

#include <stdlib.h>
#include <stdio.h>
#include <limits.h>
#include <string.h>
#include <wcstr.h>
#include <time.h>
#include <itrace.hpp>
#define INCL_DOSMODULEMGR
#define INCL_DOSERRORS
#define INCL_DOSMISC 
#define INCL_DOSNLS
#define INCL_DOSPROCESS
#include <os2.h>
#define INCL_RXFUNC
#define INCL_RXSHV
#include <rexxsaa.h>
#include "rxjis.h"
#include "rxjistbl.hpp"
#include "pctojis.hpp"
#include "jis2pc.hpp"
#include "jiscase.hpp"

#define CallingValid 0
#define CallingInvalid 40
#define RxJisDll "RXJIS"
#define RxJisVersion "0.93" 
#define Base64BitWidth 6
#define ByteBitWidth 8
#define MaxMimeLineSize 76
#define Base64Mask 0x00003f
#define HighByteMask 0x0000ff00
#define Ht '\x09'
#define Space ' '
#define Esc '\x1b'
#define EucMsb 0x0080                     
#define ByteMsb 0x0080                     
#define EucMask 0x007f                    
#define EucSs2 0x008e                    
#define EucSs3 0x008f
#define JisEnvVarName "IPF_KEYS"          
#define Jis90Value "NEWJIS"               
#define Jis83InSeq DoubleByteSeqTable[0]  
#define Jis83OutSeq DoubleByteSeqTable[6] 
#define JisSpace 0x2121                   
#define SI 0x0e
#define SO 0x0f
#define CpListSize 8
#define BeginKinsoku L"�A�B�C�D�F�G�E�H�I!%��),.:;?]}�����j�p�l�n�z�r�t��>�v�x�J�K�f�h�������߁R�S�T�U�[�X��݂����������������@�B�D�F�H�b����������������������`�����"
#define EndKinsoku L"�i�o�k�m�u�w�y([{��q�s��<�e�g��\\��$@��#��������"
#define CodepageJapanese 932
#define CodepageSaaJapanese 942
#define CodepageNewJapanese 943

#define RxJisCountCheck2(count, targetsize, sourcewide) \
   if (count >= targetsize) { \
      delete sourcewide; \
      return (RxJisError); \
   } /* endif */

extern "C" {
RexxFunctionHandler RxJisLoadFuncs;
RexxFunctionHandler RxJisDropFuncs;
RexxFunctionHandler RxJisToJis;
RexxFunctionHandler RxJisJisTo; 
RexxFunctionHandler RxJisToEuc; 
RexxFunctionHandler RxJisToPc;
RexxFunctionHandler RxJisToBase64;
RexxFunctionHandler RxJisToQuotedPrintable;
RexxFunctionHandler RxJisBase64To;
RexxFunctionHandler RxJisEucTo; 
RexxFunctionHandler RxJisMimeJisTo; 
RexxFunctionHandler RxJisQuotedPrintableTo;
RexxFunctionHandler RxJisJisCharTo; 
RexxFunctionHandler RxJisToJisChar; 
RexxFunctionHandler RxJisToSbcs; 
RexxFunctionHandler RxJisToDbcs; 
RexxFunctionHandler RxJisToAscii; 
RexxFunctionHandler RxJisToUpper; 
RexxFunctionHandler RxJisToZenkakuKatakana; 
RexxFunctionHandler RxJisIso8859_1ToCp850; 
RexxFunctionHandler RxJisIso8859_2ToCp852; 
RexxFunctionHandler RxJisIso8859_9ToCp857; 
RexxFunctionHandler RxJisCp850ToIso8859_1; 
RexxFunctionHandler RxJisCp852ToIso8859_2; 
RexxFunctionHandler RxJisCp857ToIso8859_9; 
RexxFunctionHandler RxJisWords; 
RexxFunctionHandler RxJisWord; 
RexxFunctionHandler RxJisWordIndex;        
RexxFunctionHandler RxJisAppend;        
RexxFunctionHandler RxJisUrlToVar;        
RexxFunctionHandler RxJisKanjiAlias;        
RexxFunctionHandler RxJisPriority;        
RexxFunctionHandler RxJisTrace;        
};

static const PSZ RxJisFuncsTable[] = {
   "RxJisLoadFuncs",
   "RxJisDropFuncs",
   "RxJisToBase64",
   "RxJisToQuotedPrintable",
   "RxJisToJis",
   "RxJisToEuc", 
   "RxJisToPc",
   "RxJisJisTo", 
   "RxJisBase64To",
   "RxJisEucTo", 
   "RxJisMimeJisTo", 
   "RxJisQuotedPrintableTo",
   "RxJisJisCharTo", 
   "RxJisToJisChar", 
   "RxJisToSbcs", 
   "RxJisToDbcs", 
   "RxJisToAscii", 
   "RxJisToUpper", 
   "RxJisToZenkakuKatakana", 
   "RxJisIso8859_1ToCp850", 
   "RxJisIso8859_2ToCp852", 
   "RxJisIso8859_9ToCp857", 
   "RxJisCp850ToIso8859_1", 
   "RxJisCp852ToIso8859_2", 
   "RxJisCp857ToIso8859_9", 
   "RxJisWords", 
   "RxJisWord", 
   "RxJisWordIndex", 
   "RxJisAppend", 
   "RxJisUrlToVar", 
   "RxJisKanjiAlias", 
   "RxJisPriority", 
   "RxJisTrace", 
};

static const size_t NoOfEntries = sizeof(RxJisFuncsTable) / sizeof(RxJisFuncsTable[0]);

static PWCHAR_T *JisX0212_1990ToPccodeTable = JisCodeToPcCodeTable;
static BOOL TableIsLoaded = FALSE;
static APIRET LoadRxJisTables(void);
static BOOL (APIENTRY16 *NlsFindWord)(USHORT codepage, PSZ string, ULONG strlen, ULONG  position, PULONG pStartWord, PULONG pEndWord, PULONG pNextWord);
static USHORT DefaultCodepage;
static int Base64To(PCHAR target, PCHAR source, int targetsize, int sourcesize = 0, int linesize = 0);          
static int QuotedPrintableTo( PCHAR target, PCHAR source, int targetsize, int sourcesize = 0, int linesize = 0); 
static int ToPc(PCHAR target, PCHAR source, int targetsize, int sourcesize = 0, int linesize = 0); 

#define ToIso8859_1(c) Cp850ToIso8859_1Table[c]
#define ToCp850(c) Iso8859_1ToCp850Table[c]
#define ToIso8859_2(c) Cp852ToIso8859_2Table[c]
#define ToCp852(c) Iso8859_2ToCp852Table[c]
#define ToIso8859_9(c) Cp857ToIso8859_9Table[c]
#define ToCp857(c) Iso8859_9ToCp857Table[c]

enum CharSet {
   USASCII,
   ISO8859_1,  
   ISO8859_2,  
   ISO8859_3,  
   ISO8859_4,  
   ISO8859_5,  
   ISO8859_6,  
   ISO8859_7,  
   ISO8859_8,  
   ISO8859_9,  
   ISO2022KR, 
   ISO2022JP,  
   JIS78,
   JISX0212_1990,
   HankakuKatakana,
   SS2         
};

struct EscapeSeq {
   PSZ seq;
   int len;
   CharSet charset; 
   PWCHAR_T *jistopccodetable; 
};

static const EscapeSeq DoubleByteSeqTable[] = {
   {"\x1b$B", 3, ISO2022JP, NULL},  
   {"\x1b$A", 3, ISO2022JP, NULL},  
   {"\x1b$@", 3, JIS78, NULL},  
   {"\x1b$@\x1b$B", 6, ISO2022JP, NULL}, 
   {"\x1b(J", 3, USASCII, NULL},   
   {"\x1b$(D", 4, JISX0212_1990, JisX0212_1990ToPccodeTable},   
   {"\x1b(B", 3, USASCII, NULL},   
   {"\x1b$(C", 4, ISO2022KR, NULL}, 
   {"\x1b$)C", 4, ISO2022KR, NULL}, 
   {"\x1bN", 2, SS2, NULL},   
   {"\x1b.A", 3, ISO8859_1, NULL},   
   {"\x1b.F", 3, ISO8859_7, NULL},   
   {"\x1b(I", 3, HankakuKatakana, NULL},   
   {NULL, 0}
};

struct MimeCharSet {
   PCHAR name;
   int namesize;
   CharSet charset;
};

static struct MimeCharSet MimeCharSetTable[] = {
   {"US-ASCII", 8, USASCII},
   {"ISO-8859-1", 10, ISO8859_1}, 
   {"ISO-8859-2", 10, ISO8859_2}, 
   {"ISO-8859-3", 10, ISO8859_3}, 
   {"ISO-8859-4", 10, ISO8859_4}, 
   {"ISO-8859-5", 10, ISO8859_5}, 
   {"ISO-8859-6", 10, ISO8859_6}, 
   {"ISO-8859-7", 10, ISO8859_7}, 
   {"ISO-8859-8", 10, ISO8859_8}, 
   {"ISO-8859-9", 10, ISO8859_9}, 
   {"ISO-2022-JP", 11, ISO2022JP},
   {"ISO-2022-JP-2", 13, ISO2022JP},
   {"ISO-2022-KR", 11, ISO2022KR}
};

static const size_t NoOfMimeCharSet = sizeof(MimeCharSetTable) / sizeof(MimeCharSetTable[0]);

static struct MimeCharSet *MimeEncodedWordTable;
static size_t NoOfMimeEncodedWord;
static PCHAR ToBase64Table = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

static int _Optlink
compcharset(
const void *key,
const void *element) {
   MimeCharSet *v1 = (MimeCharSet*)key;
   MimeCharSet *v2 = (MimeCharSet*)element;
   return (strnicmp(v1->name, v2->name, v2->namesize));
}

static int
find1stbyte(
PCHAR str,
int pos) {
   if (pos <= 0 || pos > strlen(str)) {
      return (0);
   } /* endif */
   if (strlen(str) == 1) {
      return (1);
   } /* endif */
   for (int i = pos - 1; i >= 2; i -= 1) {
      if (!IsDbcs1st(str[i]) && !IsDbcs1st(str[i-1])) {
         return (i + 1);
      } /* endif */
      if (IsDbcs1st(str[i]) && !IsDbcs1st(str[i-1])) {
         return (i + 1);
      } /* endif */
      if (IsDbcs1st(str[i]) && IsDbcs1st(str[i-1]) && !IsDbcs1st(str[i-2])) {
         return (i - 1);
      } /* endif */
   } /* endfor */
   if (!IsDbcs1st(str[0])) {
      return (2);
   } /* endif */
   return (1);
}

int JisFindWord(
char *string, 
int length,
int position, 
int *startWord) {
   int sizeword;
   int& startword = *startWord;
   if (DefaultCodepage != CodepageJapanese && DefaultCodepage != CodepageSaaJapanese && DefaultCodepage != CodepageNewJapanese) {
      ULONG endword;
      ULONG nextword;
      BOOL r = NlsFindWord(DefaultCodepage, string, length, position, (PULONG)&startword, &endword, &nextword);
      if (!r) {
         return (0);
      } /* endif */
      sizeword = endword - startword;
      return (sizeword);
   } /* endif */
   while (position < length && !IsDbcs1st(string[position]) && isspace(string[position])) {
      position += 1;
   } /* endwhile */
   if (position >= length || IsDbcs1st(string[position]) && position + 1 >= length) {
      sizeword = 0;
      return (0);
   } /* endif */
   startword = position;
   sizeword = 0;
   wchar_t w;
   int n = mbtowc(&w, string + position, 2);
   while (wcsrchr(EndKinsoku, w)) {
      sizeword += n;
      if (position + n >= length || IsDbcs1st(string[position+n]) && position + n + 1 >= length) {
         return (sizeword);
      } /* endif */
      position += n;
      n = mbtowc(&w, string + position, 2);
   } /* endwhile */
   if (!IsDbcs1st(string[position]) && string[position] <= SCHAR_MAX) {
      while (position < length && !IsDbcs1st(string[position]) && string[position] <= SCHAR_MAX && !isspace(string[position])) {
         sizeword += 1;
         position += 1;
      } /* endwhile */
   } else {
      sizeword += n;
      position += n;
   } /* endif */
   if (position >= length || IsDbcs1st(string[position]) && position + 1 >= length) {
      return (sizeword);
   } /* endif */
   n = mbtowc(&w, string + position, 2);
   while (wcsrchr(BeginKinsoku, w)) {
      position += n;
      sizeword += n;
      if (position >= length || IsDbcs1st(string[position]) && position + 1 >= length) {
         return (sizeword);
      } /* endif */
      n = mbtowc(&w, string + position, 2);
   } /* endwhile */
   return (sizeword);
}

static int
nmbstowcs(
wchar_t *target,
size_t targetsize,
PCHAR source,
size_t sourcesize) {
   size_t i = 0;
   size_t count = 0;
   while (i < sourcesize) {
      RxJisCountCheck(count, targetsize);
      mbtowc(target + count, source + i, sourcesize - i);
      if (target[count] > UCHAR_MAX) {
         i += 2;
      } else {
         i += 1;
      } /* endif */
      count += 1;
   } /* endwhile */
   RxJisCountCheck(count, targetsize);
   target[count] = '\0';
   return (count);
}

static wchar_t
JisCodeToPcCode(
wchar_t jiscode) {
   int h = jiscode >> ByteBitWidth;
   int l = jiscode & ByteMask;
   if (h & '\x01') {
      l += '\x1f';
   } else {
      l += '\x7d';
   } /* endif */
   if (l >= '\x7f') {
      l += 1;
   } /* endif */
   h = (h - '\x21') >> 1;
   if (h > '\x1e') {
      h += '\xc1';
   } else {
      h += '\x81';
   } /* endif */
   return (h << ByteBitWidth | l);
}

static wchar_t
JisToPc(
wchar_t c,
PWCHAR_T* t) {
   if (!t) {
      return (JisCodeToPcCode(c));
   } /* endif */
   int l = c & ByteMask;
   int h = c >> ByteBitWidth;
   if (!t[h]) {
      return (L'�@');
   } /* endif */
   return (t[h][l]);
}

static int
Base64Size(
PCHAR source,
int sourcesize = 0,
int linesize = 0) {
   if (sourcesize <= 0) { 
      sourcesize = strlen(source);
   } /* endif */
   int n = ByteBitWidth * sourcesize;
   n /= Base64BitWidth;
   if (n % Base64BitWidth) {
      n += 1;
   } /* endif */
   if (linesize > 0) {
      int l = n / linesize;
      if (n % linesize) {
         l += 1;
      } /* endif */
      n += 2 * l;
   } /* endif */
   n += MaxMimeLineSize;
   return (n);
}

static int
DbcsSize(
PCHAR source,
int sourcesize = 0,
int linesize = 0) {
   if (sourcesize <= 0) { 
      sourcesize = strlen(source);
   } /* endif */
   return (2 * sourcesize);
}

static int
QuotedPrintableSize(
PCHAR source,
int sourcesize = 0,
int linesize = 0) {
   if (sourcesize <= 0) { 
      sourcesize = strlen(source);
   } /* endif */
   int n = 3 * sourcesize;
   if (linesize > 0) {
      int l = n / linesize;
      if (n % linesize) {
         l += 1;
      } /* endif */
      n += 2 * l;
   } /* endif */
   n += linesize;
   return (n);
}

static int
JisSize(
PCHAR source,
int sourcesize = 0,
int linesize = 0) {
   if (sourcesize <= 0) { 
      sourcesize = strlen(source);
   } /* endif */
   int sourcesize2 = maxIbm2JisSize * sourcesize + 1;
   PCHAR source2 = new char[sourcesize2];
   if (!source2) {
      return (RxJisError);
   } /* endif */
   if ((sourcesize = IbmcodeStringToJiscodeString(source, sourcesize, source2, sourcesize2)) == RxJisError) {
      delete source2;
      return (RxJisError);
   } /* endif */
   source = source2;
   int count = 0;
   int sourcecount = 0;
   BOOL indoublebyte = FALSE;
   while (sourcecount <= sourcesize) { 
      if (!IsDbcs1st(source[sourcecount])) {  
         if (indoublebyte) {
            indoublebyte = FALSE;
            count += Jis83OutSeq.len; 
         } /* endif */
         count += 1;
         sourcecount += 1;
      } else {
         if (!indoublebyte) {
            indoublebyte = TRUE;
            count += Jis83InSeq.len; 
         } /* endif */
         count += 2;
         sourcecount += 2;
      } /* endif */
   } /* endwhile */
   if (indoublebyte) {
      count += Jis83OutSeq.len; 
   } /* endif */
   return (count + 1);
}

static int
EucSize(
PCHAR source,
int sourcesize = 0,
int linesize = 0) {
   if (sourcesize <= 0) { 
      sourcesize = strlen(source);
   } /* endif */
   int count = 0;
   size_t sourcecount = 0;
   while (sourcecount <= sourcesize) {
      if (!IsDbcs1st(source[sourcecount])) {
         count += 1;
         sourcecount += 1;
      } else {
         count += 2;
         sourcecount += 2;
      } /* endif */
   } /* endwhile */
   return (count + 1);
}

int _Export 
JisWords(
PCHAR source,
int sourcesize) {
   if (0 == sourcesize) {
      sourcesize = strlen(source);
   } /* endif */
   ULONG pos = 0;
   int count = 0;
   for (; ; ) {
      int startword;
      int sizeword;
      if (!(sizeword = JisFindWord(source, sourcesize, pos, &startword))) {
         break;
      } /* endif */
      count += 1;
      if ((pos = startword + sizeword) >= sourcesize) {
         break;
      } /* endif */
   } /* endfor */
   return (count);
}

int _Export 
JisKanjiAlias(
wchar_t kanji,
wchar_t* aliaslist,
int aliassize) {
   char b[2];
   wctomb(b, kanji);
   wchar_t *t;
   if (!KanjiAliasTable[b[0]] || !(t = KanjiAliasTable[b[0]][b[1]])) {
      return (0);
   } /* endif */
   const int n = wcslen(t);
   if (n + 1 > aliassize) {
      return (-1);
   } /* endif */
   wcscpy(aliaslist, t);
   return (n);
}

int _Export 
JisWord(
char* target, 
char* source, 
int targetsize, 
int position, 
int sourcesize) {
   if (!target || !source || targetsize <= 0 || position <= 0) {
      return (RxJisError);
   } /* endif */
   if (0 == sourcesize) {
      sourcesize = strlen(source);
   } /* endif */
   if (sourcesize < 0) {
      return (RxJisError);
   } /* endif */
   if (0 == sourcesize) {
      return (0);
   } /* endif */
   int pos = 0;
   int startword;
   int sizeword;
   int count = 0;
   for (; ; ) {
      if (!(sizeword = JisFindWord(source, sourcesize, pos, &startword))) {
         target[0] = '\0';
         return (0);
      } /* endif */
      if (++count == position) {
         break;
      } /* endif */
      pos = startword + sizeword;
   } /* endfor */
   if (sizeword >= targetsize) {
      return (RxJisError);
   } /* endif */
   memcpy(target, source + startword, sizeword);
   target[sizeword] = '\0';
   return (sizeword);
}

int _Export 
JisAppend(
char* target, 
char* source, 
int targetsize, 
int targetlength,
int sourcesize) {
   if (!target || !source || targetsize <= 0) {
      return (RxJisError);
   } /* endif */
   if (sourcesize < 0) {
      return (RxJisError);
   } /* endif */
   if (0 == sourcesize) {
      sourcesize = strlen(source);
   } /* endif */
   if (0 == targetlength) {
      targetlength = strlen(target);
   } /* endif */
   if (targetlength + 1 + sourcesize + 1 > targetsize) {
      return (RxJisError);
   } /* endif */
   if (0 == sourcesize) {
      target[targetlength] = '\0';
      return (targetlength);
   } /* endif */
   if (0 == targetlength) {
      memcpy(target, source, sourcesize);
      target[sourcesize] = '\0';
      return (sourcesize);
   } /* endif */
   int i = find1stbyte(target, targetlength);
   for (; ; ) {
      if (i == targetlength || IsDbcs1st(target[i-1]) && i + 1 == targetlength) {
         break;
      } /* endif */
      if (IsDbcs1st(target[i-1])) {
         i += 2;
      } else {
         i += 1;
      } /* endif */
   } /* endfor */
   if (i == targetlength) {
      if (!IsDbcs1st(source[0]) && !isspace(source[0]) && i > 0 && !isspace(target[i-1])) {
         target[targetlength] = ' ';
         targetlength += 1;
      } /* endif */
   } /* endif */           
   memcpy(&target[targetlength], source, sourcesize);
   targetlength += sourcesize;
   target[targetlength] = '\0';
   return (targetlength);
}

int _Export 
JisWordIndex(
char* target, 
char* source, 
int targetsize, 
int wordposition, 
int sourcesize) {
   if (!target || !source || targetsize <= 0 || wordposition <= 0) {
      return (RxJisError);
   } /* endif */
   if (0 == sourcesize) {
      sourcesize = strlen(source);
   } /* endif */
   if (sourcesize < 0) {
      return (RxJisError);
   } /* endif */
   if (0 == sourcesize) {
      return (0);
   } /* endif */
   int count = 0;
   int pos = 0;
   int startword;
   int sizeword;
   for (; ; ) {
      if (!(sizeword = JisFindWord(source, sourcesize, pos, &startword))) {
         return (0);
      } /* endif */
      if (++count == wordposition) {
         break;
      } /* endif */
      pos = startword + sizeword;
   } /* endfor */
   return (startword + 1);
}

static int
ToEuc(
PCHAR target,
PCHAR source,
int targetsize,
int sourcesize = 0,
int linesize = 0) {
   RxJisArgCheck(source, target, targetsize, sourcesize);
   int sourcesize2 = maxIbm2JisSize * sourcesize + 1;
   PCHAR source2 = new char[sourcesize2];
   if (!source2) {
      return (RxJisError);
   } /* endif */
   if ((sourcesize = IbmcodeStringToJiscodeString(source, sourcesize, source2, sourcesize2)) == RxJisError) {
      delete source2;
      return (RxJisError);
   } /* endif */
   source = source2;
   int count = 0;
   size_t sourcecount = 0;
   while (sourcecount < sourcesize) { 
      if (source[sourcecount] <= SCHAR_MAX) {
         RxJisCountCheck2(count, targetsize, source2);
         target[count++] = source[sourcecount++];
      } else if (!IsDbcs1st(source[sourcecount])) {
         RxJisCountCheck2(count + 1, targetsize, source2);
         target[count++] = EucSs2;
         target[count++] = source[sourcecount++];
      } else {
         RxJisCountCheck2(count + 1, targetsize, source2);
         int h = source[sourcecount++];
         int l = source[sourcecount++];
         wchar_t c = h << ByteBitWidth | l;                    
         c = PccodeToJiscode(c);                                       
         target[count++] = EucMsb | (c >> ByteBitWidth);       
         target[count++] = EucMsb | (c & ByteMask);            
      } /* endif */
   } /* endwhile */
   delete source2;
   RxJisCountCheck(count, targetsize);
   target[count] = '\0';
   return (count);                      
}

static int
MimeJisTo(
PCHAR target,
PCHAR source,
int targetsize,
int sourcesize = 0,
int linesize = 0) {
   RxJisArgCheck(source, target, targetsize, sourcesize);
   if (targetsize < sourcesize) {
      return (RxJisError);
   } /* endif */
   int count = 0;
   PCHAR temp1 = new CHAR[targetsize];
   PCHAR temp2 = new CHAR[targetsize];
   if (!temp1 || !temp2) {
      return (RxJisError);
   } /* endif */
   int sourcecount = 0;
   while (sourcecount < sourcesize) {
      PCHAR p;
      PCHAR s;
      MimeCharSet k;
      MimeCharSet *r;
      int n;
      int c;
      switch (source[sourcecount]) {
      case '=':
         k.name = source + sourcecount;
         r = (MimeCharSet*)bsearch(&k, MimeEncodedWordTable, NoOfMimeEncodedWord, sizeof(MimeEncodedWordTable[0]), compcharset);
         if (!r) {
            RxJisCountCheck(count, targetsize);
            temp1[count++] = source[sourcecount++];
            continue;
         } /* endif */
         sourcecount += r->namesize;
         s = source + sourcecount;
         p = strstr(source + sourcecount, "?=");
         if (!p) {
            n = sourcesize - sourcecount;
         } else {
            n = p - s;
         } /* endif */
         if ('B' == r->name[r->namesize-2]) {
            c = Base64To(temp2, s, targetsize, n);
         } else {
            c = QuotedPrintableTo(temp2, s, targetsize, n);
         } /* endif */
         if (c < 0) {
           return (RxJisError);
         } /* endif */
         sourcecount += n + 2;
         memcpy(temp1 + count, temp2, c);
         RxJisCountCheck(count + c, targetsize);
         count += c;
         break;
      default: 
        RxJisCountCheck(count, targetsize);
        temp1[count++] = source[sourcecount++];
        break;
      } /* endswitch */
   } /* endwhile */
   RxJisCountCheck(count, targetsize);
   temp1[count] = '\0';
   count = ToPc(target, temp1, targetsize, count);
   delete temp1;
   delete temp2;
   return (count);
}

static int
EucTo(
PCHAR target,
PCHAR source,
int targetsize,
int sourcesize = 0,
int linesize = 0) {
   RxJisArgCheck(source, target, targetsize, sourcesize);
   int count = 0;
   size_t sourcecount = 0;
   while (sourcecount < sourcesize) {
      if (source[sourcecount] <= SCHAR_MAX) {
         RxJisCountCheck(count, targetsize);
         target[count++] = source[sourcecount++];
      } else if (EucSs2 == source[sourcecount]) {
         RxJisCountCheck(count, targetsize);
         sourcecount += 1;
         target[count++] = source[sourcecount++];
      } else if (EucSs3 == source[sourcecount]) {
         sourcecount += 1;        
         RxJisCountCheck(count + 1, targetsize);
         int h = source[sourcecount++] & EucMask; 
         int l = source[sourcecount++] & EucMask; 
         wchar_t c = h << ByteBitWidth | l;        
         c = JisToPc(c, JisX0212_1990ToPccodeTable);                           
         target[count++] = c >> ByteBitWidth;      
         target[count++] = c & ByteMask;           
      } else {
         RxJisCountCheck(count + 1, targetsize);
         int h = source[sourcecount++] & EucMask; 
         int l = source[sourcecount++] & EucMask; 
         wchar_t c = h << ByteBitWidth | l;        
         c = JisCodeToPcCode(c);
         target[count++] = c >> ByteBitWidth;      
         target[count++] = c & ByteMask;           
      } /* endif */
   } /* endwhile */
   RxJisCountCheck(count, targetsize);
   target[count] = '\0';
   return (count);
}

static int
ToJisChar(
PCHAR target,
PCHAR source,
int targetsize,
int sourcesize = 0,
int linesize = 0) {
   RxJisArgCheck(source, target, targetsize, sourcesize);
   if (!sourcesize) {
      return (0);
   } /* endif */
   if (targetsize <= 3) {
      return (RxJisError);
   } /* endif */
   wchar_t *temp = new wchar_t[sourcesize+1];
   if (!temp) {
      return (RxJisError);
   } /* endif */
   nmbstowcs(temp, sourcesize, source, sourcesize);
   if (temp[0] <= UCHAR_MAX) {
      delete temp;
      return (0);
   } /* endif */
   wchar_t c = PccodeToJiscode(temp[0]);
   target[0] = c >> ByteBitWidth;
   target[1] = c & ByteMask;
   target[2] = '\0';
   delete temp;
   return (2);
}

static int
JisCharTo(
PCHAR target,
PCHAR source,
int targetsize,
int sourcesize = 0,
int linesize = 0) {
   RxJisArgCheck(source, target, targetsize, sourcesize);
   if (sourcesize < 2) {
      return (0);
   } /* endif */
   if (targetsize <= 3) {
      return (RxJisError);
   } /* endif */
   wchar_t c = JisCodeToPcCode((source[0] << ByteBitWidth) | source[1]);
   target[0] = c >> ByteBitWidth;
   target[1] = c & ByteMask;
   target[2] = '\0';
   return (2);
}

static int
ToJis(
PCHAR target,
PCHAR source,
int targetsize,
int sourcesize = 0,
int linesize = 0) {
   RxJisArgCheck(source, target, targetsize, sourcesize);
   int sourcesize2 = maxIbm2JisSize * sourcesize + 1;
   PCHAR source2 = new char[sourcesize2];
   if (!source2) {
      return (RxJisError);
   } /* endif */
   if ((sourcesize = IbmcodeStringToJiscodeString(source, sourcesize, source2, sourcesize2)) == RxJisError) {
      delete source2;
      return (RxJisError);
   } /* endif */
   source = source2;
   int count = 0;
   size_t sourcecount = 0; 
   while (sourcecount < sourcesize) { 
      if (!IsDbcs1st(source[sourcecount])) { 
         RxJisCountCheck2(count, targetsize, source2);
         target[count++] = source[sourcecount++]; 
      } else {
         RxJisCountCheck2(count + Jis83InSeq.len, targetsize, source2);
         strncpy(target + count, Jis83InSeq.seq, Jis83InSeq.len); 
         count += Jis83InSeq.len; 
         while (sourcecount < sourcesize && IsDbcs1st(source[sourcecount])) { 
            RxJisCountCheck2(count + 2, targetsize, source2);
            int h = source[sourcecount++];
            int l = source[sourcecount++];
            wchar_t c = h << ByteBitWidth | l;                    
            c = PccodeToJiscode(c);                                       
            target[count++] = c >> ByteBitWidth; 
            target[count++] = c & ByteMask;      
         } /* endwhile */
         RxJisCountCheck2(count + Jis83OutSeq.len, targetsize, source2);
         strncpy(target + count, Jis83OutSeq.seq, Jis83OutSeq.len); 
         count += Jis83OutSeq.len;                                  
      } /* endif */
   } /* endwhile */
   delete source2;
   RxJisCountCheck(count, targetsize);
   target[count] = '\0';
   return (count);
}

static int
ToSbcs(
PCHAR target,
PCHAR source,
int targetsize,
int sourcesize = 0,
int linesize = 0) {
   RxJisArgCheck(source, target, targetsize, sourcesize);
   int count = 0;
   size_t sourcecount = 0; 
   while (sourcecount < sourcesize) { 
      if (!IsDbcs1st(source[sourcecount])) { 
         RxJisCountCheck(count, targetsize);
         target[count++] = source[sourcecount++]; 
      } else {
         int h = source[sourcecount++];
         int l = source[sourcecount++];
         if (!ToSbcsTable[h] || !ToSbcsTable[h][l]) {
            RxJisCountCheck(count + 1, targetsize);
            target[count++] = h;
            target[count++] = l;
         } else {
            for (int i = 0; ToSbcsTable[h][l][i]; i += 1) {
               RxJisCountCheck(count, targetsize);
               target[count++] = ToSbcsTable[h][l][i];
            } /* endfor */
         } /* endif */
      } /* endif */
   } /* endwhile */
   RxJisCountCheck(count, targetsize);
   target[count] = '\0';
   return (count);
}

static int
ToAscii(
PCHAR target,
PCHAR source,
int targetsize,
int sourcesize = 0,
int linesize = 0) {
   RxJisArgCheck(source, target, targetsize, sourcesize);
   int count = 0;
   size_t sourcecount = 0; 
   while (sourcecount < sourcesize) { 
      if (!IsDbcs1st(source[sourcecount])) { 
         RxJisCountCheck(count, targetsize);
         target[count++] = source[sourcecount++]; 
      } else {
         int h = source[sourcecount++];
         int l = source[sourcecount++];
         if (!ToSbcsTable[h] || !ToSbcsTable[h][l] || ToSbcsTable[h][l][0] > SCHAR_MAX) {
            RxJisCountCheck(count + 1, targetsize);
            target[count++] = h;
            target[count++] = l;
         } else {
            RxJisCountCheck(count, targetsize);
            target[count++] = ToSbcsTable[h][l][0];
         } /* endif */
      } /* endif */
   } /* endwhile */
   RxJisCountCheck(count, targetsize);
   target[count] = '\0';
   return (count);
}

static int
ToUpper(
PCHAR target,
PCHAR source,
int targetsize,
int sourcesize = 0,
int linesize = 0) {
   RxJisArgCheck(source, target, targetsize, sourcesize);
   int count = 0;
   wchar_t* sourcewide = new wchar_t[sourcesize + 1]; 
   if (!sourcewide) {
      return (CallingInvalid);
   } /* endif */
   const size_t sourcewidesize = nmbstowcs(sourcewide, sourcesize + 1, source, sourcesize); 
   size_t sourcewidecount = 0; 
   while (sourcewidecount < sourcewidesize) { 
      switch (sourcewide[sourcewidecount]) {
      case L'�':
      case L'�K':
      case L'�':
      case L'�J':
      case L'�E':
      case L'�':
      case L'�[':
      case L'�':
         sourcewidecount += 1;
         continue;
         break;
      } /* endswitch */
      if (sourcewide[sourcewidecount] <= UCHAR_MAX) { 
         RxJisCountCheck2(count, targetsize, sourcewide);
         target[count++] = UppercaseTable[0][sourcewide[sourcewidecount++]];
      } else {
         char b[2];
         wctomb(b, sourcewide[sourcewidecount]);
         if (UppercaseTable[b[0]]) {
            wchar_t c = UppercaseTable[b[0]][b[1]];
            wctomb(b, c);
         } /* endif */
         RxJisCountCheck2(count + 1, targetsize, sourcewide);
         strncpy(target + count, b, 2);
         count += 2;
         sourcewidecount += 1;
      } /* endif */
   } /* endwhile */
   RxJisCountCheck2(count, targetsize, sourcewide);
   target[count] = '\0';
   delete sourcewide; 
   return (count);
}

static int
ToDbcs(
PCHAR target,
PCHAR source,
int targetsize,
int sourcesize = 0,
int linesize = 0) {
   RxJisArgCheck(source, target, targetsize, sourcesize);
   int count = 0;
   wchar_t* sourcewide = new wchar_t[sourcesize + 1]; 
   if (!sourcewide) {
      return (CallingInvalid);
   } /* endif */
   const size_t sourcewidesize = nmbstowcs(sourcewide, sourcesize + 1, source, sourcesize); 
   size_t sourcewidecount = 0;
   while (sourcewidecount < sourcewidesize) {
      wchar_t c = sourcewide[sourcewidecount++];
      char b[2];
      if (c <= UCHAR_MAX) { 
         if (sourcewidecount >= sourcewidesize) {
            if (!ToDbcsTable1[c]) {
               RxJisCountCheck2(count, targetsize, sourcewide);
               target[count++] = c;
               continue;
            } /* endif */
            c = ToDbcsTable1[c];
         } else {
            wchar_t *t = ToDbcsTable1;
            switch (sourcewide[sourcewidecount]) {
            case L'�':
            case L'�K':
               t = ToDbcsTable3;
               sourcewidecount += 1;
               break;
            case L'�':
            case L'�J':
               t = ToDbcsTable2;
               sourcewidecount += 1;
               break;
            } /* endswitch */
            wchar_t d = t[c];
            if (!d) {
               d = ToDbcsTable1[c];
            } /* endif */
            if (d) {
               c = d;
            } /* endif */
            if (c <= UCHAR_MAX) {
               RxJisCountCheck2(count, targetsize, sourcewide);
               target[count++] = c;
               continue;
            } /* endif */
         } /* endif */
      } else if (sourcewidecount < sourcewidesize) {
         PWCHAR_T *t = NULL;
         switch (sourcewide[sourcewidecount]) {
            case L'�':
            case L'�J':
               t = ToDbcsTable4;
               sourcewidecount += 1;
               break;
         case L'�':
         case L'�K':
            t = ToDbcsTable5;
            sourcewidecount += 1;
            break;
         } /* endswitch */
         wctomb(b, c);
         if (t && t[b[0]]) {
            c = t[b[0]][b[1]];
         } /* endif */
      } /* endif */
      RxJisCountCheck2(count + 1, targetsize, sourcewide);
      wctomb(b, c);
      strncpy(target + count, b, 2);
      count += 2;
   } /* endwhile */
   RxJisCountCheck2(count, targetsize, sourcewide);
   target[count] = '\0';
   delete sourcewide; 
   return (count);
}

static int
ToZenkakuKatakana(
PCHAR target,
PCHAR source,
int targetsize,
int sourcesize = 0,
int linesize = 0) {
   RxJisArgCheck(source, target, targetsize, sourcesize);
   int count = 0;
   wchar_t* sourcewide = new wchar_t[sourcesize + 1]; 
   if (!sourcewide) {
      return (CallingInvalid);
   } /* endif */
   const size_t sourcewidesize = nmbstowcs(sourcewide, sourcesize + 1, source, sourcesize); 
   size_t sourcewidecount = 0; 
   while (sourcewidecount < sourcewidesize) {
      wchar_t c = sourcewide[sourcewidecount++];
      char b[2];
      if (c <= SCHAR_MAX) {
         RxJisCountCheck2(count, targetsize, sourcewide);
         target[count++] = c;
         continue;
      } else if (c <= UCHAR_MAX) { 
         if (sourcewidecount >= sourcewidesize) {
            if (!ToDbcsTable1[c]) {
               RxJisCountCheck2(count, targetsize, sourcewide);
               target[count++] = c;
               continue;
            } /* endif */
            c = ToDbcsTable1[c];
         } else {
            wchar_t *t = ToDbcsTable1;
            switch (sourcewide[sourcewidecount]) {
            case L'�':
            case L'�K':
               t = ToDbcsTable3;
               sourcewidecount += 1;
               break;
            case L'�':
            case L'�J':
               t = ToDbcsTable2;
               sourcewidecount += 1;
               break;
            } /* endswitch */
            wchar_t d = t[c];
            if (!d) {
               d = ToDbcsTable1[c];
            } /* endif */
            if (d) {
               c = d;
            } /* endif */
            if (c <= UCHAR_MAX) {
               RxJisCountCheck2(count, targetsize, sourcewide);
               target[count++] = c;
               continue;
            } /* endif */
         } /* endif */
      } else if (sourcewidecount < sourcewidesize) {
         PWCHAR_T *t = NULL;
         switch (sourcewide[sourcewidecount]) {
            case L'�':
            case L'�J':
               t = ToDbcsTable4;
               sourcewidecount += 1;
               break;
         case L'�':
         case L'�K':
            t = ToDbcsTable5;
            sourcewidecount += 1;
            break;
         } /* endswitch */
         wctomb(b, c);
         if (t && t[b[0]]) {
            c = t[b[0]][b[1]];
         } /* endif */
      } /* endif */
      RxJisCountCheck2(count + 1, targetsize, sourcewide);
      wctomb(b, c);
      strncpy(target + count, b, 2);
      count += 2;
   } /* endwhile */
   RxJisCountCheck2(count, targetsize, sourcewide);
   target[count] = '\0';
   delete sourcewide; 
   return (count);
}

static int
ToQuotedPrintable(
PCHAR target,
PCHAR source,
int targetsize,
int sourcesize = 0,
int linesize = 0) {
   RxJisArgCheck(source, target, targetsize, sourcesize);
   int count = 0;
   int column = 0;
   for (int i = 1; i <= sourcesize; i += 1) {
      if (count + ToQuotedPrintableTable[*source].len >= targetsize) {
         return (RxJisError); 
      } /* endif */
      if (column + ToQuotedPrintableTable[*source].len > MaxMimeLineSize) {
         if (count + 3 >= targetsize) {
            return (RxJisError); 
         } /* endif */
         target[count++] = '=';
         target[count++] = '\r';
         target[count++] = '\n';
         column = 0;
      } /* endif */
      strncpy(target + count, ToQuotedPrintableTable[*source].seq, ToQuotedPrintableTable[*source].len);
      count += ToQuotedPrintableTable[*source].len;
      column += ToQuotedPrintableTable[*source].len;
      source += 1;
   } /* endfor */
   if (count >= targetsize) {
      return (RxJisError); 
   } /* endif */
   target[count] = '\0';
   return (count);
}

static int
ToBase64(
PCHAR target,
PCHAR source,
int targetsize,
int sourcesize = 0,
int linesize = 0) {
   RxJisArgCheck(source, target, targetsize, sourcesize);
   int count = 0;
   int column = 0;
   for (int i = 1; i <= sourcesize; i += 3) {
      RxJisCountCheck(count + 3, targetsize);
      if (column >= MaxMimeLineSize) {
         RxJisCountCheck(count + 2, targetsize);
         target[count++] = '\r';
         target[count++] = '\n';
         column = 0;
      } /* endif */
      long v;
      if (i + 2 <= sourcesize) {
         v = *source++ << (2 * ByteBitWidth);
         v |= *source++ << ByteBitWidth;
         v |= *source++;
         target[count++] = ToBase64Table[Base64Mask&(v>>(3*Base64BitWidth))];
         target[count++] = ToBase64Table[Base64Mask&(v>>2*Base64BitWidth)];
         target[count++] = ToBase64Table[Base64Mask&(v>>Base64BitWidth)];
         target[count++] = ToBase64Table[Base64Mask&v];
      } else if (i + 1 <= sourcesize) {
         v = *source++ << ByteBitWidth;
         v |= *source++;
         v <<= (3*Base64BitWidth-2*ByteBitWidth);
         target[count++] = ToBase64Table[Base64Mask&(v>>2*Base64BitWidth)];
         target[count++] = ToBase64Table[Base64Mask&(v>>Base64BitWidth)];
         target[count++] = ToBase64Table[Base64Mask&v];
         target[count++] = '=';
      } else {
         v = *source++ << (2*Base64BitWidth-ByteBitWidth);
         target[count++] = ToBase64Table[Base64Mask&(v>>Base64BitWidth)];
         target[count++] = ToBase64Table[Base64Mask&v];
         target[count++] = '=';
         target[count++] = '=';
      } /* endif */
   } /* endfor */
   RxJisCountCheck(count, targetsize);
   target[count] = '\0';
   return (count);
}

static int
Iso8859_1ToCp850(
PCHAR target,
PCHAR source,
int targetsize,
int sourcesize,  
int linesize) {  
   RxJisArgCheck(source, target, targetsize, sourcesize);
   RxJisCountCheck(sourcesize, targetsize);
   int count = 0;
   for (int sourcecount = 0; sourcecount < sourcesize; sourcecount += 1) {
      RxJisCountCheck(count, targetsize);
      target[count++] = ToCp850(source[sourcecount]);
   } /* endfor */
   RxJisCountCheck(count, targetsize);
   target[count] = '\0';
   return (count);
}

static int
Cp850ToIso8859_1(
PCHAR target,
PCHAR source,
int targetsize,
int sourcesize,  
int linesize) {  
   RxJisArgCheck(source, target, targetsize, sourcesize);
   RxJisCountCheck(sourcesize, targetsize);
   int count = 0;
   for (int sourcecount = 0; sourcecount < sourcesize; sourcecount += 1) {
      RxJisCountCheck(count, targetsize);
      target[count++] = ToIso8859_1(source[sourcecount]);
   } /* endfor */
   RxJisCountCheck(count, targetsize);
   target[count] = '\0';
   return (count);
}

static int
Cp852ToIso8859_2(
PCHAR target,
PCHAR source,
int targetsize,
int sourcesize,  
int linesize) {  
   RxJisArgCheck(source, target, targetsize, sourcesize);
   RxJisCountCheck(sourcesize, targetsize);
   int count = 0;
   for (int sourcecount = 0; sourcecount < sourcesize; sourcecount += 1) {
      RxJisCountCheck(count, targetsize);
      target[count++] = ToIso8859_2(source[sourcecount]);
   } /* endfor */
   RxJisCountCheck(count, targetsize);
   target[count] = '\0';
   return (count);
}

static int
Cp857ToIso8859_9(
PCHAR target,
PCHAR source,
int targetsize,
int sourcesize,  
int linesize) {  
   RxJisArgCheck(source, target, targetsize, sourcesize);
   RxJisCountCheck(sourcesize, targetsize);
   int count = 0;
   for (int sourcecount = 0; sourcecount < sourcesize; sourcecount += 1) {
      RxJisCountCheck(count, targetsize);
      target[count++] = ToIso8859_9(source[sourcecount]);
   } /* endfor */
   RxJisCountCheck(count, targetsize);
   target[count] = '\0';
   return (count);
}

static int
Iso8859_2ToCp852(
PCHAR target,
PCHAR source,
int targetsize,
int sourcesize,  
int linesize) {  
   RxJisArgCheck(source, target, targetsize, sourcesize);
   RxJisCountCheck(sourcesize, targetsize);
   int count = 0;
   for (int sourcecount = 0; sourcecount < sourcesize; sourcecount += 1) {
      target[count++] = ToCp852(source[sourcecount]);
   } /* endfor */
   RxJisCountCheck(count, targetsize);
   target[count] = '\0';
   return (count);
}

static int
Iso8859_9ToCp857(
PCHAR target,
PCHAR source,
int targetsize,
int sourcesize,  
int linesize) {  
   RxJisArgCheck(source, target, targetsize, sourcesize);
   RxJisCountCheck(sourcesize, targetsize);
   int count = 0;
   for (int sourcecount = 0; sourcecount < sourcesize; sourcecount += 1) {
      target[count++] = ToCp857(source[sourcecount]);
   } /* endfor */
   RxJisCountCheck(count, targetsize);
   target[count] = '\0';
   return (count);
}

static int
ToPc(
PCHAR target,
PCHAR source,
int targetsize,
int sourcesize,  
int linesize) {  
   RxJisArgCheck(source, target, targetsize, sourcesize);
   int count = 0;
   int sourcecount = 0;
   CharSet currentset = USASCII; 
   CHAR currentmask = 0x00;
   PWCHAR_T* jistopccode; 
   while (sourcecount < sourcesize) { 
      int i;
      switch (source[sourcecount]) {
      case SO:
      case SI:
         target[count++] = source[sourcecount++];
         break;
      case Esc:
         for (i = 0; DoubleByteSeqTable[i].seq; i += 1) {
            if (sourcecount + DoubleByteSeqTable[i].len > sourcesize) {
               continue; 
            } /* endif */
            if (strncmp(source + sourcecount, DoubleByteSeqTable[i].seq, DoubleByteSeqTable[i].len) == 0) {
               break;
            } /* endif */
         } /* endfor */
         if (DoubleByteSeqTable[i].seq != NULL) {
            if (sourcecount + DoubleByteSeqTable[i].len > sourcesize) {
               RxJisCountCheck(count, targetsize);
               target[count++] = source[sourcecount++];
               continue;
            } /* endif */
            sourcecount += DoubleByteSeqTable[i].len;
            switch (DoubleByteSeqTable[i].charset) { 
            case USASCII:
               switch (currentset) {
               case ISO8859_1:
               case ISO8859_7:
                  RxJisCountCheck(count + Jis83OutSeq.len, targetsize);
                  strncpy(target + count, Jis83OutSeq.seq, Jis83OutSeq.len);
                  count += Jis83OutSeq.len;
                  break;
               default:
                 break;
               } /* endswitch */
               currentset = DoubleByteSeqTable[i].charset;
               break;
            case SS2:
               if (sourcecount < sourcesize) {
                  RxJisCountCheck(count, targetsize);
                  switch (currentset) {
                  case ISO8859_1:
                     target[count++] = ToCp850(ByteMsb | source[sourcecount++]); 
                     break;
                  default:
                    target[count++] = source[sourcecount++];                 
                    break;
                  } /* endswitch */
               } /* endif */
               break;
            case ISO8859_1:
            case ISO8859_7:
               RxJisCountCheck(count + DoubleByteSeqTable[i].len, targetsize);
               strncpy(target + count, DoubleByteSeqTable[i].seq, DoubleByteSeqTable[i].len);
               currentset = DoubleByteSeqTable[i].charset;
               break;
            default:
              switch (currentset) {
              case ISO8859_1:
              case ISO8859_7:
              case ISO2022KR:
                 RxJisCountCheck(count + Jis83OutSeq.len, targetsize);
                 strncpy(target + count, Jis83OutSeq.seq, Jis83OutSeq.len);
                 count += Jis83OutSeq.len;
                 break;
              } /* endswitch */
              currentset = DoubleByteSeqTable[i].charset;
              jistopccode = DoubleByteSeqTable[i].jistopccodetable;
              break;
            } /* endswitch */
         } else {
            RxJisCountCheck(count, targetsize);
            currentset = USASCII;
            target[count++] = source[sourcecount++];                               
         } /* endif */
         break;
      default: 
        wchar_t c;
        int l;
        int h;
        switch (currentset) {
        case HankakuKatakana:
           RxJisCountCheck(count, targetsize);
           target[count++] = ByteMsb | source[sourcecount++];
           break;
        case ISO2022JP:
        case JIS78:
        case JISX0212_1990:
        case ISO2022KR:
           if (sourcecount + 2 > sourcesize) { 
              RxJisCountCheck(count, targetsize);
              target[count++] = source[sourcecount++];
              continue;
           } /* endif */                                     
           RxJisCountCheck(count + 2, targetsize);
           if (source[sourcecount] <= ' ' || source[sourcecount+1] <= ' ') { 
              target[count++] = source[sourcecount++];       
              target[count++] = source[sourcecount++];       
              currentset = USASCII;
              continue;                                      
           } /* endif */                                     
           h = source[sourcecount++];           
           l = source[sourcecount++];           
           c = h << ByteBitWidth | l;
           switch (currentset) {
           case ISO2022JP:
           case JIS78:
              c = JisCodeToPcCode(c);
              if (InJis90 && JIS78 == currentset) {
                 c = OldJisToNewJis(c);
              } else if (!InJis90 && ISO2022JP == currentset) {
                 c = NewJisToOldJis(c);
              } /* endif */
              break;
           default:
             c = JisToPc(c, jistopccode);              
             break;
           } /* endswitch */
           target[count++] = c >> ByteBitWidth;      
           target[count++] = c & ByteMask;           
           break;
        default:
          RxJisCountCheck(count, targetsize);
          target[count++] = source[sourcecount++];
          break;
        } /* endswitch */
        break;
      } /* endswitch */
   } /* endwhile */
   switch (currentset) {
   case ISO8859_1:
   case ISO8859_7:
   case ISO2022KR:
      RxJisCountCheck(count + Jis83OutSeq.len, targetsize);
      strncpy(target + count, Jis83OutSeq.seq, Jis83OutSeq.len);
      count += Jis83OutSeq.len;
      break;
   } /* endswitch */
   RxJisCountCheck(count, targetsize);
   target[count] = '\0';
   return (count);
}

static int
QuotedPrintableTo(
PCHAR target,
PCHAR source,
int targetsize,
int sourcesize, 
int linesize) { 
   RxJisArgCheck(source, target, targetsize, sourcesize);
   int count = 0;
   int sourcecount = 0; 
   while (sourcecount < sourcesize) { 
      long v;
      long c;
      int p;
      switch (source[sourcecount]) {
      case '=':
         RxJisCountCheck(count, targetsize);
         if (!source[++sourcecount]) {
            continue;
         } /* endif */
         v = QuotedPrintableTable[source[sourcecount]];
         if (QuotedPrintableError == v) {
            continue;
         } /* endif */
         if (!source[++sourcecount]) {
            continue;
         } /* endif */
         c = QuotedPrintableTable[source[sourcecount++]];
         if (QuotedPrintableError == c) {
            continue;
         } /* endif */
         target[count++] = (v << 4) | c;
         break;
      case Space:
      case Ht:
         p = sourcecount;
         while (source[p]) {
            if (source[p] != Space && source[p] != Ht) {
               break;
            } /* endif */
            p += 1;
         } /* endwhile */
         if (source[p]) {
            p = sourcecount;
            while (source[p]) {
               RxJisCountCheck(count, targetsize);
               if (source[p] != Space && source[p] != Ht) {
                  break;
               } /* endif */
               target[count++] = source[p++];
            } /* endwhile */
         } /* endif */
         sourcecount = p;
         break;
      default: 
         RxJisCountCheck(count, targetsize);
         target[count++] = source[sourcecount++];
         break;
      } /* endswitch */
   } /* endwhile */
   RxJisCountCheck(count, targetsize);
   target[count] = '\0';
   return (count);
}

static int
Base64To(
PCHAR target,
PCHAR source,
int targetsize,
int sourcesize, 
int linesize) { 
   RxJisArgCheck(source, target, targetsize, sourcesize);
   int count = 0;
   for (int i = 1; i <= sourcesize; i += 4) {
      long v = 0;
      int m = 0;
      for (int j = 1; *source && j <= 4; j += 1) {
         long c = Base64Table[*source++];
         switch (c) {
         case Base64Error:
         case Base64Pad:
            break;
         default:
            v = (v << Base64BitWidth) | c;
            m += Base64BitWidth;
            break;
         } /* endswitch */
      } /* endfor */
      if (m >= ByteBitWidth) {
         v >>= (m % ByteBitWidth);
         m /= ByteBitWidth;
      } else {
         v <<= (ByteBitWidth - m);
         m = 1;
      } /* endif */
      if (count + m > targetsize) {
         return (RxJisError); 
      } /* endif */
      for (j = m - 1; j >= 0; j -= 1) {
         target[count+j] = v & ByteMask;
         v >>= ByteBitWidth;
      } /* endfor */
      count += m;
   } /* endfor */
   target[count] = '\0';
   return (count);
}

static ULONG
JisCommon(
int (*convert)(PCHAR, PCHAR, int, int, int),
PCHAR target,
PCHAR source,
int targetsize,
int sourcesize = 0,
int (*mintargetsize)(PCHAR, int, int) = NULL) {
   if (!TableIsLoaded) {  
      LoadRxJisTables();  
   } /* endif */          
   if (0 == sourcesize) {
      sourcesize = strlen(source);
   } /* endif */
   if (0 == sourcesize) {
      target[0] = '\0';
      return (0);
   } /* endif */
   int minsize;
   if (mintargetsize) {
      minsize = (*mintargetsize)(source, sourcesize, 0);
   } else {
      minsize = sourcesize;
   } /* endif */
   if (targetsize < minsize) {
      return (RxJisError);
   } /* endif */
   return ((*convert)(target, source, targetsize, sourcesize, 0));
}

int _Export 
JisToJis(
char* target, 
char* source, 
int targetsize, 
int sourcesize) {
   return (JisCommon(ToJis, target, source, targetsize, sourcesize, JisSize));
}

int _Export 
JisToEuc(
char* target, 
char* source, 
int targetsize, 
int sourcesize) {
   return (JisCommon(ToEuc, target, source, targetsize, sourcesize, EucSize));
}

int _Export 
JisToBase64(
char* target,
char* source, 
int targetsize, 
int sourcesize) {
   return (JisCommon(ToBase64, target, source, targetsize, sourcesize, Base64Size));
}

int _Export 
JisToQuotedPrintable(
char* target, 
char* source, 
int targetsize, 
int sourcesize) {
   return (JisCommon(ToQuotedPrintable, target, source, targetsize, sourcesize, QuotedPrintableSize));
}

int _Export JisJisTo(
char* target, 
char* source, 
int targetsize, 
int sourcesize) {
   return (JisCommon(ToPc, target, source, targetsize, sourcesize));
}

int _Export 
JisBase64To(
char* target, 
char* source, 
int targetsize, 
int sourcesize) {
   return (JisCommon(Base64To, target, source, targetsize, sourcesize));
}

int _Export 
JisEucTo(
char* target, 
char* source, 
int targetsize, 
int sourcesize) {
   return (JisCommon(EucTo, target, source, targetsize, sourcesize));
}

int _Export 
JisQuotedPrintableTo(
char* target, 
char* source, 
int targetsize, 
int sourcesize) {
   return (JisCommon(QuotedPrintableTo, target, source, targetsize, sourcesize));
}

int _Export 
JisMimeJisTo(
char* target, 
char* source, 
int targetsize, 
int sourcesize) {
   return (JisCommon(MimeJisTo, target, source, targetsize, sourcesize));
}

int _Export 
JisJisCharTo(
char* target, 
char* source, 
int targetsize, 
int sourcesize) {
   return (JisCommon(JisCharTo, target, source, targetsize, sourcesize));
}

int _Export 
JisToJisChar(
char* target, 
char* source, 
int targetsize, 
int sourcesize) {
   return (JisCommon(ToJisChar, target, source, targetsize, sourcesize));
}

int _Export 
JisToSbcs(
char* target, 
char* source, 
int targetsize, 
int sourcesize) {
   return (JisCommon(ToSbcs, target, source, targetsize, sourcesize));
}

int _Export 
JisToDbcs(
char* target, 
char* source, 
int targetsize, 
int sourcesize) {
   return (JisCommon(ToDbcs, target, source, targetsize, sourcesize, DbcsSize));
}

int _Export 
JisToAscii(
char* target, 
char* source, 
int targetsize, 
int sourcesize) {
   return (JisCommon(ToAscii, target, source, targetsize, sourcesize));
}

int _Export 
JisToUpper(
char* target, 
char* source, 
int targetsize, 
int sourcesize) {
   return (JisCommon(ToUpper, target, source, targetsize, sourcesize));
}

int _Export 
JisCp850ToIso8859_1(
char* target, 
char* source, 
int targetsize, 
int sourcesize) {
   return (JisCommon(Cp850ToIso8859_1, target, source, targetsize, sourcesize));
}

int _Export 
JisCp852ToIso8859_2(
char* target, 
char* source, 
int targetsize, 
int sourcesize) {
   return (JisCommon(Cp852ToIso8859_2, target, source, targetsize, sourcesize));
}

int _Export 
JisCp857ToIso8859_9(
char* target, 
char* source, 
int targetsize, 
int sourcesize) {
   return (JisCommon(Cp857ToIso8859_9, target, source, targetsize, sourcesize));
}

int _Export 
JisIso8859_9ToCp857(
char* target, 
char* source, 
int targetsize, 
int sourcesize) {
   return (JisCommon(Iso8859_9ToCp857, target, source, targetsize, sourcesize));
}

int _Export 
JisIso8859_2ToCp852(
char* target, 
char* source, 
int targetsize, 
int sourcesize) {
   return (JisCommon(Iso8859_2ToCp852, target, source, targetsize, sourcesize));
}

int _Export 
JisIso8859_1ToCp850(
char* target, 
char* source, 
int targetsize, 
int sourcesize) {
   return (JisCommon(Iso8859_1ToCp850, target, source, targetsize, sourcesize));
}

int _Export 
JisToZenkakuKatakana(
char* target, 
char* source, 
int targetsize, 
int sourcesize) {
   return (JisCommon(ToZenkakuKatakana, target, source, targetsize, sourcesize));
}

static ULONG
RxJisCommon(
PUCHAR name, 
ULONG argc,
RXSTRING argv[],
PSZ queuename,
RXSTRING *retstr,
int (*convert)(PCHAR, PCHAR, int, int, int),
int (*mintargetsize)(PCHAR, int, int) = NULL) {
   if (0 == argc || argc > 2) {
      return (CallingInvalid);
   } /* endif */
   if (NULL == retstr || RXNULLSTRING(argv[0])) {
      return (CallingInvalid);
   } /* endif */
   PSZ& source = RXSTRPTR(argv[0]);
   const int& sourcesize = RXSTRLEN(argv[0]);
   int linesize = 0;
   if (argc > 1) {
      if (RXNULLSTRING(argv[1])) {
         return (CallingInvalid);
      } /* endif */
      int n = sscanf(RXSTRPTR(argv[1]), "%d", &linesize);
      if (n != 1 || linesize < MaxMimeLineSize / 2 || linesize > MaxMimeLineSize) {
         return (CallingInvalid);
      } /* endif */
   } /* endif */
   if (0 == sourcesize) {    
      retstr->strlength = 0; 
      return (CallingValid); 
   } /* endif */             
   if (!TableIsLoaded) {  
      LoadRxJisTables();  
   } /* endif */          
   int minimumtargetsize;
   if (mintargetsize) {                                                   
      minimumtargetsize = (*mintargetsize)(source, sourcesize, linesize); 
   } else {                                                               
      minimumtargetsize = 2 * sourcesize + 1;
   } /* endif */                                                          
   if (RXNULLSTRING(*retstr) || RXSTRLEN(*retstr) < minimumtargetsize) {  
      retstr->strlength = minimumtargetsize; 
      APIRET code = DosAllocMem((PPVOID)&retstr->strptr, retstr->strlength, PAG_COMMIT | PAG_READ | PAG_WRITE);
      if (code != NO_ERROR) {
         return (CallingInvalid);
      } /* endif */
   } /* endif */
   int count = (*convert)(RXSTRPTR(*retstr), source, RXSTRLEN(*retstr), sourcesize, linesize);
   if (count < 0) {
      return (CallingInvalid);
   } /* endif */
   retstr->strlength = count;
   return (CallingValid);
}

ULONG _Export 
RxJisBase64To(
PUCHAR name, 
ULONG argc,
RXSTRING argv[],
PSZ queuename,
RXSTRING *retstr) {
   return (RxJisCommon(name, argc, argv, queuename, retstr, Base64To));
}

ULONG _Export 
RxJisToPc(
PUCHAR name, 
ULONG argc,
RXSTRING argv[],
PSZ queuename,
RXSTRING *retstr) {
   return (RxJisCommon(name, argc, argv, queuename, retstr, ToPc));
}

ULONG _Export
RxJisJisTo(
PUCHAR name, 
ULONG argc,
RXSTRING argv[],
PSZ queuename,
RXSTRING *retstr) {
   return (RxJisCommon(name, argc, argv, queuename, retstr, ToPc));
}

ULONG _Export
RxJisToZenkakuKatakana(
PUCHAR name, 
ULONG argc,
RXSTRING argv[],
PSZ queuename,
RXSTRING *retstr) {
   return (RxJisCommon(name, argc, argv, queuename, retstr, ToZenkakuKatakana));
}

ULONG _Export 
RxJisQuotedPrintableTo(
PUCHAR name, 
ULONG argc,
RXSTRING argv[],
PSZ queuename,
RXSTRING *retstr) {
   return (RxJisCommon(name, argc, argv, queuename, retstr, QuotedPrintableTo));
}

ULONG _Export 
RxJisToJis(
PUCHAR name, 
ULONG argc,
RXSTRING argv[],
PSZ queuename,
RXSTRING *retstr) {
   return (RxJisCommon(name, argc, argv, queuename, retstr, ToJis, JisSize));
}

ULONG _Export 
RxJisToBase64(
PUCHAR name, 
ULONG argc,
RXSTRING argv[],
PSZ queuename,
RXSTRING *retstr) {
   return (RxJisCommon(name, argc, argv, queuename, retstr, ToBase64, Base64Size));
}

ULONG _Export 
RxJisToQuotedPrintable(
PUCHAR name, 
ULONG argc,
RXSTRING argv[],
PSZ queuename,
RXSTRING *retstr) {
   return (RxJisCommon(name, argc, argv, queuename, retstr, ToQuotedPrintable, QuotedPrintableSize));
}

ULONG _Export                                                                
RxJisToEuc(                                                                  
PUCHAR name,                                                                 
ULONG argc,                                                                  
RXSTRING argv[],                                                             
PSZ queuename,                                                               
RXSTRING *retstr) {                                                          
   return (RxJisCommon(name, argc, argv, queuename, retstr, ToEuc, EucSize));
}                                                                            

ULONG _Export                                                                
RxJisKanjiAlias(                                                                  
PUCHAR name,                                                                 
ULONG argc,                                                                  
RXSTRING argv[],                                                             
PSZ queuename,                                                               
RXSTRING *retstr) {                                                          
   if (argc != 1) {
      return (CallingInvalid);
   } /* endif */
   if (NULL == retstr || RXNULLSTRING(argv[0])) {
      return (CallingInvalid);
   } /* endif */
   PSZ& source = RXSTRPTR(argv[0]);
   const int& sourcesize = RXSTRLEN(argv[0]);
   wchar_t* sourcewide = new wchar_t[sourcesize + 1]; 
   if (!sourcewide) {
      return (CallingInvalid);
   } /* endif */
   const size_t sourcewidesize = nmbstowcs(sourcewide, sourcesize + 1, source, sourcesize); 
   if (sourcewidesize != 1 || sourcewide[0] <= UCHAR_MAX) {
      return (CallingInvalid);
   } /* endif */
   if (!TableIsLoaded) {  
      LoadRxJisTables();  
   } /* endif */          
   wchar_t* t = new wchar_t[maxKanjiAliasSize];
   if (!t) {
      return (CallingInvalid);
   } /* endif */
   int n = JisKanjiAlias(sourcewide[0], t, maxKanjiAliasSize);
   if (n < 0) {
      return (CallingInvalid);
   } /* endif */
   if (0 == n) {    
      retstr->strlength = 0; 
      return (CallingValid); 
   } /* endif */             
   const int count = sizeof(wchar_t) * n;
   int minimumtargetsize = count + 1;                                 
   if (RXNULLSTRING(*retstr) || RXSTRLEN(*retstr) < minimumtargetsize) {  
      retstr->strlength = minimumtargetsize; 
      APIRET code = DosAllocMem((PPVOID)&retstr->strptr, retstr->strlength, PAG_COMMIT | PAG_READ | PAG_WRITE);
      if (code != NO_ERROR) {
         return (CallingInvalid);
      } /* endif */
   } /* endif */
   wcstombs(RXSTRPTR(*retstr), t, count);
   delete t;
   retstr->strlength = count;
   return (CallingValid);
}                                                                            

ULONG _Export                                                                
RxJisPriority(                                                                  
PUCHAR name,                                                                 
ULONG argc,                                                                  
RXSTRING argv[],                                                             
PSZ queuename,                                                               
RXSTRING *retstr) {                                                          
   if (!(0 == argc || 2 == argc)) {
      return (CallingInvalid);
   } /* endif */
   if (NULL == retstr) {
      return (CallingInvalid);
   } /* endif */
   if (2 == argc && (RXNULLSTRING(argv[0]) || RXNULLSTRING(argv[1]))) {
      return (CallingInvalid);
   } /* endif */
   APIRET code;
   if (2 == argc) {
      int nclass;
      int npri;
      int n = sscanf(RXSTRPTR(argv[0]), "%d", &nclass);
      if (n != 1 || nclass < PRTYC_NOCHANGE || nclass > PRTYC_FOREGROUNDSERVER) {
         return (CallingInvalid);
      } /* endif */
      LONG int delta;
      n = sscanf(RXSTRPTR(argv[1]), "%d", &delta);
      if (n != 1 || nclass < PRTYD_MINIMUM || nclass > PRTYD_MAXIMUM) {
         return (CallingInvalid);
      } /* endif */
      code = DosSetPriority(PRTYS_THREAD, nclass, delta, 0);
      if (code != NO_ERROR) {
         return (CallingInvalid);
      } /* endif */
   } /* endif */
   PTIB tib;
   PPIB pib;
   code = DosGetInfoBlocks(&tib, &pib);
   if (code != NO_ERROR) {
      return (CallingInvalid);
   } /* endif */
   const ULONG pri = tib->tib_ptib2->tib2_ulpri;
   const int ccls = (pri & 0x0000ff00) >> 8;
   const int cpri = pri & 0x000000ff;
   sprintf(RXSTRPTR(*retstr), "%d %d", ccls, cpri);
   retstr->strlength = strlen(RXSTRPTR(*retstr));
   return (CallingValid);
}                                                                            

ULONG _Export                                                                
RxJisTrace(                                                                  
PUCHAR name,                                                                 
ULONG argc,                                                                  
RXSTRING argv[],                                                             
PSZ queuename,                                                               
RXSTRING *retstr) {                                                          
   if (argc != 1 || RXNULLSTRING(argv[0]) || NULL == retstr) {
      return (CallingInvalid);
   } /* endif */
   time_t t = time(NULL);
   if ((time_t)(-1) == t) {
      return (CallingInvalid);
   } /* endif */
   struct tm *l = localtime(&t);
   const int s = RXSTRLEN(argv[0])+BUFSIZ;
   char *b = new char[s];
   if (!b) {
      return (CallingInvalid);
   } /* endif */
   size_t n = strftime(b, BUFSIZ - 3, "%y%m%d%H%M%S: ", l);
   if (!n) {
      delete b;
      return (CallingInvalid);
   } /* endif */
   ITrace::enableTrace();
   ITrace::writeToQueue();
   ITrace::enableWritePrefix();
   strncpy(b + strlen(b), RXSTRPTR(argv[0]), RXSTRLEN(argv[0])+1);
   ITrace::write(b);
   delete b;
   retstr->strlength = 0;
   return (CallingValid);
}                                                                            

ULONG _Export                                                                
RxJisEucTo(                                                                  
PUCHAR name,                                                                 
ULONG argc,                                                                  
RXSTRING argv[],                                                             
PSZ queuename,                                                               
RXSTRING *retstr) {                                                          
   return (RxJisCommon(name, argc, argv, queuename, retstr, EucTo));
}                                                                            

ULONG _Export                                                                
RxJisMimeJisTo(                                                              
PUCHAR name,                                                                 
ULONG argc,                                                                  
RXSTRING argv[],                                                             
PSZ queuename,                                                               
RXSTRING *retstr) {                                                          
   return (RxJisCommon(name, argc, argv, queuename, retstr, MimeJisTo));
}                                                                            

ULONG _Export                                                                
RxJisJisCharTo(                                                              
PUCHAR name,                                                                 
ULONG argc,                                                                  
RXSTRING argv[],                                                             
PSZ queuename,                                                               
RXSTRING *retstr) {                                                          
   return (RxJisCommon(name, argc, argv, queuename, retstr, JisCharTo));
}                                                                            

ULONG _Export                                                                
RxJisToJisChar(                                                              
PUCHAR name,                                                                 
ULONG argc,                                                                  
RXSTRING argv[],                                                             
PSZ queuename,                                                               
RXSTRING *retstr) {                                                          
   return (RxJisCommon(name, argc, argv, queuename, retstr, ToJisChar));
}                                                                            

ULONG _Export                                                                
RxJisToDbcs(                                                              
PUCHAR name,                                                                 
ULONG argc,                                                                  
RXSTRING argv[],                                                             
PSZ queuename,                                                               
RXSTRING *retstr) {                                                          
   return (RxJisCommon(name, argc, argv, queuename, retstr, ToDbcs, DbcsSize));
}                                                                            

ULONG _Export                                                                
RxJisToSbcs(                                                              
PUCHAR name,                                                                 
ULONG argc,                                                                  
RXSTRING argv[],                                                             
PSZ queuename,                                                               
RXSTRING *retstr) {                                                          
   return (RxJisCommon(name, argc, argv, queuename, retstr, ToSbcs));
}                                                                            

ULONG _Export                                                                
RxJisToAscii(                                                              
PUCHAR name,                                                                 
ULONG argc,                                                                  
RXSTRING argv[],                                                             
PSZ queuename,                                                               
RXSTRING *retstr) {                                                          
   return (RxJisCommon(name, argc, argv, queuename, retstr, ToAscii));
}                                                                            

ULONG _Export                                                                
RxJisToUpper(                                                              
PUCHAR name,                                                                 
ULONG argc,                                                                  
RXSTRING argv[],                                                             
PSZ queuename,                                                               
RXSTRING *retstr) {                                                          
   return (RxJisCommon(name, argc, argv, queuename, retstr, ToUpper));
}                                                                            

ULONG _Export                                                                
RxJisIso8859_1ToCp850(                                                              
PUCHAR name,                                                                 
ULONG argc,                                                                  
RXSTRING argv[],                                                             
PSZ queuename,                                                               
RXSTRING *retstr) {                                                          
   return (RxJisCommon(name, argc, argv, queuename, retstr, Iso8859_1ToCp850));
}                                                                            

ULONG _Export                                                                
RxJisIso8859_2ToCp852(                                                              
PUCHAR name,                                                                 
ULONG argc,                                                                  
RXSTRING argv[],                                                             
PSZ queuename,                                                               
RXSTRING *retstr) {                                                          
   return (RxJisCommon(name, argc, argv, queuename, retstr, Iso8859_2ToCp852));
}                                                                            

ULONG _Export                                                                
RxJisIso8859_9ToCp857(                                                              
PUCHAR name,                                                                 
ULONG argc,                                                                  
RXSTRING argv[],                                                             
PSZ queuename,                                                               
RXSTRING *retstr) {                                                          
   return (RxJisCommon(name, argc, argv, queuename, retstr, Iso8859_9ToCp857));
}                                                                            

ULONG _Export                                                                
RxJisCp857ToIso8859_9(                                                              
PUCHAR name,                                                                 
ULONG argc,                                                                  
RXSTRING argv[],                                                             
PSZ queuename,                                                               
RXSTRING *retstr) {                                                          
   return (RxJisCommon(name, argc, argv, queuename, retstr, Cp857ToIso8859_9));
}                                                                            

ULONG _Export                                                                
RxJisCp852ToIso8859_2(                                                              
PUCHAR name,                                                                 
ULONG argc,                                                                  
RXSTRING argv[],                                                             
PSZ queuename,                                                               
RXSTRING *retstr) {                                                          
   return (RxJisCommon(name, argc, argv, queuename, retstr, Cp852ToIso8859_2));
}                                                                            

ULONG _Export                                                                
RxJisCp850ToIso8859_1(                                                              
PUCHAR name,                                                                 
ULONG argc,                                                                  
RXSTRING argv[],                                                             
PSZ queuename,                                                               
RXSTRING *retstr) {                                                          
   return (RxJisCommon(name, argc, argv, queuename, retstr, Cp850ToIso8859_1));
}                                                                            

ULONG _Export                                                                
RxJisWords(                                                              
PUCHAR name,                                                                 
ULONG argc,                                                                  
RXSTRING argv[],                                                             
PSZ queuename,                                                               
RXSTRING *retstr) {                                                          
   if (argc != 1) {
      return (CallingInvalid);
   } /* endif */
   int count = JisWords(RXSTRPTR(argv[0]), RXSTRLEN(argv[0]));
   if (count < 0) {
      return (CallingInvalid);
   } /* endif */
   sprintf(RXSTRPTR(*retstr), "%d", count);
   retstr->strlength = strlen(RXSTRPTR(*retstr));
   return (CallingValid);
}                                                                            

ULONG _Export                                                                
RxJisWord(                                                              
PUCHAR name,                                                                 
ULONG argc,                                                                  
RXSTRING argv[],                                                             
PSZ queuename,                                                               
RXSTRING *retstr) {                                                          
   if (argc != 2) {
      return (CallingInvalid);
   } /* endif */
   if (NULL == retstr || RXNULLSTRING(argv[0]) || RXNULLSTRING(argv[1])) {
      return (CallingInvalid);
   } /* endif */
   PSZ& source = RXSTRPTR(argv[0]);
   const int& sourcesize = RXSTRLEN(argv[0]);
   int position = 0;
   int n = sscanf(RXSTRPTR(argv[1]), "%d", &position);
   if (n != 1 || position < 1) {
      return (CallingInvalid);
   } /* endif */
   if (0 == sourcesize) {    
      retstr->strlength = 0; 
      return (CallingValid); 
   } /* endif */             
   if (!TableIsLoaded) {  
      LoadRxJisTables();  
   } /* endif */          
   int minimumtargetsize = sourcesize + 1;                                 
   if (RXNULLSTRING(*retstr) || RXSTRLEN(*retstr) < minimumtargetsize) {  
      retstr->strlength = minimumtargetsize; 
      APIRET code = DosAllocMem((PPVOID)&retstr->strptr, retstr->strlength, PAG_COMMIT | PAG_READ | PAG_WRITE);
      if (code != NO_ERROR) {
         return (CallingInvalid);
      } /* endif */
   } /* endif */
   PSZ& target = RXSTRPTR(*retstr);
   const int& targetsize = RXSTRLEN(*retstr);
   int count = JisWord(target, source, targetsize, position, sourcesize);
   if (count < 0) {
      return (CallingInvalid);
   } /* endif */
   retstr->strlength = count;
   return (CallingValid);
}                                                                            

ULONG _Export                                                                
RxJisAppend(                                                              
PUCHAR name,                                                                 
ULONG argc,                                                                  
RXSTRING argv[],                                                             
PSZ queuename,                                                               
RXSTRING *retstr) {                                                          
   if (argc != 2) {
      return (CallingInvalid);
   } /* endif */
   if (NULL == retstr || RXNULLSTRING(argv[0]) || RXNULLSTRING(argv[1])) {
      return (CallingInvalid);
   } /* endif */
   if (!TableIsLoaded) {  
      LoadRxJisTables();  
   } /* endif */          
   PSZ& source = RXSTRPTR(argv[1]);
   const int& sourcesize = RXSTRLEN(argv[1]);
   const int& targetlength = RXSTRLEN(argv[0]);
   const int minimumtargetsize = targetlength + 1 + sourcesize + 1;                                 
   PSZ& target = RXSTRPTR(*retstr);
   if (!target || RXSTRLEN(*retstr) < minimumtargetsize) {  
      retstr->strlength = minimumtargetsize; 
      APIRET code = DosAllocMem((PPVOID)&target, RXSTRLEN(*retstr), PAG_COMMIT | PAG_READ | PAG_WRITE);
      if (code != NO_ERROR) {
         return (CallingInvalid);
      } /* endif */
   } /* endif */
   const int& targetsize = RXSTRLEN(*retstr);
   memcpy(target, RXSTRPTR(argv[0]), RXSTRLEN(argv[0]) + 1);
   int count = JisAppend(target, source, targetsize, targetlength, sourcesize);
   if (count < 0) {
      return (CallingInvalid);
   } /* endif */
   retstr->strlength = count;
   return (CallingValid);
}                                                                            

static int
parsenamevalue(
PCHAR target,
int targetsize,
PCHAR source,
int& sourceposition,
int sourcesize,
CHAR delimiter) {
   int count = 0;
   while (sourceposition < sourcesize) {
      if (IsDbcs1st(source[sourceposition])) {
         target[count++] = source[sourceposition++];
         if (sourceposition < sourcesize) {
            target[count++] = source[sourceposition++];
         } /* endif */
         continue;
      } /* endif */
      if (delimiter == source[sourceposition]) {
         sourceposition += 1;
         break;
      } /* endif */
      switch (source[sourceposition]) {
      case '%':
         sourceposition += 1;
         if (sourceposition + 1 < sourcesize) {
            int code;
            sscanf(&source[sourceposition], "%2x", &code);
            sourceposition += 2;
            target[count++] = code;
         } /* endif */
         break;
      case '+':
         target[count++] = ' ';
         sourceposition += 1;
         break;
      default: 
        target[count++] = source[sourceposition++];
        break;
      } /* endswitch */
   } /* endwhile */
   target[count] = '\0';
   return (count);
}

static int
setrexxvar(
PCHAR varname,
PCHAR varvalue,
int varvaluesize) {
   SHVBLOCK block;
   block.shvcode = RXSHV_SYSET;
   block.shvret = RXSHV_OK;
   block.shvnext = NULL;
   MAKERXSTRING(block.shvname, varname, strlen(varname));
   MAKERXSTRING(block.shvvalue, varvalue, varvaluesize);
   ULONG rc = RexxVariablePool(&block);
   if (RXSHV_NOAVL == rc || ~(RXSHV_OK | RXSHV_NEWV) & block.shvret) {
      return (CallingInvalid);
   } /* endif */
   return (CallingValid);
}

ULONG _Export                                                                
RxJisUrlToVar(                                                              
PUCHAR name,                                                                 
ULONG argc,                                                                  
RXSTRING argv[],                                                             
PSZ queuename,                                                               
RXSTRING *retstr) {                                                          
   if (argc < 1 || argc > 2) {
      return (CallingInvalid);
   } /* endif */
   if (NULL == retstr || RXNULLSTRING(argv[0]) || (2 == argc && RXNULLSTRING(argv[1]) || RXSTRLEN(argv[1]) < 1)) {
      return (CallingInvalid);
   } /* endif */
   if (!TableIsLoaded) {  
      LoadRxJisTables();  
   } /* endif */          
   PSZ& url = RXSTRPTR(argv[0]);
   const int& urlsize = RXSTRLEN(argv[0]);
   const int worksize = urlsize + 1;
   PSZ stemname;
   if (2 == argc) {
      stemname = new CHAR[RXSTRLEN(argv[1]) + 1];
      strncpy(stemname, RXSTRPTR(argv[1]), RXSTRLEN(argv[1]) + 1);
      if ('.' == stemname[RXSTRLEN(argv[1]) - 1]) {
         stemname[RXSTRLEN(argv[1]) - 1] = '\0';
      } /* endif */
   } else {
      stemname = new CHAR[4];
      strncpy(stemname, "URL", 4);
   } /* endif */
   PCHAR varname = new CHAR[worksize];
   PCHAR varvalue = new CHAR[worksize];
   PCHAR temp = new CHAR[worksize];
   sprintf(varname, "%s.", stemname);
   if (setrexxvar(varname, "", 0) != CallingValid) {
      return (CallingInvalid);
   } /* endif */
   int i = 0;
   parsenamevalue(temp, worksize, url, i, urlsize, '?');
   while (i < urlsize) {
      int tempsize = parsenamevalue(temp, worksize, url, i, urlsize, '=');
      sprintf(varname, "%s.%s", stemname, temp);
      tempsize = parsenamevalue(temp, worksize, url, i, urlsize, '&');
      int varvaluesize = JisJisTo(varvalue, temp, worksize, tempsize);
      if (setrexxvar(varname, varvalue, varvaluesize) != CallingValid) {
         return (CallingInvalid);
      } /* endif */
   } /* endwhile */
   delete stemname;
   delete varname;
   delete varvalue;
   delete temp;
   retstr->strlength = 0;
   return (CallingValid);
}                                                                            

ULONG _Export                                                                
RxJisWordIndex(
PUCHAR name,                                                                 
ULONG argc,                                                                  
RXSTRING argv[],                                                             
PSZ queuename,                                                               
RXSTRING *retstr) {                                                          
   if (argc != 2) {
      return (CallingInvalid);
   } /* endif */
   if (NULL == retstr || RXNULLSTRING(argv[0]) || RXNULLSTRING(argv[1])) {
      return (CallingInvalid);
   } /* endif */
   PSZ& source = RXSTRPTR(argv[0]);
   const int& sourcesize = RXSTRLEN(argv[0]);
   int position = 0;
   int n = sscanf(RXSTRPTR(argv[1]), "%d", &position);
   if (n != 1 || position < 1) {
      return (CallingInvalid);
   } /* endif */
   if (0 == sourcesize) {    
      retstr->strlength = 0; 
      return (CallingValid); 
   } /* endif */             
   if (!TableIsLoaded) {  
      LoadRxJisTables();  
   } /* endif */          
   int minimumtargetsize = sourcesize + 1;                                 
   if (RXNULLSTRING(*retstr) || RXSTRLEN(*retstr) < minimumtargetsize) {  
      retstr->strlength = minimumtargetsize; 
      APIRET code = DosAllocMem((PPVOID)&retstr->strptr, retstr->strlength, PAG_COMMIT | PAG_READ | PAG_WRITE);
      if (code != NO_ERROR) {
         return (CallingInvalid);
      } /* endif */
   } /* endif */
   PSZ& target = RXSTRPTR(*retstr);
   const int& targetsize = RXSTRLEN(*retstr);
   int count = JisWordIndex(target, source, targetsize, position, sourcesize);
   if (count < 0) {
      return (CallingInvalid);
   } /* endif */
   sprintf(RXSTRPTR(*retstr), "%d", count);
   retstr->strlength = strlen(RXSTRPTR(*retstr));
   return (CallingValid);
}                                                                            

static APIRET
LoadRxJisTables(void) {
   if (TableIsLoaded) {  
      return (NO_ERROR); 
   } /* endif */         
   ULONG cplistsize;
   ULONG cplist[CpListSize];
   APIRET rc = DosQueryCp(sizeof(cplist), cplist, &cplistsize);
   if (rc != NO_ERROR) {
      return (rc);
   } /* endif */
   DefaultCodepage = cplist[0];
   if (943 == DefaultCodepage) {
      InJis90 = TRUE;
   } else {
      PCHAR v = getenv(JisEnvVarName);                                                  
      if (v) {                                                                          
         PCHAR s = strstr(v, Jis90Value);                                               
         if (s) {                                                                       
            InJis90 = TRUE;                                                             
         } /* endif */                                                                  
      } /* endif */                                                                     
   } /* endif */
   NoOfMimeEncodedWord = 2 * NoOfMimeCharSet;
   MimeEncodedWordTable = new MimeCharSet[NoOfMimeEncodedWord];
   for (int i = 0; i < NoOfMimeCharSet; i += 1) {
      int j = 2 * i;
      MimeEncodedWordTable[j].namesize = MimeEncodedWordTable[j+1].namesize = 2 + MimeCharSetTable[i].namesize + 3;
      MimeEncodedWordTable[j].charset = MimeEncodedWordTable[j+1].charset = MimeCharSetTable[i].charset;
      MimeEncodedWordTable[j].name = new char[MimeEncodedWordTable[j].namesize+1];
      MimeEncodedWordTable[j+1].name = new char[MimeEncodedWordTable[j+1].namesize+1];
      sprintf(MimeEncodedWordTable[j].name, "=?%s?B?", MimeCharSetTable[i].name);
      sprintf(MimeEncodedWordTable[j+1].name, "=?%s?Q?", MimeCharSetTable[i].name);
   } /* endfor */
   qsort(MimeEncodedWordTable, NoOfMimeEncodedWord, sizeof(MimeEncodedWordTable[0]), compcharset);
   CHAR name[BUFSIZ];
   HMODULE hmod;
   rc = DosLoadModule(name, sizeof(name), "PMNLS", &hmod);
   if (rc != NO_ERROR) {
      return (rc);
   } /* endif */
   rc = DosQueryProcAddr(hmod, 0L, "NLSFINDWORD", (PFN*)&NlsFindWord);
   if (rc != NO_ERROR) {
      return (rc);
   } /* endif */
   COUNTRYCODE cc;
   cc.country = 0;
   cc.codepage = DefaultCodepage;
   CHAR vec[BUFSIZ];
   rc = DosQueryDBCSEnv(sizeof(vec), &cc, vec);
   if (rc != NO_ERROR) {
      return (rc);
   } /* endif */
   for (i = 0; vec[i]; i += 2) {
      for (int j = vec[i]; j <= vec[i+1]; j += 1) {
         DbcsVec[j] = TRUE;
      } /* endfor */
   } /* endfor */
   TableIsLoaded = TRUE;
   return (NO_ERROR);
}

ULONG _Export 
RxJisLoadFuncs(
PUCHAR name, 
ULONG argc,
RXSTRING argv[],
PSZ queuename,
RXSTRING *retstr) {
   if (argc > 0) {
      return (CallingInvalid);
   } /* endif */
   for (int i = 0; i < NoOfEntries; i += 1) {
      ULONG code = RexxDeregisterFunction(RxJisFuncsTable[i]);
      switch (code) {
      case RXFUNC_OK:
      case RXFUNC_DEFINED:
      case RXFUNC_NOTREG:
         break;
      default:
         return (CallingInvalid);
      } /* endswitch */
      code = RexxRegisterFunctionDll(RxJisFuncsTable[i], RxJisDll, RxJisFuncsTable[i]);
      switch (code) {
      case RXFUNC_OK:
         break;
      default:
         return (CallingInvalid);
      } /* endswitch */
      if (code != RXFUNC_OK && code != RXFUNC_DEFINED) {
         return (CallingInvalid);
      } /* endif */
   } /* endfor */
   if (LoadRxJisTables() != NO_ERROR) {
      return (CallingInvalid);
   } /* endif */
   extern char *RxJisDate;
   extern char *RxJisTime;
   i = sprintf(RXSTRPTR(*retstr), "RXJIS Version: %s (%s %s)", RxJisVersion, RxJisDate, RxJisTime);
   if (i + 1 > RXSTRLEN(*retstr)) {
      return (CallingInvalid);
   } /* endif */
   retstr->strlength = i;
   return (CallingValid);
}

ULONG _Export  
RxJisDropFuncs(
PUCHAR name, 
ULONG argc,
RXSTRING argv[],
PSZ queuename,
RXSTRING *retstr) {
   if (argc > 0) {
      return (CallingInvalid);
   } /* endif */
   for (int i = 0; i < NoOfEntries; i += 1) {
      ULONG code = RexxDeregisterFunction(RxJisFuncsTable[i]);
      switch (code) {
      case RXFUNC_OK:
      case RXFUNC_DEFINED:
      case RXFUNC_NOTREG:
         break;
      default:
         return (CallingInvalid);
      } /* endswitch */
   } /* endfor */
   retstr->strlength = 0;
   return (CallingValid);
}
