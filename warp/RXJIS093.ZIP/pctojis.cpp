/* product name: RXJIS                                                */
/* Version:      0.90                                                 */
/* author:       YANO Takashi                                         */
/* target:       OS/2 Warp J3.0+ (J2.1 is possible)                   */
/* source name:  PCTOJIS.CPP                                          */
/* address:      tyano@ca2.so-net.or.jp or tyano@yamato.ibm.co.jp     */
/* comment:      RXJIS is a utility functions for REXX.               */
/*               This header file is a interface to be called from    */
/*               C/C++.                                               */
/* history: 1997-08-05 0.90                                           */
/*                                                                    */
#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include <string.h>
#include <os2.h>
#include "ibm2jis.hpp"
#include "pc2jis.hpp"
#include "pctojis.hpp"

BOOL _Export InJis90 = FALSE;
BOOL _Export DbcsVec[UCHAR_MAX+1];

wchar_t _Export 
OldJisToNewJis(
wchar_t pccode) {
   switch (pccode) {
   case 0xe9cb: /* �� */
      pccode = 0x88b1;
   case 0x88b1: /* �� */
      pccode = 0xe9cb;
   case 0xe9f2: /* �� */
      pccode = 0x89a7;
   case 0x89a7: /* �� */
      pccode = 0xe9f2;
   case 0xe579: /* �y */
      pccode = 0x8a61;
   case 0x8a61: /* �a */
      pccode = 0xe579;
   case 0x9d98: /* �� */
      pccode = 0x8a68;
   case 0x8a68: /* �h */
      pccode = 0x9d98;
   case 0xe27d: /* �} */
      pccode = 0x8a96;
   case 0x8a96: /* �� */
      pccode = 0xe27d;
   case 0x9ff3: /* �� */
      pccode = 0x8ac1;
   case 0x8ac1: /* �� */
      pccode = 0x9ff3;
   case 0xe67c: /* �| */
      pccode = 0x8ad0;
   case 0x8ad0: /* �� */
      pccode = 0xe67c;
   case 0xe8f2: /* �� */
      pccode = 0x8c7a;
   case 0x8c7a: /* �z */
      pccode = 0xe8f2;
   case 0xe1e6: /* �� */
      pccode = 0x8d7b;
   case 0x8d7b: /* �{ */
      pccode = 0xe1e6;
   case 0xe541: /* �A */
      pccode = 0x8ec7;
   case 0x8ec7: /* �� */
      pccode = 0xe541;
   case 0xe8d5: /* �� */
      pccode = 0x9078;
   case 0x9078: /* �x */
      pccode = 0xe8d5;
   case 0xe6cb: /* �� */
      pccode = 0x9147;
   case 0x9147: /* �G */
      pccode = 0xe6cb;
   case 0x9ae2: /* �� */
      pccode = 0x92d9;
   case 0x92d9: /* �� */
      pccode = 0x9ae2;
   case 0xe1e8: /* �� */
      pccode = 0x9376;
   case 0x9376: /* �v */
      pccode = 0xe1e8;
   case 0x9e8d: /* �� */
      pccode = 0x938e;
   case 0x938e: /* �� */
      pccode = 0x9e8d;
   case 0x9fb7: /* �� */
      pccode = 0x9393;
   case 0x9393: /* �� */
      pccode = 0x9fb7;
   case 0xe78e: /* � */
      pccode = 0x93f4;
   case 0x93f4: /* �� */
      pccode = 0xe78e;
   case 0xe5a2: /* � */
      pccode = 0x9488;
   case 0x9488: /* �� */
      pccode = 0xe5a2;
   case 0x9e77: /* �w */
      pccode = 0x954f;
   case 0x954f: /* �O */
      pccode = 0x9e77;
   case 0x98d4: /* �� */
      pccode = 0x9699;
   case 0x9699: /* �� */
      pccode = 0x98d4;
   case 0xe54d: /* �M */
      pccode = 0x96f7;
   case 0x96f7: /* �� */
      pccode = 0xe54d;
   case 0xe2c4: /* �� */
      pccode = 0x9855;
   case 0x9855: /* �U */
      pccode = 0xe2c4;
   case 0xea9f: /* � */
      pccode = 0x8bc4;
   case 0x8bc4: /* �� */
      pccode = 0xea9f;
   case 0xeaa0: /* � */
      pccode = 0x968a;
   case 0x968a: /* �� */
      pccode = 0xeaa0;
   case 0xeaa1: /* � */
      pccode = 0x9779;
   case 0x9779: /* �y */
      pccode = 0xeaa1;
   case 0xeaa2: /* � */
      pccode = 0xe0f4;
   case 0xe0f4: /* �� */
      pccode = 0xeaa2;
   case 0xfa5b: /* �[ */
      pccode = 0x81e6;
   case 0xfa54: /* �T */
      pccode = 0x81ca;
   case 0x8d56: /* �V */
      pccode = 0xfad0;
   case 0xfad0: /* �� */
      pccode = 0x8d56;
   } /* endswitch */
   return (pccode);
}

wchar_t _Export 
NewJisToOldJis(
wchar_t pccode) {
   switch (pccode) {
   case 0xe9cb: /* �� */
      pccode = 0x88b1;
   case 0x88b1: /* �� */
      pccode = 0xe9cb;
   case 0xe9f2: /* �� */
      pccode = 0x89a7;
   case 0x89a7: /* �� */
      pccode = 0xe9f2;
   case 0xe579: /* �y */
      pccode = 0x8a61;
   case 0x8a61: /* �a */
      pccode = 0xe579;
   case 0x9d98: /* �� */
      pccode = 0x8a68;
   case 0x8a68: /* �h */
      pccode = 0x9d98;
   case 0xe27d: /* �} */
      pccode = 0x8a96;
   case 0x8a96: /* �� */
      pccode = 0xe27d;
   case 0x9ff3: /* �� */
      pccode = 0x8ac1;
   case 0x8ac1: /* �� */
      pccode = 0x9ff3;
   case 0xe67c: /* �| */
      pccode = 0x8ad0;
   case 0x8ad0: /* �� */
      pccode = 0xe67c;
   case 0xe8f2: /* �� */
      pccode = 0x8c7a;
   case 0x8c7a: /* �z */
      pccode = 0xe8f2;
   case 0xe1e6: /* �� */
      pccode = 0x8d7b;
   case 0x8d7b: /* �{ */
      pccode = 0xe1e6;
   case 0xe541: /* �A */
      pccode = 0x8ec7;
   case 0x8ec7: /* �� */
      pccode = 0xe541;
   case 0xe8d5: /* �� */
      pccode = 0x9078;
   case 0x9078: /* �x */
      pccode = 0xe8d5;
   case 0xe6cb: /* �� */
      pccode = 0x9147;
   case 0x9147: /* �G */
      pccode = 0xe6cb;
   case 0x9ae2: /* �� */
      pccode = 0x92d9;
   case 0x92d9: /* �� */
      pccode = 0x9ae2;
   case 0xe1e8: /* �� */
      pccode = 0x9376;
   case 0x9376: /* �v */
      pccode = 0xe1e8;
   case 0x9e8d: /* �� */
      pccode = 0x938e;
   case 0x938e: /* �� */
      pccode = 0x9e8d;
   case 0x9fb7: /* �� */
      pccode = 0x9393;
   case 0x9393: /* �� */
      pccode = 0x9fb7;
   case 0xe78e: /* � */
      pccode = 0x93f4;
   case 0x93f4: /* �� */
      pccode = 0xe78e;
   case 0xe5a2: /* � */
      pccode = 0x9488;
   case 0x9488: /* �� */
      pccode = 0xe5a2;
   case 0x9e77: /* �w */
      pccode = 0x954f;
   case 0x954f: /* �O */
      pccode = 0x9e77;
   case 0x98d4: /* �� */
      pccode = 0x9699;
   case 0x9699: /* �� */
      pccode = 0x98d4;
   case 0xe54d: /* �M */
      pccode = 0x96f7;
   case 0x96f7: /* �� */
      pccode = 0xe54d;
   case 0xe2c4: /* �� */
      pccode = 0x9855;
   case 0x9855: /* �U */
      pccode = 0xe2c4;
   case 0xea9f: /* � */
      pccode = 0x8bc4;
   case 0x8bc4: /* �� */
      pccode = 0xea9f;
   case 0xeaa0: /* � */
      pccode = 0x968a;
   case 0x968a: /* �� */
      pccode = 0xeaa0;
   case 0xeaa1: /* � */
      pccode = 0x9779;
   case 0x9779: /* �y */
      pccode = 0xeaa1;
   case 0xeaa2: /* � */
      pccode = 0xe0f4;
   case 0xe0f4: /* �� */
      pccode = 0xeaa2;
   case 0xfa5b: /* �[ */
      pccode = 0x81e6;
   case 0xfa54: /* �T */
      pccode = 0x81ca;
   case 0x8d56: /* �V */
      pccode = 0xfad0;
   case 0xfad0: /* �� */
      pccode = 0x8d56;
   case 0xe086: /* �� */
      pccode = FillInPc;
   case 0xeaa3: /* � */
      pccode = FillInPc;
   } /* endswitch */
   return (pccode);
}

int _Export
IbmcodeStringToJiscodeString(
PCHAR ibmstr, 
int ibmstrsize,
PCHAR jisstr,
int jisstrsize) {
   RxJisArgCheck(jisstr, ibmstr, ibmstrsize, jisstrsize)
   int i = 0;
   int j = 0;
   while (i < ibmstrsize) {
      if (!IsDbcs1st(ibmstr[i])) {
         RxJisCountCheck(j + 1, jisstrsize)
         jisstr[j++] = ibmstr[i++];
         continue;
      } /* endif */
      if (i + 1 >= ibmstrsize) {
         break;
      } /* endif */
      int h = ibmstr[i++];
      int l = ibmstr[i++];
      if (!InJis90) {
         wchar_t c = h << ByteBitWidth | l;
         c = OldJisToNewJis(c);
         l = c & ByteMask;
         h = c >> ByteBitWidth;
      } /* endif */
      if (!IbmToJisTable[h] || !IbmToJisTable[h][l]) {
         RxJisCountCheck(j + 2, jisstrsize)
         jisstr[j++] = h;
         jisstr[j++] = l;
         continue;
      } /* endif */
      PCHAR s = IbmToJisTable[h][l];
      int z = strlen(s);
      RxJisCountCheck(j + z, jisstrsize)
      while (*s) {
         jisstr[j++] = *s++;
      } /* endwhile */
   } /* endwhile */
   jisstr[j] = '\0';
   return (j);
}

wchar_t _Export
PccodeToJiscode(
wchar_t pccode) {
   char b[2];
   wctomb(b, pccode);
   if (!PcCodeToJisCodeTable[b[0]]) {
      return (FillInJis);
   } /* endif */
   return (PcCodeToJisCodeTable[b[0]][b[1]]);
}
