/* product name: RXJIS                                                */
/* Version:      0.90                                                 */
/* author:       YANO Takashi                                         */
/* target:       OS/2 Warp J3.0+ (J2.1 is possible)                   */
/* source name:  PCTOJIS.HPP                                          */
/* address:      tyano@ca2.so-net.or.jp or tyano@yamato.ibm.co.jp     */
/* comment:      RXJIS is a utility functions for REXX.               */
/*               This header file is a interface to be called from    */
/*               C/C++.                                               */
/* history: 1997-08-05 0.90                                           */
/*                                                                    */
extern BOOL InJis90;
extern wchar_t _Export PccodeToJiscode(wchar_t pccode);
extern wchar_t _Export OldJisToNewJis(wchar_t pccode);
extern wchar_t _Export NewJisToOldJis(wchar_t pccode);
extern int IbmcodeStringToJiscodeString(PCHAR ibmstr, int ibmstrsize, PCHAR jisstr, int jisstrsize);
extern const int maxIbm2JisSize;
extern BOOL DbcsVec[UCHAR_MAX+1];
#define IsDbcs1st(c) DbcsVec[c]
#define FillInPc 0x81ac  // ��
#define FillInJis 0x222e // ��
#define ByteMask 0x000000ff
#define ByteBitWidth 8
#define RxJisError -1                     

#define RxJisArgCheck(source, target, targetsize, sourcesize) \
   if (NULL == source || NULL == target || targetsize <= 0) { \
      return (RxJisError); \
   } /* endif */ \
   if (sourcesize <= 0) { \
      sourcesize = strlen(source); \
   } /* endif */

#define RxJisCountCheck(count, targetsize) \
   if (count >= targetsize) { \
      return (RxJisError); \
   } /* endif */
