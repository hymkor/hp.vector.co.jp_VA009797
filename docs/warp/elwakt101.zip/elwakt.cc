#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <iomanip>
#include <fstream>
#include <strstream>
#include <exception>
#include <string>

template <class T> const T *nvl(const T *x ,const T *y )
{  return  x != 0 ? x : y ; }

class ErrorMessage : public exception {
  string message;
public:
  explicit ErrorMessage( string m ) : message( m ){}
  explicit ErrorMessage( const char *m ) : message( m ){}
  
friend ostream &operator << ( ostream &os , const ErrorMessage &it )
  { return os << it.message; }
};

class UnexpectedEOF : public ErrorMessage {
public:
  UnexpectedEOF() : ErrorMessage("unexpected EOF. The file may be broken."){}
};

class UnsupportedPDB : public ErrorMessage {
public:
  UnsupportedPDB() : ErrorMessage("unsupported .PDB file."){}
};



#define numof(A) (sizeof(A)/sizeof((A)[0]))

/* elwakt -- PDB-Plugin for ELL
 *
 * elwakt v �sPDB�t�@�C�����t
 * elwakt p �sPDB�t�@�C�����t �sUID�t
 */

/* --- memo ---
 *
 * PDB�t�@�C��
 *	- header(78bytes)
 *		+ 52to55 app_info(�J�e�S���[���)
 *		+ 56to59 sort_info(�\�[�g���)
 *		+ 76to77  ���R�[�h����
 *	- record entry header * RECORD(8 bytes/RECORD)
 *		+ 0to3  ���R�[�h�̈ʒu
 *		+ 4     ����
 *			bit7 Delete	bit6 Dirty
 *			bit5 Busy	bit4 Secret
 *			bit3�`0 �A��
 *		+ 3to7  UNIQUE-ID
 *	- empty(2bytes)
 *	- app_info
 *		+ �ύX�r�b�g(2bytes)
 *		+ �J�e�S��(15bytes+NUL)*15��
 *		
 *	- sort_info
 *	- record
 *
 */

unsigned long getCforPDB(FILE *fp) throw(UnexpectedEOF)
{
  int ch=getc(fp);
  if( ch==EOF ) throw UnexpectedEOF();
  return ch;
}

unsigned long getWforPDB(FILE *fp) throw(UnexpectedEOF)
{
  unsigned char buf[2];
  if( feof(fp) || fread( buf , 1 , sizeof(buf) , fp ) < sizeof(buf) )
    throw UnexpectedEOF();
  return (buf[0]<<8) | (buf[1] & 255 );
}

unsigned long getQforPDB(FILE *fp) throw(UnexpectedEOF)
{
  unsigned char buf[4];
  if( feof(fp) || fread( buf , 1 , sizeof(buf) , fp ) < sizeof(buf) )
    throw UnexpectedEOF();
  return (buf[0]<<24) | (buf[1]<<16) | (buf[2]<<8) | buf[3];
}

/* PDB�t�@�C���̂P���R�[�h�G���g�����Ǘ�����N���X
 */
class RecordEntry {
  unsigned long position;
  unsigned long attrib;
  
  enum{
    DELETED = 0x80000000 ,
    DIRTY   = 0x40000000 ,
    BUSY    = 0x20000000 ,
    SECRET  = 0x10000000 ,

    CATEGORY= 0x0F000000 ,
    UID     = 0x00FFFFFF ,
  };
      
public:
  bool isDeleted() const { return attrib & DELETED; }
  bool isDirty()   const { return attrib & DIRTY;   }
  bool isBusy()    const { return attrib & BUSY;    }
  bool isSecret()  const { return attrib & SECRET;  }

  unsigned long getCategory() const { return (attrib & CATEGORY) >> 24; }
  unsigned long getUID()      const { return attrib & UID; }
  unsigned long getPos()      const { return position; }

  RecordEntry(){}
  ~RecordEntry(){}

  /* read
   * 
   * PDB�t�@�C���̑S�Ẵ��R�[�h�G���g����ǂݏo���āA
   * RecordEntry�^�̔z��Ƃ��ĕԂ��ÓI���\�b�h�B
   *
   * �A��l�̔z��́A�g�p���ς񂾂�Adelete[] ����K�v������B
   */

  /* read(1) 
   *
   * ���݂̃t�@�C���ǂݏo���ʒu���烌�R�[�h�G���g����
   * ����ł���Ɖ��肵�Ă���o�[�W�����B
   * ���R�[�h�G���g�����́A���� n �ŗ^���Ă��K�v������B
   *
   *	n  (in)	���R�[�h�G���g����
   *	fp (in)	PDB�t�@�C���̃t�@�C���|�C���^
   */
  static RecordEntry *read(int n,FILE *fp){
    RecordEntry *buf=new RecordEntry[n];
    if( buf==0 )
      return 0;

    for(int i=0;i<n;i++){
      buf[i].position = getQforPDB(fp);
      buf[i].attrib   = getQforPDB(fp);
    }
    return buf;
  }

  /* read(2)
   *
   * ���R�[�h�G���g���̈ʒu�܂ŁA�t�@�C���ǂ݈ʒu��
   * �ړ������āA��O����ɕK�v�Ȑ��̃��R�[�h�G���g��
   * ��ǂݏo���o�[�W�����B
   *
   *	fp  (in) PDB�t�@�C���̃t�@�C���|�C���^
   *	*n (out) ���R�[�h�G���g���̐�
   */

  static RecordEntry *read(FILE *fp,int *n=NULL){
    if( n != NULL ){
      fseek(fp,76,SEEK_SET);
      *n = getWforPDB(fp);
    }else{
      fseek(fp,78,SEEK_SET);
    }
    return RecordEntry::read(*n,fp);
  }
};

/* �S�J�e�S���[���Ǘ�����N���X
 */
class Category{
  char category[16][16];
public:
  const char *operator[] (int n){
    return category[n];
  }

  void read(FILE *fp) throw(UnexpectedEOF) {
    (void)getw(fp);
    if( fread( category , 1 , sizeof(category) , fp ) < sizeof(category) )
      throw UnexpectedEOF();
  }

  int getMaxLength() const {
    int length=0;
    for(int i=0;i<16;i++){
      int len=strlen(category[i]);
      if( len > length )
	length = len;
    }
    return length;
  }

  Category(){}
  Category(FILE *fp){ read(fp); }
  ~Category(){}
};

enum PDBType {
  PDB_UNKNOWN ,
  PDB_MEMOPAD ,
  PDB_TODO ,
  PDB_ADDRESS ,
};

PDBType whichPdb( const char *path )
{
  const char *name=_getname(path);
  
  if( stricmp(name,"MemoDB") == 0 )
    return PDB_MEMOPAD;
  else if( stricmp(name,"ToDoDB") == 0 )
    return PDB_TODO;
  else if( stricmp(name,"AddressDB") == 0 )
    return PDB_ADDRESS;
  else
    return PDB_UNKNOWN;
}

PDBType whichPdb( FILE *fp )
{
  char buffer[16];
  int ch;

  for(int i=0;i<sizeof(buffer);i++){
    if( (ch=getc(fp))==EOF )
      return PDB_UNKNOWN;
    
    if( ch==0 ){
      buffer[i]='\0';
      break;
    }
    buffer[i] = ch;
  }
  return whichPdb( buffer );
}


/* ���݂̃t�@�C���ǂݏo���ʒu���A'\0'�܂ł�S�ĕW���o�͂ɓf���B
 */
static int print_until_zero(FILE *fp , ostream &outs )
{
  int ch;
  while( (ch=getc(fp)) !='\0' && ch != EOF )
    outs << char(ch);
  return ch;
}

static int print_until_zero_without_yomi(FILE *fp , ostream &outs )
{
  int ch;
  while( (ch=getc(fp)) != '\0' && ch != EOF ){
    if( ch == 1 ){
      while( (ch=getc(fp)) != '\0' && ch != EOF )
	;
      return ch;
    }
    outs << char(ch);
  }
  return ch;
}

static int print_until_zero_with_yomi(  FILE *fp
				      , const char *pre
				      , const char *post
				      , ostream &outs )
{
  int ch;
  while( (ch=getc(fp)) != '\0' && ch != EOF ){
    if( ch == 1 ){
      outs << pre;
      while( (ch=getc(fp)) != '\0' && ch != EOF )
	outs << char(ch);
      outs << post;
      return ch;
    }
    outs << char(ch);
  }
  return ch;
}



/* ���݂̃t�@�C���ǂݏo���ʒu���A���s��'\0'�܂ł�S�ĕW���o�͂ɓf���B
 */
static int print_1_line(FILE *fp , ostream &outs )
{
  int ch;
  while( (ch=getc(fp)) !='\0' && ch != EOF && ch != '\n' )
    outs << char(ch);
  return ch;
}

static int view_list( FILE *fp , ostream &outs) throw( ErrorMessage )
{
  PDBType pdbtype=whichPdb( fp );
  if( pdbtype == PDB_UNKNOWN )
    throw UnsupportedPDB();
  
  RecordEntry *recEntry=0;
  try{
    int nRecords;
    recEntry=RecordEntry::read(fp,&nRecords);
    if( recEntry != NULL ){
      Category category(fp);
      
      int category_space = category.getMaxLength();
      
      for(int i=0;i<nRecords;i++){
	outs << (recEntry[i].isDeleted() ? 'D' : '-' );
	outs << (recEntry[i].isDirty()   ? 'X' : '-' );
	outs << (recEntry[i].isBusy()    ? 'B' : '-' );
	outs << (recEntry[i].isSecret()  ? 'S' : '-' );
	outs << ' ' << setfill('0') << setw(6) << hex << recEntry[i].getUID() ;
	outs << " (" << setfill(' ') << setw(category_space)
	  << category[ recEntry[i].getCategory() ];
	outs << ") ";
	
	fseek( fp , recEntry[i].getPos() , SEEK_SET);
	switch( pdbtype ){
	case PDB_MEMOPAD:
	  print_1_line(fp,outs);
	  outs << endl;
	  break;
	  
	case PDB_TODO:
	  {
	    unsigned date = getWforPDB(fp);
	    if( date == 0xFFFF ){
	      outs << "           ";
	    }else{
	      outs << setw(4) << 1904 + ((date >> 9) & 127);
	      outs << '/' << setw(2) << ((date >> 5 ) & 15);
	      outs << '/' << (date & 31);
	      outs << ' ';
	    }
	    int kanryo=getc(fp);
	    outs << '[' << char(kanryo) << "] " << setw(1) << (kanryo & 127);
	    outs << ' ';
	    
	    if( print_1_line(fp,outs) != EOF &&  getc(fp) != '\0' )
	      outs << " [Note]";
	    outs << endl;
	  }
	  break;
	  
	case PDB_ADDRESS:
	  {
	    (void)getQforPDB(fp);
	    (void)getQforPDB(fp);
	    (void)getCforPDB(fp);
	    if( print_until_zero_without_yomi(fp,outs) != EOF ){
	      outs << ' ';
	      print_until_zero_without_yomi(fp,outs);
	    }
	    outs << endl;
	  }
	  break;
	  
	default:
	  ;
	}
      }
      delete [] recEntry;
    } /* if recEntry != NULL */
  }catch( UnexpectedEOF ){
    delete [] recEntry;
    throw;
  }
  return 0;
}

void cat_pdb( FILE *fp , unsigned long uid , ostream &outs )
{
  PDBType pdbtype=whichPdb( fp );
  if( pdbtype == PDB_UNKNOWN )
    throw UnsupportedPDB();

  RecordEntry *recEntry=0;
  try{
    int nRecords;
    recEntry=RecordEntry::read(fp,&nRecords);
    if( recEntry == NULL )
      throw ErrorMessage("memory allocation error.");
    
    for(int i=0;i<nRecords;i++){
      if( recEntry[i].getUID() == uid ){
	fseek( fp , recEntry[i].getPos(), SEEK_SET);
	
	switch( pdbtype ){
	case PDB_MEMOPAD:
	  print_until_zero(fp,outs);
	  goto exit;
	  
	case PDB_TODO:
	  (void)getWforPDB(fp);
	  (void)getc(fp);

	  outs << '[';
	  print_until_zero(fp,outs) ;
	  outs << ']';
	  if( ! feof(fp) )
	    print_until_zero(fp,outs);
	  goto exit;
	  
	case PDB_ADDRESS:
	  {
	    const static char *contents_name[]={
	      "��","��","��Ж�",0,0,0,0,0,
	      "�Z��","�s����","�s���{��","�X�֔ԍ�","��","��E",
	      "Custom1","Custom2","Custom3","Custom4","        \n",
	    };
	    const static char *phone_name[]={
	      "���","����" , "Fax","���̑�",
	      "E-Mail","��\\ ","�|�P�x��","�g��",
	    };
	    unsigned long phone    = getQforPDB(fp);
	    unsigned long contents = getQforPDB(fp);
	    (void)getCforPDB(fp);
	    
	    for(int i=0;i<numof(contents_name);i++){
	      if( contents & 1 ){
		outs << setw(9)
		  << nvl( contents_name[i] , phone_name[ phone & 15 ] );
		print_until_zero_with_yomi(fp,"\n (�ǂ�)  ","",outs );
		outs << endl;
	      }
	      if( contents_name[i] == 0 )
		phone >>= 4;
	      contents >>= 1;
	    }
	  }
	  goto exit;
	default:
	  ;
	}
      }
    } // for loop
    ostrstream sbuf;
    sbuf << setw(6) << setfill('0') << hex << uid
      << "no such UID." << ends; /* %06lX */
    throw ErrorMessage( sbuf.str() );
  }catch(...){
    delete [] recEntry;
    throw;
  }
 exit:
  delete [] recEntry;
}


int main(int argc,char **argv)
{
  if( argc < 3 ){
    cerr << "elwakt 1.01 -- PDB-Plugin for ELL\n";
    cerr << "usage:\n";
    cerr << "       elwakt v MemoDB.pdb\n";
    cerr << "       elwakt e MemoDB.pdb UID\n";
    cerr << "       elwakt p MemoDB.pdb UID\n";
    return -1;
  }
  FILE *fp=NULL;
  try{
    if( argv[1][0] == 'v' ){
      /* �ꗗ�\�� */
      fp=fopen(argv[2],"rb");
      if( fp == NULL ){
	perror(argv[2]);
	return 1;
      }
      view_list(fp,cout);
      
    }else if( argv[1][0] == 'e' ){
      if( argc < 4 ){
	cerr << argv[0] << ": -e option needs UID.\n";
	return 0;
      }
      fp=fopen(argv[2],"rb");
      if( fp == NULL ){
	perror(argv[2]);
	return 1;
      }
      /* �o�̓t�@�C���̖��̂���� */
      ostrstream textfilename;
      textfilename << argv[3] << ".txt";
      
      /* �o�̓t�@�C���ւ̃X�g���[�����쐬 */
      ofstream fout( textfilename.str() );
      if( ! fout )
	throw ErrorMessage("can't open the file.");
      
      cat_pdb( fp , strtoul(argv[3],NULL,16) , fout );
      
    }else if( argv[1][0] == 'p' ){
      if( argc < 4 ){
	cerr << argv[0] << ": -p option needs UID.\n";
	return 0;
      }
      fp=fopen(argv[2],"rb");
      if( fp == NULL ){
	perror(argv[2]);
	return 1;
      }
      cat_pdb( fp , strtoul(argv[3],NULL,16) , cout );
      cout << flush;
    }else{
      cerr << argv[0] << ": " << argv[1] << "unsupported command." << endl;
    }
  }catch( ErrorMessage &e ){
    cerr << argv[0] << ": " << argv[2] << ": " << e << endl;
  }
  if( fp != NULL )
    fclose(fp);
  return 0;
}
