/* #define NDEBUG */
#include <assert.h>
#include <alloca.h>
#include <assert.h>
#include <ctype.h>
#include <io.h>
#include <signal.h>
#include <stdlib.h>
#include <string.h>

#include <sys/ioctl.h>
#include <sys/video.h>
#include <sys/kbdscan.h>

#define INCL_VIO
#define INCL_DOSPROCESS
#define INCL_DOSNLS
#define INCL_WIN
#include <os2.h>

#define KARL
#include "lesz.h"
#include "filewin.h"

extern int do_option(const char *);

HAB hab,hmq;
int jump_table_init();
extern command_t (*jump_table[])( Pager & );
const char *program_name;

int screen_width , screen_height;
int original_cursor_x  , original_cursor_y ;
char *original_screen;
int screen_size;

/* VIO�v���O��������A�����I�� PM �A�v���P�[�V�����ɉ�����
 * ����ɂ���āAPM �̃N���b�v�{�[�h�̓ǂݏ������\�Ƃ���B
 */
int pretend_pm_application()
{
  PTIB  ptib = NULL;
  PPIB  ppib = NULL;
  APIRET rc = DosGetInfoBlocks(&ptib, &ppib);
  if (rc != 0)
    return rc;
  ppib->pib_ultype = PROG_PM;
  hab = WinInitialize(0);
  hmq = WinCreateMsgQueue(hab, 0);
  if (hmq == NULLHANDLE)
    return rc;
  return 0;
}

int lesz( int argc , char **argv )
{
  const char *filename=NULL;
  program_name = argv[0];

  // **** �R�}���h���C���I�v�V����
  for( int i=1 ; i < argc ; i++ ){
    
    if( argv[i][0] == '-'  &&  argv[i][1] != '\0'  ){
      int result = do_option( &argv[i][1] );
      if( result != 0 )
	return result ;
      
    }else{
      filename = argv[i];
    }
  }

  signal( SIGINT , SIG_IGN );			/* �uCtrl-C�v�𖳎�����B*/
  v_init();					/* ��ʊ֌W */
  v_dimen( &screen_width , &screen_height );	/* ��ʂ̑傫�����L�^ */
  Buffer buffer(screen_width);
  
  /* ��ʂ̕ۑ� */
  v_getxy( &original_cursor_x , &original_cursor_y );
  original_screen
    = (char*)alloca( (screen_size = screen_width * screen_height)*2 );
  v_getline( original_screen , 0 , 0 , screen_size );


  /**************** �I�v�V������� ********************/
	
  // **** ���ϐ��ɂ��I�v�V���� ( strtok �Ő؂�o�� )
  
  char *option=getenv(OPTIONENV);
  if( option != NULL ){
    char leszopt[ 256 ];
    strcpy( leszopt , option );
    
    option = strtok( leszopt , " \t\n\r" );
    while( option != NULL ){
      if( *option == '-' ) // �I�v�V�����������u-�v�͂����Ă��Ȃ��Ă��悢�B
	option++;
      
      int result = do_option( option );
      if( result != 0 )
	return result;
      
      option = strtok( NULL , " \t\n\r" );
    }
  }
  
  
  if( filename == NULL ) { // �t�@�C�������w�肵�Ă��Ȃ���
    if( isatty(fileno(stdin)) ){
      FileWindow filewin(".");
      filewin.open(0,1,30,screen_height-1);
      
      char topline[160];
      {	/* ��ʂ̍ŏ�s�Ƀ^�C�g����\�� */
	const char title[]="The pager for OS/2 Warp KARL "VER;
	const char usage[]="Esc-key: Cancel , Option -h or -j : Help";
	
	int orgattr = v_getattr();
	v_getline( topline , 0 , 0 , 80 );
	v_attrib( 0x0E );
	int x,y;
	v_getxy( &x,&y );
	v_gotoxy( 0 , 0 );               v_putn( ' ',screen_width );
	v_gotoxy( 0 , 0 );               v_puts( title );
	v_gotoxy( 80-sizeof(usage) , 0 );v_puts( usage );
	
	v_gotoxy( x , y );
	v_attrib( orgattr );
      }
      for(;;){
	switch( getkey(1) ){
	  
	case 'k':
	case 'K':
	case 'p':
	case 'P':
	case CTRL('P'):
	case KEY(UP):
	  filewin.csr_backward();
	  break;
	  
	case 'j':case 'J':
	case 'n':case 'N':case CTRL('N'):
	case KEY(DOWN):
	  filewin.csr_forward();
	  break;
	  
	case '\r':
	case 'i':
	case 'v':
	  if( filewin->is_dir() ){
	    filewin.chdir();
	    break;
	  }else{
	    filename = filewin.csr_fname();
	    filewin.close();
	    v_getline( topline , 0 , 0 , 80 );
	    goto file_sel_loop;
	  }
	case 'q':
	case 'Q':
	case '\x1b':
	case 'o':
	  filewin.close();
	  v_getline( topline , 0 , 0 , 80 );
	  return 1;
	}
      }
    file_sel_loop: ;
      if( buffer.open( filename , filename ) ){
	perror( argv[1] );
	return 1;
      }
    }else if( buffer.open( stdin , "<STDIN>" ) ){
      return 1;
    }
    
  }else if( buffer.open( filename , filename ) ){
    perror( argv[1] );
    return 1;
  }
  
  Pager win( buffer , 0 , 0 , screen_height );
  
  win.paint_top();
  
  jump_table_init();
  if( !buffer != Buffer::ENDOFFILE ){
    int id=buffer.beginBackgroundThread();
    assert(id != -1);
  }
  // ���C�����[�`��
  for(;;){
    int key = getkey(1);
    switch( (*jump_table[ key + 1 ] )(win) ){
      
    case RESTORE_QUIT: // �ۑ�������ʂ��񕜂��ďI��
      v_putline( original_screen , 0 , 0 , screen_size );
      v_gotoxy( original_cursor_x , original_cursor_y );
      return 0;
      
    case QUIT: // ��ʂ����̂܂܂ɂ��ďI��
      v_gotoxy( 0 , screen_height-1 );
      return 0;

    default:
      break;
    }
  }// end for(;;)
  
}// end lesz()

ULONG codepages[8];

int main(int argc,char **argv)
{
  if( _osmode == DOS_MODE ){
    fprintf( stderr, "\nThis program runs under OS/2 prompt.\n" );
    return -1;
  }
  ULONG CpSize;
  
  if(   DosQueryCp(sizeof(codepages),codepages,&CpSize )==0 
     && codepages[0] != CHEV_JP )
    Buffer::setDefaultNomemoMode( false );
  
  // �J�[�\���֌W
  int cursor_start,cursor_end;
  v_getctype( &cursor_start , &cursor_end );
  v_hidecursor();
  
  int result=lesz(argc,argv);

  v_ctype( cursor_start , cursor_end );
  return result;
}
