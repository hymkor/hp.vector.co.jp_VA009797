#include "filewin.h"
#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <sys/video.h>

enum{
  FRAME_ATTRIB = 0x0B
};

int FileWindow::screen_save(void)
{
  if( (screen_buffer=new char[width*(height+2)*2]) == NULL )
    return 1;
  
  char *ptr=screen_buffer;
  v_getline( ptr , x0 , y0-1 , width );
  for(int i=0 ; i<height ; i++ ){
    v_getline( ptr , x0 , y0+i , width );
    ptr += width*2;
  }
  v_putline( ptr , x0 , y0+height , width );
  return 0;
}

int FileWindow::screen_restore(void)
{
  if( screen_buffer == NULL )
    return 1;
  
  char *ptr=screen_buffer;
  v_putline( ptr , x0 , y0-1 , width );
  for(int i=0 ; i<height ; i++ ){
    v_putline( ptr , x0 , y0+i , width );
    ptr += width*2 ; 
  }
  v_putline( ptr, x0 , y0+height , width );
  return 0;
}

void FileWindow::chdir( void )
{
  ::chdir( cursor->fname() );
  close();
  Files::close();
  csrlin = 0;
  heaven = Files::open(".");
  open(_x0,_y0,_width,_height);
}

void FileWindow::disp_a_file( int y , Files *ptr , unsigned attr )
{
  char buffer[ 128 ];
	
  if( ptr->is_dir() ){
    sprintf( buffer, "    <DIR>  %s",ptr->fname() );
  }else{
    sprintf( buffer, "%10d %s" , ptr->size()  , ptr->fname() );
  }
  
  unsigned len = ptr->namlen()+12;
  if( len >= width-2 ){
    len = width-2;
  }else{
    v_attrib( attr );
    v_scroll( x0+1+len , y0+y , x0+width-2 , y0+y , 1 , V_SCROLL_CLEAR ) ;
  }
  int orgx,orgy;
  v_getxy( &orgx , &orgy );

  v_gotoxy( x0 , y0+y );
  v_attrib( FRAME_ATTRIB );
  v_putc( framechar[1][0] );
  v_attrib( attr );
  v_putm( buffer , len );
  v_attrib( FRAME_ATTRIB );
  v_gotoxy( x0+width-1 , y0+y );
  v_putc( framechar[1][2] );

  v_gotoxy( orgx , orgy );
}

/* ���݂� heaven �̈ʒu�ɏ]���āA��ʂɃ��X�g��\�����A
 *	�|�C���^ : earth,hell,cursor ���X�V����B
 */

void FileWindow::repaint( void )
{
  if( openflag == 0 )
    return;
  
  int orgx,orgy;
  v_getxy( &orgx , &orgy );

  int orgattr = v_getattr();
  
  hell = earth = heaven;

  char buffer[ FILENAME_MAX ];
  _getcwd2( buffer , sizeof(buffer) );
  buffer[ width-3 ] = '\0';
 
  v_attrib( FRAME_ATTRIB );
  v_frameline( x0 , y0-1 , width , framechar[0] );
  v_gotoxy( x0+1 , y0-1 );
  v_attrib( 0x3F );
  v_puts( buffer );

  int i;
  for(i=0 ; i<height  ; i++ ){
    if( hell == NULL )
      break;

    if( i==csrlin )
      disp_a_file(i, cursor=hell , CURSOR_ATTRIB );
    else
      disp_a_file(i, hell , TEXT_ATTRIB );
    earth = hell;
    hell = hell->forward();
  }

  v_attrib( FRAME_ATTRIB );
  v_frameline( x0,y0+i,width,framechar[2] );

  int len=sprintf( buffer , " %d files " , nfiles );
  v_gotoxy( x0+width-len-3 , y0+i  );
  v_puts( buffer );

  v_attrib(orgattr);
  v_gotoxy( orgx , orgy );
}

int FileWindow::open( int x,int y,int w,int h )
{
  if( openflag ){
    return 2;
  }
  framechar = getframechar();
  
  x0 = (_x0=x);
  y0 = (_y0=y)+1;
  width = (_width=w);
  height = (_height=h)-2;
  if( screen_save() )
    return 1;
  
  nfiles = 0;
  for( Files *tmp=heaven ; tmp != NULL ; tmp=tmp->forward() )
    nfiles++;

#if 0
  struct{
    ULONG filesysid , sectornum , unitnum , unitavail;
    USHORT bytesnum;
  } infobuf;
    
  if( DosQueryFSInfo(0,1,&infobuf,sizeof(infobuf) == 0 ){
    diskspace = infobuf.unitavail * infobuf.sectornum * infobuf.bytesnum;
#endif

  openflag = 1;
  repaint();
  return 0;
}

int FileWindow::close( void )
{
  if( openflag ){
    openflag = 0;
    
    if( screen_buffer != NULL ){
      screen_restore();
      delete [] screen_buffer;
      screen_buffer = NULL;
    }
  }
  return 0;
}

void FileWindow::pageup( void )
{
  for(int i=0 ; i<height ; i++ ){
    if( hell == NULL )
      break;
    heaven = heaven->forward();
    earth = hell;
    hell = hell->forward();
  }
  repaint();
}

void FileWindow::pagedown( void )
{
  for(int i=0 ; i<height ; i++ ){
    if( heaven->backward() == NULL )
      break;
    hell = earth;
    earth = earth->backward();
    heaven = heaven->backward();
  }
  repaint();
}

void FileWindow::scrollup( void )
{
  int orgattr=v_getattr();
  if( hell != NULL ){
    if( cursor != NULL )
      disp_a_file( csrlin , cursor , TEXT_ATTRIB );
    v_scroll( x0 , y0 , x0+width-1 , y0+height-1 , 1,V_SCROLL_UP );
    
    earth = hell;
    hell = hell->forward();
    heaven = heaven->forward();
    
    disp_a_file( height-1, earth , TEXT_ATTRIB );
    if( cursor != NULL )
      disp_a_file( csrlin , cursor = cursor->forward() , CURSOR_ATTRIB );

  }
  v_attrib(orgattr);
}

void FileWindow::scrolldown( void )
{
  if( heaven->backward() != NULL ){
    if( cursor != NULL )
      disp_a_file( csrlin , cursor , TEXT_ATTRIB );

    v_scroll( x0 , y0 , x0+width-1 , y0+height-1 , 1, V_SCROLL_DOWN );
    
    hell = earth;
    earth = earth->backward();
    heaven = heaven->backward();
    
    disp_a_file( 0 , heaven , TEXT_ATTRIB );
    if( cursor != NULL )
      disp_a_file( csrlin , cursor = cursor->backward() , CURSOR_ATTRIB );
  }
}

void FileWindow::csr_forward( void )
{
  if( cursor == earth ){ /* �E�C���h�E�̈�ԉ��Ȃ�� */
    scrollup();
  }else{
    disp_a_file( csrlin , cursor , TEXT_ATTRIB );
    disp_a_file( ++csrlin , cursor=cursor->forward() , CURSOR_ATTRIB );
  }
}

void FileWindow::csr_backward( void )
{
  if( cursor == heaven ){ /* �E�C���h�E�̈�ԏ�Ȃ�� */
    scrolldown();
  }else{
    disp_a_file( csrlin , cursor , TEXT_ATTRIB );
    disp_a_file( --csrlin , cursor=cursor->backward() , CURSOR_ATTRIB );
  }
}

#ifdef TEST
int main(void)
{
  v_init();
	
  FileWindow fw(".");
	
  fw.open(0,0,16,25);
	
  for(;;){
    int ch=getch();
    switch(ch){
    case '\r':
      v_attrib( 0x0F );
      fw.close();
      printf( "%s\n" , fw.csr_fname() );
      return 0;
    case 'n':case 'N':case ('n' & 0x1f):
      fw.csr_forward();
      break;
    case 'p':case 'P':case ('p' & 0x1F):
      fw.csr_backward();
      break;
    }
  }
}
#endif
