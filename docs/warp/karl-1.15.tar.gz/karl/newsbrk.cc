#undef DEBUG
#include <assert.h>
#include <stdlib.h>
#include <os2.h>
#include "newsbrk.h"

#ifdef DEBUG
#  define DEBUG1(x) (x)
#  include <stdio.h>
#  include <malloc.h>
#else
#  define DEBUG1(x)
#endif

enum{
  BLOCK_SIZE = 1024,
};

void *Sbrk::alloc( unsigned  size )
{
  if( leftsize < size ){
    Block *prev = block;

    /* Sbrk �Ŋm�ۂ��ꂽ�������� 16bitAPI �̊֐�(v_putline��)��
     * �Ă΂�邱�Ƃ�����B���̎��A16bit���E���ׂ��ł͂����Ȃ���
     * �ŁA������ _tmalloc ���g�p����B
     */

    if( (block = (Block*)_tmalloc( sizeof(Block) + BLOCK_SIZE )) == NULL ){
#ifdef DEBUG
      fprintf(stderr,"(Sbrk::alloc) malloc(%d) failed.\n",BLOCK_SIZE);
      perror("(Sbrk::alloc)");
      switch( _heapchk() ){
      case _HEAPBADBEGIN:
	fputs("(Sbrk::alloc) _heapchk()==_HEAPBADBEGIN : heap is corrupt.\n"
	      , stderr );
	break;
      case _HEAPBADEND:
	fputs("(Sbrk::alloc) _heapchk()==_HEAPBADEND : heap is corrupt.\n"
	      , stderr );
	break;
      case _HEAPBADNODE:
	fputs("(Sbrk::alloc) _heapchk()==_HEAPBADNODE : "
	      "A block of the heap is damaged or "
	      "the heap is corrupted.\n" , stderr );
	break;
      case _HEAPEMPTY:
	fputs("(Sbrk::alloc) _heapchk()==_HEAPEMPTY : "
	      "heap has not been initialized.\n",stderr );
	break;
      case _HEAPOK:
	fputs("(Sbrk::alloc) _heapchk()==_HEAPOK : "
	      "The heep seems to be consistent.\n",stderr);
	break;
      }
#endif
	    
      block=prev;
      return NULL;
    }
    
    block->prev = prev ;
    usedsize = 0;
    pointor = block->buffer;

    if( (leftsize = BLOCK_SIZE) < size ){
      DEBUG1(fputs("(Sbrk::alloc) too much size requested\n",stderr));
      return NULL ;
    }
  }
  
  void *result = pointor;
  
  pointor  += size;
  usedsize += size;
  leftsize -= size;
  
  return result;
}

void Sbrk::back( int size )
{
  if( size <= 0 )
    return;

  if( usedsize >= (unsigned)size ){
    pointor  -= size;
    leftsize += size;
    usedsize -= size;
  }else{
    pointor  -= usedsize;
    leftsize += usedsize;
    usedsize  = 0;
  }
}

void Sbrk::free( void )
{
  while( block != NULL ){
    Block  *tmp = block->prev;
    ::_tfree( block );
    
    block = tmp;
  }
  usedsize = leftsize = 0;
}
