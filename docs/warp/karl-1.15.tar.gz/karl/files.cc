#include "files.h"
#ifdef TEST
#	include <stdio.h>
#endif

DIR *Files::dirp = NULL;
Files *Files::first = NULL;

Files::Files(void)
{
	struct dirent *tmp = readdir(dirp);
	if( tmp != NULL ){
		memcpy( &info , tmp , sizeof(struct dirent) );
		status = 0;
	}else{
		status = 1;
	}
	next = prev = NULL ; /* �b��I��NULL�ɂ��� */
}
Files *Files::forward(void)
{
	if( next != NULL )
		return next;
	
	if( (next=new Files) == NULL )
		return NULL;
	
	if( !(*next) ){
		delete next;
		return next = NULL;
	}
	
	next->prev = this;
	return next;
}

Files::~Files(void)
{
	/* ��E���ƑS�ł���B*/
	if( prev == NULL ){ /* ---> �擪 */
		first = NULL;
	}else{
		prev->next = NULL;
		delete prev;
	}
	
	if( next != NULL ){
		next->prev = NULL;
		delete next;
	}
}

Files *Files::open( const char *path )
{
	if( dirp != NULL  || (dirp=opendir(path))==NULL )
		return NULL;
	
	return first = new Files;
}

void Files::close( void )
{
	delete first;
	first = NULL;
	closedir(dirp);
	dirp = NULL;
}
#ifdef TEST
int main(void)
{
	Files *ptr=Files::open("."),*tmp;
	while( ptr != NULL ){
		printf( "%s\n",ptr->fname() );
		tmp = ptr;
		ptr = ptr->forward();
	}
	printf("Reverse!!\n");
	while( tmp != NULL ){
		printf( "%s\n",tmp->fname() );
		tmp = tmp->backward();
	}
	Files::close();
	return 0;
}
#endif /* TEST */
