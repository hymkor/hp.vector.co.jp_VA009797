#include <stdlib.h>
#include <sys/video.h>
#include <sys/kbdscan.h>
#include "wminput.h"

void WmInput::putchr(int ch)
{
  static int prevchar=0;
  if( prevchar != 0 ){
    char buf[3] = { prevchar , ch , '\0' };
    wm_puts( handle , buf);
    prevchar = 0;
  }else if( isKanji(ch & 255) ){
    prevchar = ch;
  }else{
    wm_putc( handle , ch );
  }
}
void WmInput::putbs(int n)
{
  wm_backsp( handle , n );
}

void WmInput::start(void)
{
  wm_cursor( handle );

  wm_cvis( handle , 1 );
  ::box_cursor_on();

  /* debug */
  while( _read_kbd(0,0,0) != -1 )
    sleep(0);
}

void WmInput::end(void)
{
  ::cursor_off();
}
