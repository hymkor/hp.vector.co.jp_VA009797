#include <assert.h>
#include <stdlib.h>
#include <string.h>

#include "effetc.h"
#include "thedir.h"
#include "files.h"
#include "os2eff.h"

void Files::insert_nul(unsigned extrabytes) throw(MallocError)
{
  Node *node = (Node*)malloc(sizeof(Node)+extrabytes+3);
  if( node == 0 )
    throw MallocError();
  
  memset( node , 0 , sizeof(Node)+extrabytes+2 );
  node->name = node->extra + extrabytes ;
  node->length = 3;
  node->attr = 0;
  node->name[0] = 'N';
  node->name[1] = 'U';
  node->name[2] = 'L';
  node->name[3] = '\0';
  node->prev = node->next = NULL;
  node->flag = NULFILE;
  
  add(node);
}

int Files::getFileSys(int drive)
{
  char drivestr[3]={drive,':','\0'};
  char fsys[16];

  int rc=_filesys(drivestr , fsys , sizeof(fsys) );
  if( rc != 0 )
    return -1;
  
  /* FAT , HPFS , CDFS , LAN */
  return fsys[0];
}

/* FAT �Ɏ��[�\�ȃt�@�C����(8+3����)���쐬����B
 * �t���p�X�ɂ͑Ή����Ă��Ȃ��B
 *
 *	buffer  �V�t�@�C����������o�b�t�@
 *	orgname ���̃t�@�C����
 */
void Files::make83name(  char buffer[20] , const char *orgname )
{
  const char *newSuffix=NULL;
  const char *finalDot=strrchr(orgname,'.');

  int length=strlen(orgname);
  if( stricmp( &orgname[length-sizeof(".tar.bz2")+1] , ".tar.bz2" ) == 0 ){
    newSuffix = ".TBZ";
  }else if( stricmp( &orgname[length-sizeof(".tar.gz")+1] , "tar.gz" ) == 0 ){
    newSuffix = ".TGZ";
  }else{
    newSuffix = finalDot;
  }

  bool afterkanji=false;
  
  const char *sp=orgname;
  char *dp=buffer;
  int len=0;

  while( *sp != '\0'  &&  len < 8 ){
    /* �����u�� */
    if( !afterkanji ){
      switch( *sp ){
      case '.':
	if( sp == finalDot ){
	  goto exit;
	}else{
	  *dp++ = '_';
	  ++sp;
	  ++len;
	  continue;
	}
	
      case '[':
	*dp++ = '{'; ++sp; ++len;
	continue;

      case ']':
	*dp++ = '}'; ++sp; ++len;
	continue;

      case '=':
	*dp++ = '@'; ++sp; ++len;
	continue;

      case ',':	
      case '+':
      case ' ':
      case ';':
	*dp++ = '_'; ++sp; ++len;
	continue;
      }
    }

    if( afterkanji ){
      afterkanji = false;
    }else if( isKanji(*sp) ){
      if( len == 7 )
	break;
      afterkanji = true;
    }else{
      afterkanji = false;
    }
    *dp++ = *sp++;
    ++len;
  }
 exit:
  if( newSuffix != NULL ){
    for(int i=0 ; i<4  &&  *newSuffix != '\0' ; i++ )
      *dp++ = *newSuffix++;
    *dp = '\0';
  }
}
