
#include <stddef.h>

class Dir {
  void *resultBuf;
  size_t resultBufLen;
  

public:

};
