#ifndef MACROS_H
#define MACROS_H

#undef numof
#define numof(A) ((int)(sizeof(A) / sizeof((A)[0])))

#undef KEY
#define KEY(X) ( (K_##X) | 0x100 )

#undef CTRL
#define CTRL(X) ((X) & 0x1F)

#ifdef DEBUG
#  undef DEBUG1
#  define DEBUG1(x) (x)
#else
#  undef DEBUG1
#  define DEBUG1(x)
#endif

class MallocError{ };
class FileNotFound{ };

#endif /* MACROS_H */
