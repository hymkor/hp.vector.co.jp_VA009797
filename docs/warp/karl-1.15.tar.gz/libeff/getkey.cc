#include <assert.h>
#include <io.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>

#include <string.h> /* for memset */
#include <stdlib.h> /* for _osmode */
#include <dos.h>    /* for int86 */

#include <termios.h>
#include <termio.h>

#include "effetc.h"
#include "getline.h"

static int tty=-255;
static struct termios orig,s;
static int raw_level=0;

void raw_mode(void)
{
  if( raw_level++ > 0 )
    return;

  if( _osmode == DOS_MODE )
    return;
  
  if( tty == -255 ){
    tcgetattr(tty=2,&s);
    orig = s;
  }
  /* �@�\�� off �ɂ��� */
  s.c_lflag &= ~(  ICANON /* line editing */
		 | ECHO   /* echo input */
		 | ECHOK  /* echo CR/LF after VKILL */
		 | ISIG   /* Enable signal processing */
		 | ECHONL /* not support ? */
		 );
  /* �ȉ��̓�s�͓� */
  s.c_oflag |=  ( TAB3 | OPOST | ONLCR );
  s.c_oflag &= ~( OCRNL | ONOCR | ONLRET );

  /* �ꕶ���P�ʂŁA0�b�Ŕ��������� */
  s.c_cc[VMIN] = 1;
  s.c_cc[VTIME] = 0;
  
  tcsetattr(tty,TCSADRAIN,&s);
}

void cocked_mode(void)
{
  if( --raw_level > 0 )
    return;

  if( tty == 2  &&  _osmode != DOS_MODE )
    tcsetattr(tty,TCSADRAIN,&orig);
  raw_level = 0;
}

int get86key(void)
{
  if( _osmode == DOS_MODE ){
    /* DOS�ł�_read_kbd�ŁA�����̑��o�C�g�ڂ��擾�ł��Ȃ��B*/
    union REGS regs;
    regs.h.ah = 0x7;
    return _int86( 0x21, &regs , &regs ) & 0xFF ;
  }else{
    unsigned char key;
    int rc;

    enum{ READ_INTR = -2 };
    assert( tty != -255 );

    do{
      if( isatty( tty ) ){
	fd_set readfds;
	FD_ZERO( &readfds );
	FD_SET(tty,&readfds );
	if( select(tty+1,&readfds,NULL,NULL,NULL) == -1 )
	  return 0;
      }
      
      rc= read( tty , &key , sizeof(char) );
      if( rc < 0 )
	return 0;
    }while( rc != 1 );
    return key & 0xFF;
  }
}

static int keybuf[16],left=0;

void ungetkey(int key)
{
  keybuf[ left++ ] = key;
}

int getkey(void)
{
  if( left > 0 )
    return keybuf[ --left ];

  int ch = (get86key() & 0xFF );
  if( ch == 0 )
    ch = (get86key()|0x100);
  else if( isKanji(ch) )
    ch = ((ch << 8)|(get86key() & 0xFF));

  return ch;
}
