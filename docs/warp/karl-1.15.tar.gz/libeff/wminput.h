/* -*- c++ -*- */
#ifndef WMINPUT_H
#include <sys/winmgr.h>
#include "getline.h"

class WmInput : public VioCannaInput {
  wm_handle handle;
protected:
  void putchr(int);
  void putbs(int);
  void start(void);
  void end(void);
public:
  WmInput(wm_handle h) : handle(h) {  }
};

#endif
